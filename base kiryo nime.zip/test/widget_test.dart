import 'package:flutter_test/flutter_test.dart';

import 'package:flutter_base/main.dart';

void main() {
  testWidgets('menampilkan halaman login', (WidgetTester tester) async {
    await tester.pumpWidget(const FlutterBaseApp());
    await tester.pump(const Duration(milliseconds: 900));

    expect(find.text('𝙆𝙄𝙍𝙔𝙊 𝙈𝘼𝙉𝙕'), findsOneWidget);
    expect(find.text('LOGIN'), findsOneWidget);
  });
}
