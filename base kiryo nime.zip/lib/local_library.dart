import 'dart:convert';
import 'dart:io';

import 'app_paths.dart';
import 'session.dart';

import 'package:shared_preferences/shared_preferences.dart';

// ---------------------------------------------------------------------------
// Download folder preference
// ---------------------------------------------------------------------------

class DownloadFolderPref {
  static const _key = 'download_folder_mode_v1';
  /// 'download' | 'kiryo'
  static Future<String> mode() async {
    final p = await SharedPreferences.getInstance();
    return p.getString(_key) ?? 'download';
  }

  static Future<void> setMode(String mode) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_key, mode == 'kiryo' ? 'kiryo' : 'download');
  }

  static Future<Directory> resolve() async {
    const base = '/storage/emulated/0/Download';
    final m = await mode();
    final path = m == 'kiryo' ? '$base/KIRYO' : base;
    final dir = Directory(path);
    try {
      if (!await dir.exists()) await dir.create(recursive: true);
      final probe = File('${dir.path}/.kiryo_write_probe');
      await probe.writeAsString('ok', flush: true);
      await probe.delete();
      return dir;
    } catch (_) {
      return dir; // caller may still fail; AppErrors will explain
    }
  }
}

// ---------------------------------------------------------------------------
// Catalog cache (JSON blob + TTL)
// ---------------------------------------------------------------------------

class CatalogCache {
  static Future<void> put(String key, Object data, {Duration ttl = const Duration(hours: 6)}) async {
    final p = await SharedPreferences.getInstance();
    final payload = {
      'savedAt': DateTime.now().toIso8601String(),
      'ttlMs': ttl.inMilliseconds,
      'data': data,
    };
    await p.setString('catalog_cache_$key', jsonEncode(payload));
  }

  static Future<Object?> get(String key) async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString('catalog_cache_$key');
    if (raw == null || raw.isEmpty) return null;
    try {
      final map = jsonDecode(raw);
      if (map is! Map) return null;
      final savedAt = DateTime.tryParse('${map['savedAt']}') ?? DateTime.fromMillisecondsSinceEpoch(0);
      final ttlMs = int.tryParse('${map['ttlMs']}') ?? 0;
      if (DateTime.now().difference(savedAt).inMilliseconds > ttlMs) {
        await p.remove('catalog_cache_$key');
        return null;
      }
      return map['data'];
    } catch (_) {
      return null;
    }
  }

  static Future<void> invalidate(String key) async {
    final p = await SharedPreferences.getInstance();
    await p.remove('catalog_cache_$key');
  }
}

// ---------------------------------------------------------------------------
// Generic media entry (history / bookmark)
// ---------------------------------------------------------------------------

class LibraryEntry {
  const LibraryEntry({
    required this.id,
    required this.title,
    required this.coverUrl,
    required this.kind, // manga | anime | ba
    this.subtitle,
    this.progress,
    this.extra,
    this.updatedAt,
  });

  final String id;
  final String title;
  final String coverUrl;
  final String kind;
  final String? subtitle;
  final String? progress;
  final Map<String, dynamic>? extra;
  final DateTime? updatedAt;

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'coverUrl': coverUrl,
        'kind': kind,
        'subtitle': subtitle,
        'progress': progress,
        'extra': extra,
        'updatedAt': (updatedAt ?? DateTime.now()).toIso8601String(),
      };

  factory LibraryEntry.fromJson(Map<String, dynamic> j) => LibraryEntry(
        id: '${j['id'] ?? ''}',
        title: '${j['title'] ?? ''}',
        coverUrl: '${j['coverUrl'] ?? ''}',
        kind: '${j['kind'] ?? ''}',
        subtitle: j['subtitle']?.toString(),
        progress: j['progress']?.toString(),
        extra: j['extra'] is Map ? Map<String, dynamic>.from(j['extra'] as Map) : null,
        updatedAt: DateTime.tryParse('${j['updatedAt'] ?? ''}'),
      );
}

class _JsonListStore {
  static Future<List<LibraryEntry>> list(String key) async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(key);
    if (raw == null || raw.isEmpty) return [];
    try {
      final decoded = jsonDecode(raw);
      if (decoded is! List) return [];
      return decoded
          .whereType<Map>()
          .map((e) => LibraryEntry.fromJson(Map<String, dynamic>.from(e)))
          .where((e) => e.id.isNotEmpty)
          .toList();
    } catch (_) {
      return [];
    }
  }

  static Future<void> save(String key, List<LibraryEntry> items) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(key, jsonEncode(items.map((e) => e.toJson()).toList()));
  }

  static Future<void> upsert(String key, LibraryEntry item, {int max = 100}) async {
    final all = await list(key);
    all.removeWhere((e) => e.id == item.id && e.kind == item.kind);
    all.insert(0, item);
    if (all.length > max) {
      all.removeRange(max, all.length);
    }
    await save(key, all);
  }

  static Future<void> remove(String key, String id, {String? kind}) async {
    final all = await list(key);
    all.removeWhere((e) => e.id == id && (kind == null || e.kind == kind));
    await save(key, all);
  }

  static Future<bool> contains(String key, String id, {String? kind}) async {
    final all = await list(key);
    return all.any((e) => e.id == id && (kind == null || e.kind == kind));
  }
}

class HistoryStore {
  static const _baseKey = 'library_history_v1';

  static Future<String> _key() => UserDataKeys.of(_baseKey);

  static Future<List<LibraryEntry>> list({String? kind}) async {
    final all = await _JsonListStore.list(await _key());
    if (kind == null) return all;
    return all.where((e) => e.kind == kind).toList();
  }

  static Future<void> add(LibraryEntry item) async =>
      _JsonListStore.upsert(await _key(), item, max: 80);

  static Future<void> remove(String id, {String? kind}) async =>
      _JsonListStore.remove(await _key(), id, kind: kind);

  static Future<void> clear() async {
    final p = await SharedPreferences.getInstance();
    await p.remove(await _key());
  }

  /// Ganti seluruh list (dipakai saat pull dari server agar tidak campur akun lain).
  static Future<void> replaceAll(List<LibraryEntry> items) async {
    await _JsonListStore.save(await _key(), items);
  }
}

class BookmarkStore {
  static const _baseKey = 'library_bookmarks_v1';

  static Future<String> _key() => UserDataKeys.of(_baseKey);

  static Future<List<LibraryEntry>> list({String? kind}) async {
    final all = await _JsonListStore.list(await _key());
    if (kind == null) return all;
    return all.where((e) => e.kind == kind).toList();
  }

  static Future<bool> isBookmarked(String id, {String? kind}) async =>
      _JsonListStore.contains(await _key(), id, kind: kind);

  static Future<void> add(LibraryEntry item) async =>
      _JsonListStore.upsert(await _key(), item, max: 200);

  static Future<void> remove(String id, {String? kind}) async =>
      _JsonListStore.remove(await _key(), id, kind: kind);

  static Future<void> toggle(LibraryEntry item) async {
    final on = await isBookmarked(item.id, kind: item.kind);
    if (on) {
      await remove(item.id, kind: item.kind);
    } else {
      await add(item);
    }
  }

  static Future<void> clear() async {
    final p = await SharedPreferences.getInstance();
    await p.remove(await _key());
  }

  /// Ganti seluruh list (pull server — isolasi per akun).
  static Future<void> replaceAll(List<LibraryEntry> items) async {
    await _JsonListStore.save(await _key(), items);
  }
}

// ---------------------------------------------------------------------------
// Offline index: local file paths for chapters/episodes
// ---------------------------------------------------------------------------

class OfflineIndex {
  static const _baseKey = 'offline_index_v1';

  static Future<String> _key() => UserDataKeys.of(_baseKey);

  static Future<Map<String, dynamic>> _all() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(await _key());
    if (raw == null || raw.isEmpty) return {};
    try {
      final d = jsonDecode(raw);
      if (d is Map) return Map<String, dynamic>.from(d);
    } catch (_) {}
    return {};
  }

  static Future<void> _write(Map<String, dynamic> data) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(await _key(), jsonEncode(data));
  }

  /// key contoh: anime:slug:ep10 / manga:slug:ch12
  static Future<void> register({
    required String key,
    required String filePath,
    required String title,
    String? owner,
    String? animeTitle,
    String? coverUrl,
    String? seriesKey,
  }) async {
    final all = await _all();
    var own = (owner ?? '').trim();
    if (own.isEmpty) {
      try {
        own = (await SessionStore.getUsername()) ?? '';
      } catch (_) {}
    }
    all[key] = {
      'path': filePath,
      'title': title,
      'owner': own,
      'savedAt': DateTime.now().toIso8601String(),
      if (animeTitle != null && animeTitle.trim().isNotEmpty)
        'animeTitle': animeTitle.trim(),
      if (coverUrl != null && coverUrl.trim().isNotEmpty)
        'coverUrl': coverUrl.trim(),
      if (seriesKey != null && seriesKey.trim().isNotEmpty)
        'seriesKey': seriesKey.trim(),
    };
    await _write(all);
  }

  /// Judul serial dari judul episode (untuk item lama tanpa animeTitle).
  static String seriesTitleFromEpisode(String title) {
    var t = title.trim();
    t = t.replaceAll(RegExp(r'\s*\([^)]*\)\s*$'), '');
    t = t.replaceAll(
        RegExp(r'\s*Episode\s+\d+.*$', caseSensitive: false), '');
    t = t.replaceAll(
        RegExp(r'\s*Ep\.?\s*\d+.*$', caseSensitive: false), '');
    t = t.replaceAll(
        RegExp(r'\s*Subtitle\s+Indonesia.*$', caseSensitive: false), '');
    t = t.trim();
    return t.isEmpty ? title : t;
  }

  /// Kelompokkan item offline per serial anime.
  static List<Map<String, dynamic>> groupBySeries(
    List<Map<String, dynamic>> items,
  ) {
    final map = <String, Map<String, dynamic>>{};
    for (final e in items) {
      final key = (e['key'] ?? '').toString();
      var seriesKey = (e['seriesKey'] ?? '').toString().trim();
      if (seriesKey.isEmpty && key.startsWith('anime:')) {
        final parts = key.split(':');
        if (parts.length >= 2 && parts[1] != 'scan') {
          seriesKey = 'anime:${parts[1]}';
        }
      }
      final animeTitle = (e['animeTitle'] ?? '').toString().trim();
      final title = (e['title'] ?? '').toString();
      final display = animeTitle.isNotEmpty
          ? animeTitle
          : seriesTitleFromEpisode(title);
      if (seriesKey.isEmpty) {
        seriesKey = 'title:${display.toLowerCase()}';
      }
      final cover = (e['coverUrl'] ?? '').toString();
      final bucket = map.putIfAbsent(
        seriesKey,
        () => {
          'seriesKey': seriesKey,
          'animeTitle': display,
          'coverUrl': cover,
          'items': <Map<String, dynamic>>[],
          'count': 0,
        },
      );
      if (cover.isNotEmpty && (bucket['coverUrl'] as String).isEmpty) {
        bucket['coverUrl'] = cover;
      }
      if (animeTitle.isNotEmpty) bucket['animeTitle'] = animeTitle;
      (bucket['items'] as List<Map<String, dynamic>>).add(e);
      bucket['count'] = (bucket['count'] as int) + 1;
    }
    final out = map.values.toList();
    out.sort((a, b) =>
        '${a['animeTitle']}'.toLowerCase().compareTo('${b['animeTitle']}'.toLowerCase()));
    return out;
  }

  /// Scan folder assets/video — pulihkan index jika prefs kosong/terlewat.
  static Future<void> scanLocalVideos() async {
    try {
      final dir = await AppPaths.video();
      if (!await dir.exists()) return;
      final all = await _all();
      final existingPaths = <String>{};
      for (final e in all.values) {
        if (e is Map && e['path'] != null) {
          existingPaths.add(e['path'].toString());
        }
      }
      var owner = '';
      try {
        owner = (await SessionStore.getUsername()) ?? '';
      } catch (_) {}
      var changed = false;
      await for (final entity in dir.list()) {
        if (entity is! File) continue;
        final path = entity.path;
        final low = path.toLowerCase();
        if (!(low.endsWith('.mp4') ||
            low.endsWith('.mkv') ||
            low.endsWith('.webm') ||
            low.endsWith('.avi'))) {
          continue;
        }
        if (existingPaths.contains(path)) continue;
        final name = path.split(Platform.pathSeparator).last;
        final key = 'anime:scan:$name';
        if (all.containsKey(key)) continue;
        all[key] = {
          'path': path,
          'title': name.replaceAll('_', ' ').replaceAll(RegExp(r'\.(mp4|mkv|webm|avi)$', caseSensitive: false), ''),
          'owner': owner,
          'savedAt': (await entity.stat()).modified.toIso8601String(),
        };
        changed = true;
      }
      if (changed) await _write(all);
    } catch (_) {}
  }

  static Future<List<Map<String, dynamic>>> listForUser(String username) async {
    await scanLocalVideos();
    await pruneMissing();
    final all = await listAll();
    final u = username.trim().toLowerCase();
    final out = <Map<String, dynamic>>[];
    for (final e in all) {
      final path = e['path']?.toString() ?? '';
      // Hanya tampilkan jika file benar-benar ada (hindari duplikat gagal)
      if (path.isEmpty || !File(path).existsSync()) continue;
      try {
        if (File(path).lengthSync() < 50 * 1024) continue; // <50KB = gagal
      } catch (_) {
        continue;
      }
      final owner = (e['owner'] ?? '').toString().trim().toLowerCase();
      if (u.isEmpty || owner.isEmpty || owner == u) {
        out.add(e);
      }
    }
    return out;
  }

  static Future<String?> pathFor(String key) async {
    final all = await _all();
    final e = all[key];
    if (e is Map) {
      final path = e['path']?.toString();
      if (path != null && path.isNotEmpty && await File(path).exists()) {
        return path;
      }
    }
    return null;
  }

  /// Hapus entry offline + file lokal (jika ada).
  static Future<void> remove(String key) async {
    final all = await _all();
    final e = all[key];
    if (e is Map) {
      final path = e['path']?.toString() ?? '';
      if (path.isNotEmpty) {
        try {
          final f = File(path);
          if (await f.exists()) await f.delete();
        } catch (_) {}
      }
    }
    all.remove(key);
    await _write(all);
  }

  /// Hapus semua key dalam daftar.
  static Future<void> removeKeys(Iterable<String> keys) async {
    for (final k in keys) {
      await remove(k);
    }
  }

  /// Bersihkan index yang file-nya hilang / terlalu kecil (gagal unduh).
  static Future<void> pruneMissing() async {
    final all = await _all();
    final drop = <String>[];
    for (final e in all.entries) {
      if (e.value is! Map) {
        drop.add(e.key);
        continue;
      }
      final path = (e.value as Map)['path']?.toString() ?? '';
      if (path.isEmpty) {
        drop.add(e.key);
        continue;
      }
      try {
        final f = File(path);
        if (!await f.exists() || await f.length() < 50 * 1024) {
          drop.add(e.key);
          try {
            if (await f.exists() && await f.length() < 50 * 1024) {
              await f.delete();
            }
          } catch (_) {}
        }
      } catch (_) {
        drop.add(e.key);
      }
    }
    if (drop.isEmpty) return;
    for (final k in drop) {
      all.remove(k);
    }
    await _write(all);
  }

  static Future<List<Map<String, dynamic>>> listAll() async {
    final all = await _all();
    final out = <Map<String, dynamic>>[];
    for (final e in all.entries) {
      if (e.value is Map) {
        final m = Map<String, dynamic>.from(e.value as Map);
        m['key'] = e.key;
        out.add(m);
      }
    }
    out.sort((a, b) => '${b['savedAt']}'.compareTo('${a['savedAt']}'));
    return out;
  }
}

// ---------------------------------------------------------------------------
// Blue Archive history + favorites
// ---------------------------------------------------------------------------

class BaImageEntry {
  const BaImageEntry({
    required this.id,
    required this.url,
    this.localPath,
    this.favorite = false,
    this.savedAt,
  });

  final String id;
  final String url;
  final String? localPath;
  final bool favorite;
  final DateTime? savedAt;

  Map<String, dynamic> toJson() => {
        'id': id,
        'url': url,
        'localPath': localPath,
        'favorite': favorite,
        'savedAt': (savedAt ?? DateTime.now()).toIso8601String(),
      };

  factory BaImageEntry.fromJson(Map<String, dynamic> j) => BaImageEntry(
        id: '${j['id'] ?? ''}',
        url: '${j['url'] ?? ''}',
        localPath: j['localPath']?.toString(),
        favorite: j['favorite'] == true,
        savedAt: DateTime.tryParse('${j['savedAt'] ?? ''}'),
      );

  BaImageEntry copyWith({String? localPath, bool? favorite}) => BaImageEntry(
        id: id,
        url: url,
        localPath: localPath ?? this.localPath,
        favorite: favorite ?? this.favorite,
        savedAt: savedAt,
      );
}

class BaLibrary {
  static const _baseKey = 'ba_library_v1';

  static Future<String> _key() => UserDataKeys.of(_baseKey);

  static Future<List<BaImageEntry>> list() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(await _key());
    if (raw == null || raw.isEmpty) return [];
    try {
      final d = jsonDecode(raw);
      if (d is! List) return [];
      return d
          .whereType<Map>()
          .map((e) => BaImageEntry.fromJson(Map<String, dynamic>.from(e)))
          .where((e) => e.id.isNotEmpty)
          .toList();
    } catch (_) {
      return [];
    }
  }

  static Future<void> _save(List<BaImageEntry> items) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(await _key(), jsonEncode(items.map((e) => e.toJson()).toList()));
  }

  static Future<void> add(BaImageEntry item) async {
    final all = await list();
    all.removeWhere((e) => e.id == item.id);
    all.insert(0, item);
    if (all.length > 60) all.removeRange(60, all.length);
    await _save(all);
  }

  static Future<void> setFavorite(String id, bool fav) async {
    final all = await list();
    final i = all.indexWhere((e) => e.id == id);
    if (i < 0) return;
    all[i] = all[i].copyWith(favorite: fav);
    await _save(all);
  }

  static Future<List<BaImageEntry>> favorites() async {
    final all = await list();
    return all.where((e) => e.favorite).toList();
  }

  static Future<void> removeIds(Set<String> ids) async {
    if (ids.isEmpty) return;
    final all = await list();
    final kept = <BaImageEntry>[];
    for (final e in all) {
      if (ids.contains(e.id)) {
        final path = e.localPath;
        if (path != null && path.isNotEmpty) {
          try {
            final f = File(path);
            if (await f.exists()) await f.delete();
          } catch (_) {}
        }
      } else {
        kept.add(e);
      }
    }
    await _save(kept);
  }
}

// ---------------------------------------------------------------------------
// Search suggestions (recent queries)
// ---------------------------------------------------------------------------

class SearchSuggest {
  static const _manga = 'search_suggest_manga_v1';
  static const _anime = 'search_suggest_anime_v1';

  static Future<List<String>> recent(String key) async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(key);
    if (raw == null) return [];
    try {
      final d = jsonDecode(raw);
      if (d is List) {
        return d.map((e) => e.toString()).where((e) => e.isNotEmpty).toList();
      }
    } catch (_) {}
    return [];
  }

  static Future<void> push(String key, String query) async {
    final q = query.trim();
    if (q.isEmpty) return;
    final all = await recent(key);
    all.removeWhere((e) => e.toLowerCase() == q.toLowerCase());
    all.insert(0, q);
    if (all.length > 12) all.removeRange(12, all.length);
    final p = await SharedPreferences.getInstance();
    await p.setString(key, jsonEncode(all));
  }

  static Future<List<String>> manga() => recent(_manga);
  static Future<void> pushManga(String q) => push(_manga, q);
  static Future<List<String>> anime() => recent(_anime);
  static Future<void> pushAnime(String q) => push(_anime, q);
}
