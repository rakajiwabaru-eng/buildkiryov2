import 'dart:io';
import 'dart:async';
import 'dart:convert';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';

import 'api_sync.dart';
import 'app_notifications.dart';
import 'app_errors.dart';
import 'session.dart';
import 'direct_download.dart';
import 'app_features.dart';
import 'local_library.dart';
import 'smart_image.dart';

/// Primary: Natee (cepat & stabil). Fallback: SiputZX.
const String _nateeBase = 'https://api.otakudesu.natee.my.id';
const String _siputzxBase = 'https://api.siputzx.my.id';

// ---------------------------------------------------------------------------
// Models
// ---------------------------------------------------------------------------

class AnimeOngoingItem {
  const AnimeOngoingItem({
    required this.title,
    required this.link,
    required this.image,
    this.episode,
    this.type,
    this.date,
    this.slug,
  });

  final String title;
  final String link;
  final String image;
  final String? episode;
  final String? type;
  final String? date;
  final String? slug;

  factory AnimeOngoingItem.fromNatee(Map<String, dynamic> json) {
    final slug = (json['slug'] ?? '').toString();
    final url = (json['otakudesu_url'] ?? '').toString();
    return AnimeOngoingItem(
      title: (json['title'] ?? '').toString(),
      link: url.isNotEmpty ? url : 'https://otakudesu.blog/anime/$slug/',
      image: (json['poster'] ?? '').toString(),
      episode: json['current_episode']?.toString(),
      type: json['release_day']?.toString(),
      date: json['newest_release_date']?.toString(),
      slug: slug.isNotEmpty ? slug : null,
    );
  }

  factory AnimeOngoingItem.fromSiputzx(Map<String, dynamic> json) {
    return AnimeOngoingItem(
      title: (json['title'] ?? '').toString(),
      link: (json['link'] ?? '').toString(),
      image: (json['image'] ?? json['imageUrl'] ?? '').toString(),
      episode: json['episode']?.toString(),
      type: json['type']?.toString(),
      date: json['date']?.toString(),
      slug: _slugFromUrl((json['link'] ?? '').toString()),
    );
  }
}

class AnimeSearchItem {
  const AnimeSearchItem({
    required this.title,
    required this.link,
    required this.imageUrl,
    this.genres,
    this.status,
    this.rating,
    this.slug,
  });

  final String title;
  final String link;
  final String imageUrl;
  final String? genres;
  final String? status;
  final String? rating;
  final String? slug;

  factory AnimeSearchItem.fromNatee(Map<String, dynamic> json) {
    final slug = (json['slug'] ?? '').toString();
    final url = (json['url'] ?? json['otakudesu_url'] ?? '').toString();
    String? genres;
    final g = json['genres'];
    if (g is List) {
      genres = g
          .map((e) => e is Map ? (e['name'] ?? '').toString() : e.toString())
          .where((e) => e.isNotEmpty)
          .join(', ');
    } else if (g != null) {
      genres = g.toString();
    }
    return AnimeSearchItem(
      title: (json['title'] ?? '').toString(),
      link: url.isNotEmpty ? url : 'https://otakudesu.blog/anime/$slug/',
      imageUrl: (json['poster'] ?? json['imageUrl'] ?? json['image'] ?? '').toString(),
      genres: genres,
      status: json['status']?.toString(),
      rating: json['rating']?.toString(),
      slug: slug.isNotEmpty ? slug : _slugFromUrl(url),
    );
  }

  factory AnimeSearchItem.fromSiputzx(Map<String, dynamic> json) {
    return AnimeSearchItem(
      title: (json['title'] ?? '').toString(),
      link: (json['link'] ?? '').toString(),
      imageUrl: (json['imageUrl'] ?? json['image'] ?? '').toString(),
      genres: json['genres']?.toString(),
      status: json['status']?.toString(),
      rating: json['rating']?.toString(),
      slug: _slugFromUrl((json['link'] ?? '').toString()),
    );
  }
}

class AnimeInfo {
  const AnimeInfo({
    required this.title,
    this.japaneseTitle,
    this.score,
    this.producer,
    this.type,
    this.status,
    this.totalEpisodes,
    this.duration,
    this.releaseDate,
    this.studio,
    this.genres,
    this.imageUrl,
    this.slug,
    this.synopsis,
  });

  final String title;
  final String? japaneseTitle;
  final String? score;
  final String? producer;
  final String? type;
  final String? status;
  final String? totalEpisodes;
  final String? duration;
  final String? releaseDate;
  final String? studio;
  final String? genres;
  final String? imageUrl;
  final String? slug;
  final String? synopsis;
}

class AnimeEpisode {
  const AnimeEpisode({
    required this.title,
    required this.link,
    this.date,
    this.slug,
  });

  final String title;
  final String link;
  final String? date;
  final String? slug;
}

class AnimeDetail {
  const AnimeDetail({
    required this.animeInfo,
    required this.episodes,
  });

  final AnimeInfo animeInfo;
  final List<AnimeEpisode> episodes;
}

class DownloadItem {
  const DownloadItem({
    required this.quality,
    required this.link,
    required this.host,
  });

  final String quality;
  final String link;
  final String host;
}


// ---------------------------------------------------------------------------
// Favorit anime + cek episode baru
// ---------------------------------------------------------------------------

class AnimeFavorite {
  const AnimeFavorite({
    required this.id,
    required this.title,
    required this.coverUrl,
    required this.link,
    this.latestEpisode,
    this.episodeCount,
  });

  final String id;
  final String title;
  final String coverUrl;
  final String link;
  final String? latestEpisode;
  final int? episodeCount;

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'coverUrl': coverUrl,
        'link': link,
        'latestEpisode': latestEpisode,
        'episodeCount': episodeCount,
      };

  factory AnimeFavorite.fromJson(Map<String, dynamic> j) => AnimeFavorite(
        id: '${j['id'] ?? ''}',
        title: '${j['title'] ?? ''}',
        coverUrl: '${j['coverUrl'] ?? ''}',
        link: '${j['link'] ?? ''}',
        latestEpisode: j['latestEpisode']?.toString(),
        episodeCount: j['episodeCount'] is int
            ? j['episodeCount'] as int
            : int.tryParse('${j['episodeCount'] ?? ''}'),
      );

  AnimeFavorite copyWith({String? latestEpisode, int? episodeCount, String? coverUrl, String? title}) {
    return AnimeFavorite(
      id: id,
      title: title ?? this.title,
      coverUrl: coverUrl ?? this.coverUrl,
      link: link,
      latestEpisode: latestEpisode ?? this.latestEpisode,
      episodeCount: episodeCount ?? this.episodeCount,
    );
  }
}

class AnimeFavoriteStore {
  static const _key = 'anime_favorites_v1';

  static Future<List<AnimeFavorite>> list() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw == null || raw.isEmpty) return [];
    try {
      final decoded = jsonDecode(raw);
      if (decoded is! List) return [];
      return decoded
          .whereType<Map>()
          .map((e) => AnimeFavorite.fromJson(Map<String, dynamic>.from(e)))
          .where((e) => e.id.isNotEmpty)
          .toList();
    } catch (_) {
      return [];
    }
  }

  static Future<void> _save(List<AnimeFavorite> items) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _key,
      jsonEncode(items.map((e) => e.toJson()).toList()),
    );
  }

  static Future<bool> isFavorite(String id) async {
    final all = await list();
    return all.any((e) => e.id == id);
  }

  static Future<void> add(AnimeFavorite item) async {
    final all = await list();
    all.removeWhere((e) => e.id == item.id);
    all.insert(0, item);
    await _save(all);
  }

  static Future<void> remove(String id) async {
    final all = await list();
    all.removeWhere((e) => e.id == id);
    await _save(all);
  }

  static Future<void> updateLatest(
    String id, {
    String? latestEpisode,
    int? episodeCount,
  }) async {
    final all = await list();
    final i = all.indexWhere((e) => e.id == id);
    if (i < 0) return;
    all[i] = all[i].copyWith(
      latestEpisode: latestEpisode,
      episodeCount: episodeCount,
    );
    await _save(all);
  }

  /// Nomor episode (angka) dari judul, atau null.
  static String? episodeNumber(String title) {
    final m = RegExp(
      r'(?:episode|ep)\s*(\d+(?:\.\d+)?)',
      caseSensitive: false,
    ).firstMatch(title);
    if (m != null) return m.group(1);
    // fallback: angka terakhir yang masuk akal di judul
    final all = RegExp(r'(\d+(?:\.\d+)?)').allMatches(title).toList();
    if (all.isEmpty) return null;
    return all.last.group(1);
  }

  /// Label ringkas: "Episode 12" jika nomor ketemu, else judul penuh.
  static String formatEpisodeLabel(String title) {
    final n = episodeNumber(title);
    if (n != null) return 'Episode $n';
    return title;
  }

  /// Ambil label episode terbaru dari daftar.
  static String latestLabel(List<AnimeEpisode> episodes) {
    if (episodes.isEmpty) return '';
    AnimeEpisode? best;
    double bestN = -1;
    for (final e in episodes) {
      final numStr = episodeNumber(e.title);
      final n = double.tryParse(numStr ?? '') ?? -1;
      if (n >= bestN) {
        bestN = n;
        best = e;
      }
    }
    final ep = best ?? episodes.first;
    return formatEpisodeLabel(ep.title);
  }

  /// Judul episode penuh (untuk detail notifikasi).
  static String latestFullTitle(List<AnimeEpisode> episodes) {
    if (episodes.isEmpty) return '';
    AnimeEpisode? best;
    double bestN = -1;
    for (final e in episodes) {
      final numStr = episodeNumber(e.title);
      final n = double.tryParse(numStr ?? '') ?? -1;
      if (n >= bestN) {
        bestN = n;
        best = e;
      }
    }
    return (best ?? episodes.first).title;
  }

  static int countEps(List<AnimeEpisode> episodes) => episodes.length;


  /// Cek favorit yang ada episode baru. Update storage + notifikasi.
  static Future<List<AnimeFavorite>> checkUpdates(AnimeApiClient api) async {
    final all = await list();
    if (all.isEmpty) return [];
    final updated = <AnimeFavorite>[];
    final next = List<AnimeFavorite>.from(all);

    for (var i = 0; i < next.length; i++) {
      final fav = next[i];
      try {
        final d = await api.fetchDetail(slug: fav.id, animeUrl: fav.link);
        final latest = latestLabel(d.episodes);
        final full = latestFullTitle(d.episodes);
        final count = countEps(d.episodes);
        final prev = (fav.latestEpisode ?? '').trim();
        final prevCount = fav.episodeCount ?? 0;
        final isNew = (latest.isNotEmpty && latest != prev) ||
            (count > 0 && count > prevCount);

        next[i] = fav.copyWith(
          latestEpisode: latest.isNotEmpty ? latest : fav.latestEpisode,
          episodeCount: count > 0 ? count : fav.episodeCount,
          coverUrl: d.animeInfo.imageUrl,
          title: d.animeInfo.title.isNotEmpty ? d.animeInfo.title : null,
        );

        if (isNew && prev.isNotEmpty) {
          // Hanya notifikasi jika sudah pernah punya baseline (bukan pertama kali)
          updated.add(next[i].copyWith(latestEpisode: latest.isNotEmpty ? latest : full));
          final epLabel = latest.isNotEmpty ? latest : 'Episode baru';
          final bodyText = full.isNotEmpty && full != latest
              ? '${next[i].title}\n$full'
              : next[i].title;
          await AnimeUpdateNotifier.show(
            title: 'Episode baru: $epLabel',
            body: bodyText,
            id: fav.id.hashCode & 0x7fffffff,
          );
        }

      } catch (_) {}
    }

    await _save(next);

    return updated;
  }
}

class AnimeUpdateNotifier {
  static Future<void> show({
    required String title,
    required String body,
    required int id,
  }) =>
      AppNotifications.showAnime(title: title, body: body, id: id);
}

String? _slugFromUrl(String url) {
  if (url.isEmpty) return null;
  try {
    final uri = Uri.parse(url);
    final segs = uri.pathSegments.where((s) => s.isNotEmpty).toList();
    if (segs.isEmpty) return null;
    return segs.last;
  } catch (_) {
    return null;
  }
}

// ---------------------------------------------------------------------------
// API Client (multi-source)
// ---------------------------------------------------------------------------

class AnimeGenre {
  const AnimeGenre({required this.name, required this.slug});

  final String name;
  final String slug;

  factory AnimeGenre.fromJson(Map<String, dynamic> json) {
    return AnimeGenre(
      name: (json['name'] ?? '').toString(),
      slug: (json['slug'] ?? '').toString(),
    );
  }
}

class GenrePageResult {
  const GenrePageResult({
    required this.items,
    required this.currentPage,
    required this.lastPage,
    required this.hasNext,
    required this.hasPrev,
  });

  final List<AnimeSearchItem> items;
  final int currentPage;
  final int lastPage;
  final bool hasNext;
  final bool hasPrev;
}

class AnimeApiClient {
  const AnimeApiClient();

  static const _timeout = Duration(seconds: 18);

  Future<http.Response> _get(String url) {
    return http.get(Uri.parse(url)).timeout(_timeout);
  }

  Future<List<AnimeGenre>> fetchGenres() async {
    try {
      final res = await _get('$_nateeBase/api/v1/anime/genres');
      if (res.statusCode >= 200 && res.statusCode < 300) {
        final decoded = jsonDecode(res.body);
        if (decoded is Map && decoded['data'] is List) {
          return (decoded['data'] as List)
              .whereType<Map<String, dynamic>>()
              .map(AnimeGenre.fromJson)
              .where((g) => g.name.isNotEmpty && g.slug.isNotEmpty)
              .toList();
        }
      }
    } catch (_) {}
    // fallback list umum
    return const [
      AnimeGenre(name: 'Action', slug: 'action'),
      AnimeGenre(name: 'Adventure', slug: 'adventure'),
      AnimeGenre(name: 'Comedy', slug: 'comedy'),
      AnimeGenre(name: 'Drama', slug: 'drama'),
      AnimeGenre(name: 'Fantasy', slug: 'fantasy'),
      AnimeGenre(name: 'Horror', slug: 'horror'),
      AnimeGenre(name: 'Romance', slug: 'romance'),
      AnimeGenre(name: 'Sci-Fi', slug: 'sci-fi'),
      AnimeGenre(name: 'Slice of Life', slug: 'slice-of-life'),
      AnimeGenre(name: 'Sports', slug: 'sports'),
      AnimeGenre(name: 'Supernatural', slug: 'supernatural'),
    ];
  }

  Future<GenrePageResult> fetchByGenre(String slug, {int page = 1}) async {
    final res = await _get('$_nateeBase/api/v1/anime/genres/$slug?page=$page');
    if (res.statusCode < 200 || res.statusCode >= 300) {
      throw Exception('Gagal memuat genre');
    }
    final decoded = jsonDecode(res.body);
    if (decoded is! Map) throw Exception('Data genre tidak valid');
    final data = decoded['data'];
    if (data is! Map) throw Exception('Data genre tidak valid');

    final raw = data['anime'];
    final items = <AnimeSearchItem>[];
    if (raw is List) {
      for (final e in raw) {
        if (e is! Map<String, dynamic>) continue;
        items.add(AnimeSearchItem.fromNatee(e));
      }
    }

    final pag = data['pagination'];
    int current = page;
    int last = page;
    bool hasNext = false;
    bool hasPrev = page > 1;
    if (pag is Map) {
      current = int.tryParse('${pag['current_page'] ?? pag['currentPage'] ?? page}') ?? page;
      last = int.tryParse(
            '${pag['last_visible_page'] ?? pag['last_page'] ?? pag['lastPage'] ?? pag['total_pages'] ?? page}',
          ) ??
          page;
      final rawNext = pag['has_next_page'] ?? pag['hasNextPage'] ?? pag['has_next'];
      if (rawNext is bool) {
        hasNext = rawNext;
      } else if (rawNext != null) {
        hasNext = '$rawNext'.toLowerCase() == 'true';
      } else {
        hasNext = current < last;
      }
      final rawPrev = pag['has_previous_page'] ?? pag['hasPreviousPage'] ?? pag['has_prev'];
      if (rawPrev is bool) {
        hasPrev = rawPrev;
      } else {
        hasPrev = current > 1;
      }
      final nextPage = int.tryParse('${pag['next_page'] ?? ''}');
      if (nextPage != null && nextPage > current) hasNext = true;
    }
    final cleaned = items.where((e) => e.title.isNotEmpty).toList();
    if (!hasNext && cleaned.length >= 15) {
      hasNext = true;
      if (last <= current) last = current + 1;
    }

    return GenrePageResult(
      items: cleaned,
      currentPage: current,
      lastPage: last < 1 ? 1 : last,
      hasNext: hasNext,
      hasPrev: hasPrev || current > 1,
    );
  }

  Future<List<AnimeOngoingItem>> fetchOngoing() async {
    final merged = <AnimeOngoingItem>[];
    final seen = <String>{};

    // Ambil beberapa halaman ongoing (terbaru biasanya di page awal)
    for (final page in [1, 2]) {
      try {
        final res = await _get('$_nateeBase/api/ongoing-anime/$page');
        if (res.statusCode >= 200 && res.statusCode < 300) {
          final decoded = jsonDecode(res.body);
          final list = _extractNateeOngoing(decoded);
          for (final item in list) {
            final key = item.slug ?? item.link;
            if (key.isEmpty || seen.contains(key)) continue;
            seen.add(key);
            merged.add(item);
          }
        }
      } catch (_) {}
    }

    if (merged.isNotEmpty) {
      return _sortOngoingNewestFirst(merged);
    }

    try {
      final res = await _get('$_siputzxBase/api/anime/otakudesu/ongoing');
      if (res.statusCode >= 200 && res.statusCode < 300) {
        final decoded = jsonDecode(res.body);
        if (decoded is Map && decoded['status'] == true && decoded['data'] is List) {
          final list = (decoded['data'] as List)
              .whereType<Map<String, dynamic>>()
              .map(AnimeOngoingItem.fromSiputzx)
              .where((e) => e.title.isNotEmpty)
              .toList();
          return _sortOngoingNewestFirst(list);
        }
      }
    } catch (_) {}

    throw Exception('Gagal memuat anime ongoing. Coba lagi nanti.');
  }

  /// Urutkan: tanggal rilis terbaru di atas, lalu nomor episode lebih tinggi.
  List<AnimeOngoingItem> _sortOngoingNewestFirst(List<AnimeOngoingItem> list) {
    final copy = List<AnimeOngoingItem>.from(list);
    copy.sort((a, b) {
      final da = _parseReleaseDate(a.date);
      final db = _parseReleaseDate(b.date);
      final byDate = db.compareTo(da); // terbaru dulu
      if (byDate != 0) return byDate;
      final ea = _episodeNumber(a.episode);
      final eb = _episodeNumber(b.episode);
      return eb.compareTo(ea);
    });
    return copy;
  }

  /// Parse "07 Sep", "6 Sep", "07 September" → DateTime (tahun berjalan)
  DateTime _parseReleaseDate(String? raw) {
    if (raw == null || raw.trim().isEmpty) {
      return DateTime.fromMillisecondsSinceEpoch(0);
    }
    final s = raw.trim();
    final months = <String, int>{
      'jan': 1, 'january': 1, 'januari': 1,
      'feb': 2, 'february': 2, 'februari': 2,
      'mar': 3, 'march': 3, 'maret': 3,
      'apr': 4, 'april': 4,
      'may': 5, 'mei': 5,
      'jun': 6, 'june': 6, 'juni': 6,
      'jul': 7, 'july': 7, 'juli': 7,
      'aug': 8, 'august': 8, 'agt': 8, 'agustus': 8,
      'sep': 9, 'sept': 9, 'september': 9,
      'oct': 10, 'okt': 10, 'october': 10, 'oktober': 10,
      'nov': 11, 'november': 11,
      'dec': 12, 'des': 12, 'december': 12, 'desember': 12,
    };
    final m = RegExp(r'(\d{1,2})\s+([A-Za-z]+)(?:\s+(\d{4}))?').firstMatch(s);
    if (m != null) {
      final day = int.tryParse(m.group(1)!) ?? 1;
      final monKey = m.group(2)!.toLowerCase();
      final mon3 = monKey.length >= 3 ? monKey.substring(0, 3) : monKey;
      final month = months[monKey] ?? months[mon3] ?? 1;
      final year = int.tryParse(m.group(3) ?? '') ?? DateTime.now().year;
      return DateTime(year, month, day);
    }
    // fallback ISO
    return DateTime.tryParse(s) ?? DateTime.fromMillisecondsSinceEpoch(0);
  }

  int _episodeNumber(String? episode) {
    if (episode == null) return 0;
    final m = RegExp(r'(\d+)').firstMatch(episode);
    return m != null ? int.tryParse(m.group(1)!) ?? 0 : 0;
  }

  List<AnimeOngoingItem> _extractNateeOngoing(dynamic decoded) {
    if (decoded is! Map) return [];
    final data = decoded['data'];
    List? raw;
    if (data is Map) {
      raw = data['ongoingAnimeData'] as List? ?? data['animeList'] as List?;
    } else if (data is List) {
      raw = data;
    }
    if (raw == null) return [];
    return raw
        .whereType<Map<String, dynamic>>()
        .map(AnimeOngoingItem.fromNatee)
        .where((e) => e.title.isNotEmpty)
        .toList();
  }

  Future<List<AnimeSearchItem>> search(String query) async {
    final q = query.trim();
    if (q.isEmpty) return [];

    try {
      final encoded = Uri.encodeComponent(q);
      final res = await _get('$_nateeBase/api/search/$encoded');
      if (res.statusCode >= 200 && res.statusCode < 300) {
        final decoded = jsonDecode(res.body);
        final list = _extractNateeSearch(decoded);
        if (list.isNotEmpty) return list;
      }
    } catch (_) {}

    try {
      final uri = Uri.parse('$_siputzxBase/api/anime/otakudesu/search').replace(queryParameters: {'s': q});
      final res = await http.get(uri).timeout(_timeout);
      if (res.statusCode >= 200 && res.statusCode < 300) {
        final decoded = jsonDecode(res.body);
        if (decoded is Map && decoded['status'] == true && decoded['data'] is List) {
          return (decoded['data'] as List)
              .whereType<Map<String, dynamic>>()
              .map(AnimeSearchItem.fromSiputzx)
              .where((e) => e.title.isNotEmpty)
              .toList();
        }
      }
    } catch (_) {}

    throw Exception('Pencarian gagal. Coba lagi.');
  }

  List<AnimeSearchItem> _extractNateeSearch(dynamic decoded) {
    if (decoded is! Map) return [];
    final data = decoded['data'];
    List? raw;
    if (data is List) {
      raw = data;
    } else if (data is Map) {
      raw = data['animeList'] as List? ?? data['searchAnimeData'] as List?;
    }
    if (raw == null) return [];
    return raw
        .whereType<Map<String, dynamic>>()
        .map(AnimeSearchItem.fromNatee)
        .where((e) => e.title.isNotEmpty)
        .toList();
  }

  Future<AnimeDetail> fetchDetail({String? slug, String? animeUrl}) async {
    final s = (slug != null && slug.isNotEmpty) ? slug : _slugFromUrl(animeUrl ?? '');
    if (s == null || s.isEmpty) {
      throw Exception('Slug anime tidak valid');
    }

    try {
      final res = await _get('$_nateeBase/api/anime/$s');
      if (res.statusCode >= 200 && res.statusCode < 300) {
        final decoded = jsonDecode(res.body);
        final detail = _parseNateeDetail(decoded, s);
        if (detail != null) return detail;
      }
    } catch (_) {}

    if (animeUrl != null && animeUrl.isNotEmpty) {
      try {
        final uri = Uri.parse('$_siputzxBase/api/anime/otakudesu/detail').replace(queryParameters: {'url': animeUrl});
        final res = await http.get(uri).timeout(_timeout);
        if (res.statusCode >= 200 && res.statusCode < 300) {
          final decoded = jsonDecode(res.body);
          if (decoded is Map && decoded['status'] == true && decoded['data'] is Map) {
            return _parseSiputzxDetail(decoded['data'] as Map<String, dynamic>, s);
          }
        }
      } catch (_) {}
    }

    throw Exception('Gagal memuat detail anime.');
  }

  AnimeDetail? _parseNateeDetail(dynamic decoded, String slug) {
    if (decoded is! Map) return null;
    final data = decoded['data'];
    if (data is! Map) return null;

    String? genres;
    final g = data['genres'];
    if (g is List) {
      genres = g
          .map((e) => e is Map ? (e['name'] ?? '').toString() : e.toString())
          .where((e) => e.isNotEmpty)
          .join(', ');
    }

    final info = AnimeInfo(
      title: (data['title'] ?? '').toString(),
      japaneseTitle: data['japanese_title']?.toString() ?? data['japanese']?.toString(),
      score: data['rating']?.toString() ?? data['score']?.toString(),
      producer: data['produser']?.toString() ?? data['producers']?.toString(),
      type: data['type']?.toString(),
      status: data['status']?.toString(),
      totalEpisodes: data['episode_count']?.toString() ?? data['episodes']?.toString(),
      duration: data['duration']?.toString(),
      releaseDate: data['release_date']?.toString() ?? data['aired']?.toString(),
      studio: data['studio']?.toString() ?? data['studios']?.toString(),
      genres: genres,
      imageUrl: (data['poster'] ?? data['imageUrl'] ?? '').toString(),
      slug: slug,
      synopsis: _parseSynopsis(data['synopsis'] ?? data['sinopsis'] ?? data['description']),
    );

    final episodes = <AnimeEpisode>[];
    final eps = data['episode_lists'] ?? data['episodes'] ?? data['episodeList'];
    if (eps is List) {
      for (final e in eps) {
        if (e is! Map) continue;
        final epSlug = (e['slug'] ?? '').toString();
        final url = (e['otakudesu_url'] ?? e['link'] ?? '').toString();
        final title = (e['episode'] ?? e['title'] ?? '').toString();
        if (title.isEmpty && epSlug.isEmpty) continue;
        episodes.add(AnimeEpisode(
          title: title.isNotEmpty ? title : epSlug,
          link: url.isNotEmpty ? url : 'https://otakudesu.blog/episode/$epSlug/',
          date: e['date']?.toString(),
          slug: epSlug.isNotEmpty ? epSlug : _slugFromUrl(url),
        ));
      }
    }
    if (episodes.length > 1) {
      final firstNum = _epNum(episodes.first.title);
      final lastNum = _epNum(episodes.last.title);
      if (firstNum != null && lastNum != null && firstNum < lastNum) {
        return AnimeDetail(animeInfo: info, episodes: episodes.reversed.toList());
      }
    }
    return AnimeDetail(animeInfo: info, episodes: episodes);
  }

  int? _epNum(String title) {
    final m = RegExp(r'Episode\s+(\d+)', caseSensitive: false).firstMatch(title);
    return m != null ? int.tryParse(m.group(1)!) : null;
  }

  /// synopsis bisa string, list paragraf, atau map { paragraphs: [...] }
  String? _parseSynopsis(dynamic raw) {
    if (raw == null) return null;
    if (raw is String) {
      final t = raw.trim();
      return t.isEmpty ? null : t;
    }
    if (raw is List) {
      final parts = raw.map((e) => e.toString().trim()).where((e) => e.isNotEmpty);
      final t = parts.join('\n\n');
      return t.isEmpty ? null : t;
    }
    if (raw is Map) {
      final p = raw['paragraphs'] ?? raw['text'] ?? raw['content'];
      return _parseSynopsis(p);
    }
    final t = raw.toString().trim();
    return t.isEmpty ? null : t;
  }

  AnimeDetail _parseSiputzxDetail(Map<String, dynamic> data, String slug) {
    final ai = data['animeInfo'] is Map<String, dynamic> ? data['animeInfo'] as Map<String, dynamic> : <String, dynamic>{};
    final info = AnimeInfo(
      title: (ai['title'] ?? '').toString(),
      japaneseTitle: ai['japaneseTitle']?.toString(),
      score: ai['score']?.toString(),
      producer: ai['producer']?.toString(),
      type: ai['type']?.toString(),
      status: ai['status']?.toString(),
      totalEpisodes: ai['totalEpisodes']?.toString(),
      duration: ai['duration']?.toString(),
      releaseDate: ai['releaseDate']?.toString(),
      studio: ai['studio']?.toString(),
      genres: ai['genres']?.toString(),
      imageUrl: (ai['imageUrl'] ?? ai['image'])?.toString(),
      slug: slug,
      synopsis: _parseSynopsis(ai['synopsis'] ?? ai['sinopsis'] ?? data['synopsis'] ?? data['sinopsis']),
    );
    final episodes = <AnimeEpisode>[];
    final eps = data['episodes'];
    if (eps is List) {
      for (final e in eps) {
        if (e is! Map) continue;
        final link = (e['link'] ?? '').toString();
        episodes.add(AnimeEpisode(
          title: (e['title'] ?? '').toString(),
          link: link,
          date: e['date']?.toString(),
          slug: _slugFromUrl(link),
        ));
      }
    }
    return AnimeDetail(animeInfo: info, episodes: episodes);
  }

  Future<EpisodePlayData> fetchEpisodePlay({String? episodeSlug, String? episodeUrl}) async {
    final s = (episodeSlug != null && episodeSlug.isNotEmpty)
        ? episodeSlug
        : _slugFromUrl(episodeUrl ?? '');
    if (s == null || s.isEmpty) throw Exception('Slug episode tidak valid');

    try {
      final res = await _get('$_nateeBase/api/episode/$s');
      if (res.statusCode >= 200 && res.statusCode < 300) {
        final decoded = jsonDecode(res.body);
        final play = _parseNateeEpisode(decoded, episodeUrl);
        if (play != null) return play;
      }
    } catch (_) {}

    if (episodeUrl != null && episodeUrl.isNotEmpty) {
      try {
        final uri = Uri.parse('$_siputzxBase/api/anime/otakudesu/download').replace(queryParameters: {'url': episodeUrl});
        final res = await http.get(uri).timeout(_timeout);
        if (res.statusCode >= 200 && res.statusCode < 300) {
          final decoded = jsonDecode(res.body);
          if (decoded is Map && decoded['status'] == true && decoded['data'] is Map) {
            final data = decoded['data'] as Map<String, dynamic>;
            final downloads = <DownloadItem>[];
            final raw = data['downloads'];
            if (raw is List) {
              for (final d in raw) {
                if (d is! Map) continue;
                final link = (d['link'] ?? '').toString();
                if (link.isEmpty) continue;
                downloads.add(DownloadItem(
                  quality: (d['quality'] ?? '').toString(),
                  link: link,
                  host: (d['host'] ?? '').toString(),
                ));
              }
            }
            return EpisodePlayData(
              title: (data['title'] ?? '').toString(),
              streamUrl: null,
              episodePageUrl: episodeUrl,
              downloads: downloads,
            );
          }
        }
      } catch (_) {}
    }

    throw Exception('Gagal memuat link episode.');
  }

  EpisodePlayData? _parseNateeEpisode(dynamic decoded, String? episodeUrl) {
    if (decoded is! Map) return null;
    final data = decoded['data'];
    if (data is! Map) return null;

    final streamUrl = data['stream_url']?.toString();
    final title = (data['episode'] ?? '').toString();
    final downloads = <DownloadItem>[];

    final dl = data['download_urls'];
    if (dl is Map) {
      dl.forEach((format, qualities) {
        if (qualities is! List) return;
        for (final q in qualities) {
          if (q is! Map) continue;
          final resolution = (q['resolution'] ?? '').toString();
          final urls = q['urls'];
          if (urls is! List) continue;
          for (final u in urls) {
            if (u is! Map) continue;
            final url = (u['url'] ?? '').toString();
            if (url.isEmpty) continue;
            final qualityLabel = '${format.toString().toUpperCase()} $resolution'.trim();
            downloads.add(DownloadItem(
              quality: qualityLabel,
              link: url,
              host: (u['provider'] ?? '').toString(),
            ));
          }
        }
      });
    }

    return EpisodePlayData(
      title: title,
      streamUrl: (streamUrl != null && streamUrl.isNotEmpty) ? streamUrl : null,
      episodePageUrl: episodeUrl,
      downloads: downloads,
    );
  }
}

class EpisodePlayData {
  const EpisodePlayData({
    required this.title,
    this.streamUrl,
    this.episodePageUrl,
    required this.downloads,
  });

  final String title;
  final String? streamUrl;
  final String? episodePageUrl;
  final List<DownloadItem> downloads;
}

// ---------------------------------------------------------------------------
// Helpers UI
// ---------------------------------------------------------------------------

Future<void> _openUrl(String url) async {
  final uri = Uri.tryParse(url);
  if (uri == null) return;
  if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
    await launchUrl(uri, mode: LaunchMode.platformDefault);
  }
}

Widget _animePoster(String? url, {double? width, double? height, BorderRadius? radius}) {
  final rad = (radius ?? BorderRadius.circular(12)).topLeft.x;
  return SizedBox(
    width: width,
    height: height,
    child: SmartCover(
      url: url ?? '',
      width: width,
      height: height,
      borderRadius: rad > 0 ? rad : 12,
    ),
  );
}

// ---------------------------------------------------------------------------
// Search Page
// ---------------------------------------------------------------------------

/// Transisi halaman custom: slide dari kanan + fade (halus).
Route<T> _slideFadeRoute<T extends Object?>(Widget page) {
  return PageRouteBuilder<T>(
    pageBuilder: (context, animation, secondaryAnimation) => page,
    transitionDuration: const Duration(milliseconds: 320),
    reverseTransitionDuration: const Duration(milliseconds: 280),
    transitionsBuilder: (context, animation, secondaryAnimation, child) {
      final curved = CurvedAnimation(
        parent: animation,
        curve: Curves.easeOutCubic,
        reverseCurve: Curves.easeInCubic,
      );
      return FadeTransition(
        opacity: curved,
        child: SlideTransition(
          position: Tween<Offset>(
            begin: const Offset(0.08, 0),
            end: Offset.zero,
          ).animate(curved),
          child: child,
        ),
      );
    },
  );
}

class AnimeSearchPage extends StatefulWidget {
  const AnimeSearchPage({super.key, this.initialGenre});

  /// Jika diisi, halaman langsung load list anime genre tersebut
  /// (digunakan saat user menekan chip genre dari halaman pencarian).
  final AnimeGenre? initialGenre;

  @override
  State<AnimeSearchPage> createState() => _AnimeSearchPageState();
}

class _AnimeSearchPageState extends State<AnimeSearchPage> {
  final _controller = TextEditingController();
  final _api = const AnimeApiClient();
  Timer? _debounce;
  int _searchSeq = 0;

  List<AnimeGenre> _genres = [];
  List<AnimeSearchItem> _results = [];
  bool _loading = false;
  bool _loadingGenres = true;
  String? _error;

  /// null = mode pencarian teks; terisi = filter genre aktif
  AnimeGenre? _selectedGenre;
  int _page = 1;
  int _lastPage = 1;
  bool _hasNext = false;
  bool _hasPrev = false;

  /// True jika halaman dibuka khusus untuk satu genre (dari chip).
  bool get _isGenreOnlyMode => widget.initialGenre != null;

  /// Ada teks di kolom cari → sembunyikan list genre
  bool get _isTyping => _controller.text.trim().isNotEmpty;

  @override
  void initState() {
    super.initState();
    _controller.addListener(_onQueryChanged);
    if (widget.initialGenre != null) {
      // Langsung load genre, skip load daftar genre (tidak ditampilkan)
      _loadingGenres = false;
      _selectedGenre = widget.initialGenre;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _selectGenre(widget.initialGenre!, page: 1);
      });
    } else {
      _loadGenres();
    }
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _controller.removeListener(_onQueryChanged);
    _controller.dispose();
    super.dispose();
  }

  void _onQueryChanged() {
    // Sembunyikan genre segera saat ada huruf
    if (mounted) setState(() {});
    _debounce?.cancel();
    final q = _controller.text.trim();
    if (q.isEmpty) {
      // Jangan hapus genre/results saat mode genre.
      // _controller.clear() di _selectGenre ikut memicu listener ini —
      // kalau _selectedGenre di-null-kan, pagination & title ikut hilang.
      if (_selectedGenre != null || widget.initialGenre != null) {
        return;
      }
      setState(() {
        _results = [];
        _allSearchResults = [];
        _error = null;
        _loading = false;
        _selectedGenre = null;
        _page = 1;
        _lastPage = 1;
        _hasNext = false;
        _hasPrev = false;
      });
      return;
    }
    // Live search: tunggu sebentar biar tidak spam API tiap ketikan
    _debounce = Timer(const Duration(milliseconds: 350), () {
      if (mounted) _doSearch(live: true);
    });
  }

  Future<void> _loadGenres() async {
    setState(() => _loadingGenres = true);
    try {
      final list = await _api.fetchGenres();
      if (!mounted) return;
      setState(() {
        _genres = list;
        _loadingGenres = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() => _loadingGenres = false);
    }
  }

  /// Urutkan: awalan query dulu, lalu yang mengandung rangkaian huruf berurutan.
  List<AnimeSearchItem> _rankByPrefix(List<AnimeSearchItem> list, String q) {
    final needle = q.toLowerCase().trim();
    if (needle.isEmpty) return list;
    int score(AnimeSearchItem e) {
      final t = e.title.toLowerCase();
      if (t.startsWith(needle)) return 0;
      // kata di judul yang mulai dengan query
      for (final w in t.split(RegExp(r'[^a-z0-9]+'))) {
        if (w.startsWith(needle)) return 1;
      }
      final idx = t.indexOf(needle);
      if (idx >= 0) return 2 + idx; // semakin di depan semakin bagus
      return 9999;
    }

    final filtered = list.where((e) {
      final t = e.title.toLowerCase();
      return t.contains(needle);
    }).toList();
    filtered.sort((a, b) {
      final sa = score(a);
      final sb = score(b);
      if (sa != sb) return sa.compareTo(sb);
      return a.title.toLowerCase().compareTo(b.title.toLowerCase());
    });
    return filtered;
  }

  /// Semua hasil search (untuk pagination client-side)
  List<AnimeSearchItem> _allSearchResults = [];

  /// Jumlah item per halaman (search & tampilan)
  static const int _pageSize = 12;

  Future<void> _doSearch({bool live = false}) async {
    final q = _controller.text.trim();
    if (q.isEmpty) return;
    final seq = ++_searchSeq;
    setState(() {
      _loading = true;
      _error = null;
      _selectedGenre = null;
      _page = 1;
      _lastPage = 1;
      _hasNext = false;
      _hasPrev = false;
      _allSearchResults = [];
    });
    try {
      if (!live) await SearchSuggest.pushAnime(q);
      var list = await _api.search(q);
      list = _rankByPrefix(list, q);
      if (!mounted || seq != _searchSeq) return;
      final last = list.isEmpty ? 1 : ((list.length - 1) ~/ _pageSize) + 1;
      setState(() {
        _allSearchResults = list;
        _page = 1;
        _lastPage = last;
        _hasNext = last > 1;
        _hasPrev = false;
        _results = list.take(_pageSize).toList();
        _loading = false;
        if (list.isEmpty) {
          _error = null; // tampil empty state, bukan error
        }
      });
    } catch (e) {
      if (!mounted || seq != _searchSeq) return;
      setState(() {
        _error = e.toString().replaceFirst('Exception: ', '');
        _loading = false;
        _results = [];
        _allSearchResults = [];
      });
    }
  }

  Future<void> _selectGenre(AnimeGenre genre, {int page = 1}) async {
    setState(() {
      _loading = true;
      _error = null;
      _selectedGenre = genre;
      _page = page;
      _allSearchResults = [];
      _controller.clear();
    });
    try {
      final result = await _api.fetchByGenre(genre.slug, page: page);
      if (!mounted) return;
      setState(() {
        _results = result.items;
        _page = result.currentPage;
        _lastPage = result.lastPage;
        _hasNext = result.hasNext;
        _hasPrev = result.hasPrev;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = e.toString().replaceFirst('Exception: ', '');
        _loading = false;
        _results = [];
      });
    }
  }

  void _goPage(int page) {
    if (page < 1) return;

    // Mode genre → fetch dari API
    final g = _selectedGenre ?? widget.initialGenre;
    if (g != null) {
      if (page > _lastPage && !(page == _page + 1 && _hasNext)) return;
      _selectGenre(g, page: page);
      return;
    }

    // Mode search → pagination client-side
    if (_allSearchResults.isEmpty) return;
    final last = ((_allSearchResults.length - 1) ~/ _pageSize) + 1;
    if (page > last) return;
    final start = (page - 1) * _pageSize;
    final end = (start + _pageSize).clamp(0, _allSearchResults.length);
    setState(() {
      _page = page;
      _lastPage = last;
      _hasNext = page < last;
      _hasPrev = page > 1;
      _results = _allSearchResults.sublist(start, end);
    });
  }

  /// Nomor halaman yang ditampilkan di bar (maks ~7 tombol)
  List<int> _pageNumbers() {
    if (_lastPage <= 1) return const [1];
    const window = 5;
    int start = _page - (window ~/ 2);
    if (start < 1) start = 1;
    int end = start + window - 1;
    if (end > _lastPage) {
      end = _lastPage;
      start = (end - window + 1).clamp(1, _lastPage);
    }
    return [for (int i = start; i <= end; i++) i];
  }

  Widget _resultTile(AnimeSearchItem item) {
    return Material(
      color: Colors.white.withOpacity(0.08),
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () {
          Navigator.of(context).push(
            _slideFadeRoute(
              AnimeDetailPage(
                animeUrl: item.link,
                titleHint: item.title,
                slug: item.slug,
              ),
            ),
          );
        },
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              _animePoster(item.imageUrl, width: 64, height: 90, radius: BorderRadius.circular(10)),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      item.title,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 15),
                    ),
                    if (item.status != null) ...[
                      const SizedBox(height: 4),
                      Text(item.status!, style: const TextStyle(color: Color(0xFFFFD88A), fontSize: 12)),
                    ],
                    if (item.genres != null) ...[
                      const SizedBox(height: 4),
                      Text(
                        item.genres!,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: Colors.white54, fontSize: 12),
                      ),
                    ],
                    if (item.rating != null) ...[
                      const SizedBox(height: 4),
                      Text('★ ${item.rating}', style: const TextStyle(color: Colors.white70, fontSize: 12)),
                    ],
                  ],
                ),
              ),
              const Icon(Icons.chevron_right, color: Colors.white54),
            ],
          ),
        ),
      ),
    );
  }

  Widget _paginationBar() {
    // Tampilkan jika genre mode ATAU search punya >1 halaman
    final showForSearch =
        _selectedGenre == null &&
        widget.initialGenre == null &&
        _allSearchResults.length > _pageSize;
    final showForGenre = _selectedGenre != null || widget.initialGenre != null;
    if (!showForGenre && !showForSearch) return const SizedBox.shrink();
    if (_results.isEmpty && !_loading) return const SizedBox.shrink();
    final canPrev = (_hasPrev || _page > 1) && !_loading;
    // Genre API: izinkan next jika hasNext ATAU belum di last page
    final canNext = (_hasNext || _page < _lastPage) && !_loading;

    return Material(
      color: const Color(0xFF221A2D),
      elevation: 8,
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
          child: Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: canPrev ? () => _goPage(_page - 1) : null,
                  icon: const Icon(Icons.chevron_left_rounded, size: 20),
                  label: const Text('Sebelumnya'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: const Color(0xFFFFD88A),
                    disabledForegroundColor: Colors.white24,
                    side: BorderSide(
                      color: canPrev ? const Color(0xFFFFD88A) : Colors.white24,
                    ),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Text(
                  '$_page / ${_lastPage < _page ? _page : _lastPage}',
                  style: const TextStyle(
                    color: Color(0xFFFFD88A),
                    fontWeight: FontWeight.w800,
                    fontSize: 14,
                  ),
                ),
              ),
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: canNext ? () => _goPage(_page + 1) : null,
                  icon: const Icon(Icons.chevron_right_rounded, size: 20),
                  label: const Text('Selanjutnya'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor:
                        canNext ? const Color(0xFFFFD88A) : Colors.white12,
                    foregroundColor: const Color(0xFF17121F),
                    disabledForegroundColor: Colors.white38,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final genreName = _selectedGenre?.name ?? widget.initialGenre?.name;
    final modeLabel = genreName != null
        ? 'Genre: $genreName  ·  Halaman $_page/$_lastPage'
        : (_allSearchResults.length > _pageSize
            ? 'Hasil pencarian  ·  Halaman $_page/$_lastPage'
            : null);

    final appBarTitle = _isGenreOnlyMode
        ? (_selectedGenre?.name ?? widget.initialGenre?.name ?? 'Cari Anime')
        : 'Cari Anime';

    return Scaffold(
      backgroundColor: const Color(0xFF17121F),
      appBar: AppBar(
        backgroundColor: Colors.black54,
        foregroundColor: Colors.white,
        title: Text(appBarTitle, style: const TextStyle(fontWeight: FontWeight.w800)),
        elevation: 0,
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Search bar — disembunyikan di mode genre-only
          if (!_isGenreOnlyMode)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _controller,
                      style: const TextStyle(color: Colors.white),
                      cursorColor: const Color(0xFFFFD88A),
                      textInputAction: TextInputAction.search,
                      onSubmitted: (_) => _doSearch(),
                      decoration: InputDecoration(
                        hintText: 'Judul anime...',
                        hintStyle: const TextStyle(color: Colors.white54),
                        filled: true,
                        fillColor: Colors.white.withOpacity(0.1),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(16),
                          borderSide: BorderSide.none,
                        ),
                        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                        prefixIcon: const Icon(Icons.search, color: Color(0xFFFFD88A)),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Material(
                    color: const Color(0xFFFFD88A),
                    borderRadius: BorderRadius.circular(14),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(14),
                      onTap: _loading ? null : _doSearch,
                      child: const Padding(
                        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                        child: Icon(Icons.search_rounded, color: Color(0xFF17121F)),
                      ),
                    ),
                  ),
                ],
              ),
            ),

          // Genre chips — deret ke bawah (Wrap)
          // Tidak ditampilkan jika halaman dibuka khusus untuk satu genre
          if (!_isGenreOnlyMode && !_isTyping) ...[
            if (_loadingGenres)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 8),
                child: Center(
                  child: SizedBox(
                    width: 22,
                    height: 22,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFFFFD88A)),
                  ),
                ),
              )
            else if (_genres.isNotEmpty)
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 4),
                child: Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: _genres.map((g) {
                    final selected = _selectedGenre?.slug == g.slug;
                    return Material(
                      color: selected ? const Color(0xFFFFD88A) : Colors.white.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(20),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(20),
                        onTap: _loading
                            ? null
                            : () {
                                // Langsung buka halaman list anime sesuai genre
                                // dengan animasi slide + fade
                                Navigator.of(context).push(
                                  _slideFadeRoute(
                                    AnimeSearchPage(initialGenre: g),
                                  ),
                                );
                              },
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                          child: Text(
                            g.name,
                            style: TextStyle(
                              color: selected ? const Color(0xFF17121F) : Colors.white,
                              fontWeight: FontWeight.w700,
                              fontSize: 13,
                            ),
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ),
          ],

          if (modeLabel != null)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
              child: Text(modeLabel, style: const TextStyle(color: Colors.white54, fontSize: 12)),
            ),

          const SizedBox(height: 8),

          if (_loading)
            const Expanded(child: Center(child: CircularProgressIndicator(color: Color(0xFFFFD88A))))
          else if (_error != null)
            Expanded(
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Text(_error!, style: const TextStyle(color: Colors.white70), textAlign: TextAlign.center),
                ),
              ),
            )
          else if (_results.isEmpty)
            Expanded(
              child: Center(
                child: Text(
                  _isGenreOnlyMode
                      ? 'Tidak ada anime untuk genre ini'
                      : (_isTyping
                          ? 'Tidak ada anime yang cocok'
                          : 'Cari judul atau pilih genre di atas'),
                  style: const TextStyle(color: Colors.white54),
                  textAlign: TextAlign.center,
                ),
              ),
            )
          else
            Expanded(
              child: ListView.separated(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
                itemCount: _results.length,
                separatorBuilder: (_, __) => const SizedBox(height: 12),
                itemBuilder: (context, i) => _resultTile(_results[i]),
              ),
            ),

          // Pagination (genre mode)
          _paginationBar(),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Detail Page
// ---------------------------------------------------------------------------

class AnimeDetailPage extends StatefulWidget {
  const AnimeDetailPage({super.key, required this.animeUrl, this.titleHint, this.slug});

  final String animeUrl;
  final String? titleHint;
  final String? slug;

  @override
  State<AnimeDetailPage> createState() => _AnimeDetailPageState();
}

class _AnimeDetailPageState extends State<AnimeDetailPage> {
  final _api = const AnimeApiClient();
  AnimeDetail? _detail;
  bool _loading = true;
  String? _error;
  bool _isFav = false;

  String get _animeId {
    final info = _detail?.animeInfo;
    return (info?.slug ??
            widget.slug ??
            _slugFromUrl(widget.animeUrl) ??
            widget.animeUrl)
        .trim();
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _refreshFav() async {
    final id = _animeId;
    if (id.isEmpty) return;
    final on = await AnimeFavoriteStore.isFavorite(id);
    if (mounted) setState(() => _isFav = on);
  }


  Future<void> _batchEnqueue() async {
    final d = _detail;
    if (d == null || d.episodes.isEmpty) return;
    final savedPref = await DownloadQualityPref.get();

    // Dialog pilih resolusi (sama seperti unduh per-episode)
    final selected = await showDialog<String>(
      context: context,
      builder: (ctx) {
        var pick = savedPref; // '' | 360 | 480 | 720 | 1080
        return StatefulBuilder(
          builder: (ctx, setLocal) => AlertDialog(
            backgroundColor: const Color(0xFF241C2C),
            title: const Text(
              'Batch unduh',
              style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800),
            ),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Antrikan ${d.episodes.length} episode via acefile.co.\nPilih resolusi:',
                  style: const TextStyle(color: Colors.white70, height: 1.4),
                ),
                const SizedBox(height: 14),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    for (final q in ['', '360', '480', '720', '1080'])
                      ChoiceChip(
                        label: Text(q.isEmpty ? 'Otomatis' : '${q}p'),
                        selected: pick == q,
                        onSelected: (_) => setLocal(() => pick = q),
                        selectedColor: const Color(0xFFFFD88A),
                        labelStyle: TextStyle(
                          color: pick == q ? Colors.black : Colors.white70,
                          fontWeight: FontWeight.w700,
                        ),
                        backgroundColor: const Color(0xFF2A2233),
                      ),
                  ],
                ),
                const SizedBox(height: 8),
                const Text(
                  'Buka Antrian unduhan di beranda untuk progress.',
                  style: TextStyle(color: Colors.white38, fontSize: 12),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('Batal', style: TextStyle(color: Colors.white54)),
              ),
              TextButton(
                onPressed: () => Navigator.pop(ctx, pick),
                child: const Text(
                  'Antrikan',
                  style: TextStyle(
                    color: Color(0xFFFFD88A),
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
    if (selected == null || !mounted) return;
    final pref = selected;
    // Simpan pilihan sebagai default batch berikutnya
    await DownloadQualityPref.set(pref);

    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(
        child: CircularProgressIndicator(color: Color(0xFFFFD88A)),
      ),
    );

    final api = const AnimeApiClient();
    final items = <QueueItem>[];
    var okCount = 0;
    var failCount = 0;

    for (final ep in d.episodes) {
      try {
        final play = await api.fetchEpisodePlay(
          episodeSlug: ep.slug,
          episodeUrl: ep.link,
        );
        final ace = <DownloadItem>[
          for (final dl in play.downloads)
            if (dl.host.toLowerCase().contains('acefile') ||
                dl.link.toLowerCase().contains('acefile'))
              dl,
        ];
        final pool = ace.isNotEmpty ? ace : play.downloads;
        final byQ = <String, List<DownloadItem>>{};
        for (final dl in pool) {
          byQ.putIfAbsent(dl.quality, () => []).add(dl);
        }
        String? pickedQ;
        if (pref.isNotEmpty) {
          for (final k in byQ.keys) {
            if (k.toLowerCase().contains(pref)) {
              pickedQ = k;
              break;
            }
          }
        }
        pickedQ ??= DownloadQualityPref.pickPreferred(byQ.keys, pref);
        if (pickedQ == null || !byQ.containsKey(pickedQ)) {
          failCount++;
          continue;
        }
        final links = [
          for (final dl in byQ[pickedQ]!)
            DlLink(
              quality: dl.quality,
              link: dl.link,
              host: dl.host.isNotEmpty ? dl.host : 'acefile',
            ),
        ];
        links.sort((a, b) {
          final ap = a.host.toLowerCase().contains('acefile') ||
                  a.link.contains('acefile')
              ? 0
              : 1;
          final bp = b.host.toLowerCase().contains('acefile') ||
                  b.link.contains('acefile')
              ? 0
              : 1;
          return ap.compareTo(bp);
        });
        items.add(QueueItem(
          id: 'batch:${ep.slug ?? ep.link}:$pickedQ',
          episodeTitle: ep.title,
          quality: pickedQ,
          links: links,
          animeTitle: d.animeInfo.title,
          coverUrl: d.animeInfo.imageUrl ?? '',
          seriesKey: 'anime:$_animeId',
          episodeSlug: ep.slug,
        ));
        okCount++;
      } catch (_) {
        failCount++;
      }
    }

    if (mounted) Navigator.of(context).pop();

    if (items.isEmpty) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Tidak ada link acefile untuk diantrikan')),
      );
      return;
    }

    await DownloadQueue.instance.enqueueMany(items);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          '$okCount episode masuk antrian (acefile'
          '${pref.isEmpty ? "" : " ${pref}p"})'
          '${failCount > 0 ? ", $failCount gagal" : ""}',
        ),
      ),
    );
  }


  Future<void> _toggleFav() async {
    final d = _detail;
    if (d == null) return;
    final id = _animeId;
    if (id.isEmpty) return;
    final info = d.animeInfo;
    final latest = AnimeFavoriteStore.latestLabel(d.episodes);
    final count = AnimeFavoriteStore.countEps(d.episodes);

    if (_isFav) {
      await AnimeFavoriteStore.remove(id);
      await BookmarkStore.remove(id, kind: 'anime');
      if (!mounted) return;
      setState(() => _isFav = false);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Dihapus dari favorit')),
      );
    } else {
      await AnimeFavoriteStore.add(AnimeFavorite(
        id: id,
        title: info.title.isNotEmpty ? info.title : (widget.titleHint ?? 'Anime'),
        coverUrl: info.imageUrl ?? '',
        link: widget.animeUrl,
        latestEpisode: latest.isNotEmpty ? latest : null,
        episodeCount: count > 0 ? count : null,
      ));
      await BookmarkStore.add(LibraryEntry(
        id: id,
        title: info.title.isNotEmpty ? info.title : (widget.titleHint ?? 'Anime'),
        coverUrl: info.imageUrl ?? '',
        kind: 'anime',
        subtitle: info.genres,
        progress: latest.isNotEmpty ? latest : null,
        extra: {'link': widget.animeUrl},
      ));
      try {
        ApiSync.pushBookmarks(await BookmarkStore.list());
      } catch (_) {}
      if (!mounted) return;
      setState(() => _isFav = true);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Ditambahkan ke favorit')),
      );
    }
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final d = await _api.fetchDetail(slug: widget.slug, animeUrl: widget.animeUrl);
      if (!mounted) return;
      setState(() {
        _detail = d;
        _loading = false;
      });
      final info = d.animeInfo;
      final id = (info.slug ?? widget.slug ?? _slugFromUrl(widget.animeUrl) ?? widget.animeUrl);
      await HistoryStore.add(LibraryEntry(
        id: id,
        title: info.title.isNotEmpty ? info.title : (widget.titleHint ?? 'Anime'),
        coverUrl: info.imageUrl ?? '',
        kind: 'anime',
        subtitle: info.genres,
        progress: d.episodes.isNotEmpty ? d.episodes.first.title : null,
        extra: {'link': widget.animeUrl},
      ));
      ApiSync.pushHistory(await HistoryStore.list());
      await _refreshFav();
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = AppErrors.describe(e);
        _loading = false;
      });
    }
  }

  void _openEpisode(AnimeEpisode ep) {
    Navigator.of(context).push(
      _slideFadeRoute(
        EpisodeDownloadPage(
          episodeUrl: ep.link,
          episodeTitle: ep.title,
          episodeSlug: ep.slug,
          animeTitle: _detail?.animeInfo.title.isNotEmpty == true
              ? _detail!.animeInfo.title
              : widget.titleHint,
          coverUrl: _detail?.animeInfo.imageUrl,
          seriesKey: () {
            final s = _detail?.animeInfo.slug ??
                widget.slug ??
                ep.slug ??
                widget.animeUrl;
            return s == null || s.isEmpty ? null : 'anime:$s';
          }(),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final title = _detail?.animeInfo.title.isNotEmpty == true
        ? _detail!.animeInfo.title
        : (widget.titleHint ?? 'Detail Anime');

    return Scaffold(
      backgroundColor: const Color(0xFF17121F),
      appBar: AppBar(
        backgroundColor: Colors.black54,
        foregroundColor: Colors.white,
        title: Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800)),
        elevation: 0,
        actions: [
          if (_detail != null)
            IconButton(
              tooltip: _isFav ? 'Hapus favorit' : 'Tambah favorit',
              onPressed: _toggleFav,
              icon: Icon(
                _isFav ? Icons.bookmark_rounded : Icons.bookmark_border_rounded,
                color: _isFav ? const Color(0xFFFFD88A) : Colors.white,
              ),
            ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: Color(0xFFFFD88A)))
          : _error != null
              ? Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(_error!, style: const TextStyle(color: Colors.white70), textAlign: TextAlign.center),
                      const SizedBox(height: 16),
                      TextButton(
                        onPressed: _load,
                        style: TextButton.styleFrom(foregroundColor: const Color(0xFFFFD88A)),
                        child: const Text('Coba lagi'),
                      ),
                    ],
                  ),
                )
              : _buildContent(),
    );
  }

  Widget _buildContent() {
    final info = _detail!.animeInfo;
    final episodes = _detail!.episodes;

    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _animePoster(info.imageUrl, width: 120, height: 170, radius: BorderRadius.circular(14)),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(info.title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 18)),
                      if (info.japaneseTitle != null && info.japaneseTitle!.isNotEmpty) ...[
                        const SizedBox(height: 4),
                        Text(info.japaneseTitle!, style: const TextStyle(color: Colors.white54, fontSize: 13)),
                      ],
                      const SizedBox(height: 10),
                      Wrap(
                        spacing: 6,
                        runSpacing: 6,
                        children: [
                          if (info.score != null) _chip('★ ${info.score}'),
                          if (info.status != null) _chip(info.status!),
                          if (info.type != null) _chip(info.type!),
                          if (info.totalEpisodes != null) _chip('${info.totalEpisodes} eps'),
                        ],
                      ),
                      if (info.studio != null) ...[
                        const SizedBox(height: 6),
                        Text('Studio: ${info.studio}', style: const TextStyle(color: Colors.white70, fontSize: 12)),
                      ],
                      if (info.genres != null) ...[
                        const SizedBox(height: 4),
                        Text(info.genres!, style: const TextStyle(color: Colors.white54, fontSize: 12)),
                      ],
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        if (info.synopsis != null && info.synopsis!.isNotEmpty)
         
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 4),
              child: _SynopsisBox(text: info.synopsis!),
            ),
          ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 20, 16, 8),
            child: Row(
              children: [
                const Expanded(
                  child: Text('Daftar Episode', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 17)),
                ),
                if (episodes.isNotEmpty)
                  TextButton.icon(
                    onPressed: _batchEnqueue,
                    icon: const Icon(Icons.playlist_add, color: Color(0xFFFFD88A), size: 18),
                    label: const Text('Batch unduh', style: TextStyle(color: Color(0xFFFFD88A), fontWeight: FontWeight.w700, fontSize: 12)),
                  ),
              ],
            ),
          ),
        ),
        if (episodes.isEmpty)
          const SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.all(24),
              child: Text('Belum ada episode', style: TextStyle(color: Colors.white54), textAlign: TextAlign.center),
            ),
          )
        else
          SliverList(
            delegate: SliverChildBuilderDelegate(
              (context, i) {
                final ep = episodes[i];
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
                  child: Material(
                    color: Colors.white.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(14),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(14),
                      onTap: () => _openEpisode(ep),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                        child: Row(
                          children: [
                            Container(
                              width: 40,
                              height: 40,
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.12),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: const Icon(Icons.play_arrow_rounded, color: Color(0xFFFFD88A)),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    ep.title,
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 14),
                                  ),
                                  if (ep.date != null && ep.date!.isNotEmpty) ...[
                                    const SizedBox(height: 3),
                                    Text(ep.date!, style: const TextStyle(color: Colors.white54, fontSize: 12)),
                                  ],
                                ],
                              ),
                            ),
                            const Icon(Icons.chevron_right, color: Colors.white54, size: 20),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              },
              childCount: episodes.length,
            ),
          ),
        const SliverToBoxAdapter(child: SizedBox(height: 28)),
      ],
    );
  }

  Widget _chip(String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.12),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white24),
      ),
      child: Text(text, style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600)),
    );
  }
}

/// Kotak sinopsis dengan tombol selengkapnya / ringkas
class _SynopsisBox extends StatefulWidget {
  const _SynopsisBox({required this.text});

  final String text;

  @override
  State<_SynopsisBox> createState() => _SynopsisBoxState();
}

class _SynopsisBoxState extends State<_SynopsisBox> {
  bool _expanded = false;

  @override
  Widget build(BuildContext context) {
    final text = widget.text.trim();
    final long = text.length > 220;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.08),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Sinopsis',
            style: TextStyle(color: Color(0xFFFFD88A), fontWeight: FontWeight.w800, fontSize: 14),
          ),
          const SizedBox(height: 8),
          Text(
            text,
            maxLines: _expanded || !long ? null : 4,
            overflow: _expanded || !long ? TextOverflow.visible : TextOverflow.ellipsis,
            style: const TextStyle(color: Colors.white70, fontSize: 13, height: 1.45),
          ),
          if (long) ...[
            const SizedBox(height: 6),
            GestureDetector(
              onTap: () => setState(() => _expanded = !_expanded),
              child: Text(
                _expanded ? 'Sembunyikan' : 'Selengkapnya',
                style: const TextStyle(
                  color: Color(0xFFFFD88A),
                  fontWeight: FontWeight.w700,
                  fontSize: 13,
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// In-app Player (WebView) + kontrol play/pause, ±10s, fullscreen 16:9
// ---------------------------------------------------------------------------

class AnimePlayerPage extends StatefulWidget {
  const AnimePlayerPage({
    super.key,
    required this.streamUrl,
    required this.title,
    this.altUrls = const [],
  });

  final String streamUrl;
  final String title;
  final List<String> altUrls;

  @override
  State<AnimePlayerPage> createState() => _AnimePlayerPageState();
}

class _AnimePlayerPageState extends State<AnimePlayerPage> {
  late final WebViewController _controller;
  bool _loading = true;
  String? _error;
  bool _fullscreen = false;
  bool _showControls = true;

  static const _headers = {
    'User-Agent':
        'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
    'Referer': 'https://otakudesu.blog/',
  };

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF000000))
      ..enableZoom(false)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (_) {
            if (mounted) {
              setState(() {
                _loading = true;
                _error = null;
              });
            }
          },
          onPageFinished: (_) async {
            if (!mounted) return;
            setState(() => _loading = false);
            // Coba rapikan tampilan video agar lebih mengisi layar
            await _controller.runJavaScript(r'''
(function(){
  var style = document.createElement('style');
  style.innerHTML = 'video{max-width:100%!important;max-height:100vh!important;width:100%!important;height:auto!important;object-fit:contain!important;} body{margin:0!important;background:#000!important;overflow:hidden!important;}';
  document.head.appendChild(style);
  var v = document.querySelector('video');
  if (v) { try { v.setAttribute('playsinline',''); v.play(); } catch(e){} }
})();
''');
          },
          onWebResourceError: (error) {
            if (mounted && _loading) {
              setState(() {
                _loading = false;
                _error = error.description;
              });
            }
          },
        ),
      )
      ..loadRequest(Uri.parse(widget.streamUrl), headers: _headers);

    // Jangan auto-miring: landscape hanya setelah tekan fullscreen
    _fullscreen = false;
  }

  @override
  void dispose() {
    // Kembalikan orientasi & system UI
    SystemChrome.setPreferredOrientations(const [
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  Future<void> _runOnVideo(String action) async {
    // action: 'toggle' | 'back' | 'forward'
    final js = '''
(function(){
  function findVideo(){
    var el = document.querySelector('video');
    if (el) return el;
    var iframes = document.querySelectorAll('iframe');
    for (var i=0;i<iframes.length;i++){
      try {
        var d = iframes[i].contentDocument || iframes[i].contentWindow.document;
        el = d.querySelector('video');
        if (el) return el;
      } catch(e){}
    }
    return null;
  }
  function clickPlayUi(){
    var sels = [
      'button[aria-label*="Play"]','button[aria-label*="play"]',
      '.vjs-big-play-button','.vjs-play-control','.ytp-large-play-button',
      '.play-button','.btn-play','[class*="play"]'
    ];
    for (var s=0;s<sels.length;s++){
      var b = document.querySelector(sels[s]);
      if (b) { try { b.click(); return true; } catch(e){} }
    }
    return false;
  }
  var v = findVideo();
  var a = '$action';
  if (!v) {
    if (a === 'toggle' && clickPlayUi()) return 'playing';
    return 'novideo';
  }
  if (a === 'toggle') {
    if (v.paused) { try { v.play(); } catch(e){} return 'playing'; }
    v.pause(); return 'paused';
  }
  if (a === 'back') { v.currentTime = Math.max(0, (v.currentTime||0) - 10); return 'ok'; }
  if (a === 'forward') { v.currentTime = (v.currentTime||0) + 10; return 'ok'; }
  return 'ok';
})();
''';
    try {
      final result = await _controller.runJavaScriptReturningResult(js);
      final s = result.toString().replaceAll('"', '');
      if (s == 'novideo' && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Ketuk tombol ▶ di tengah video untuk mulai'),
            duration: Duration(seconds: 2),
            backgroundColor: Colors.black87,
          ),
        );
      }
    } catch (_) {
      // diam — user bisa ketuk player langsung
    }
  }

  Future<void> _toggleFullscreen() async {
    final next = !_fullscreen;
    setState(() => _fullscreen = next);
    if (next) {
      await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
      await SystemChrome.setPreferredOrientations(const [
        DeviceOrientation.landscapeLeft,
        DeviceOrientation.landscapeRight,
      ]);
    } else {
      await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
      await SystemChrome.setPreferredOrientations(const [
        DeviceOrientation.portraitUp,
      ]);
      // Izinkan semua lagi setelah sedikit delay
      Future.delayed(const Duration(milliseconds: 300), () {
        SystemChrome.setPreferredOrientations(const [
          DeviceOrientation.portraitUp,
          DeviceOrientation.portraitDown,
          DeviceOrientation.landscapeLeft,
          DeviceOrientation.landscapeRight,
        ]);
      });
    }
  }

  void _reload() {
    setState(() {
      _loading = true;
      _error = null;
    });
    _controller.loadRequest(Uri.parse(widget.streamUrl), headers: _headers);
  }

  @override
  Widget build(BuildContext context) {
    // Video 16:9 + judul episode di bawah player
    final video = AspectRatio(
      aspectRatio: 16 / 9,
      child: WebViewWidget(controller: _controller),
    );

    final playerBlock = Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        video,
        if (!_fullscreen) ...[
          const SizedBox(height: 14),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              widget.title,
              textAlign: TextAlign.center,
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w800,
                fontSize: 15,
                height: 1.3,
              ),
            ),
          ),
        ],
      ],
    );

    final body = Stack(
      fit: StackFit.expand,
      children: [
        const ColoredBox(color: Colors.black),
        Center(child: playerBlock),

        if (_error != null)
          ColoredBox(
            color: Colors.black87,
            child: Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.error_outline, color: Colors.white54, size: 48),
                    const SizedBox(height: 12),
                    Text(
                      'Gagal memuat player\n$_error',
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Colors.white70),
                    ),
                    const SizedBox(height: 16),
                    TextButton(
                      onPressed: _reload,
                      style: TextButton.styleFrom(foregroundColor: const Color(0xFFFFD88A)),
                      child: const Text('Coba lagi'),
                    ),
                  ],
                ),
              ),
            ),
          ),

        if (_loading && _error == null)
          const ColoredBox(
            color: Colors.black54,
            child: Center(child: CircularProgressIndicator(color: Color(0xFFFFD88A))),
          ),

        // Top bar
        if (_showControls || _loading)
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: SafeArea(
              bottom: false,
              child: Container(
                padding: const EdgeInsets.fromLTRB(4, 0, 4, 8),
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.black87, Colors.transparent],
                  ),
                ),
                child: Row(
                  children: [
                    IconButton(
                      onPressed: () async {
                        if (_fullscreen) await _toggleFullscreen();
                        if (mounted) Navigator.of(context).pop();
                      },
                      icon: const Icon(Icons.arrow_back_rounded, color: Colors.white),
                    ),
                    Expanded(
                      child: Text(
                        widget.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 14),
                      ),
                    ),
                    IconButton(
                      tooltip: 'Muat ulang',
                      onPressed: _reload,
                      icon: const Icon(Icons.refresh_rounded, color: Colors.white70),
                    ),
                  ],
                ),
              ),
            ),
          ),

        // Bottom controls: -10s | play/pause | +10s | fullscreen
        if (_showControls && !_loading && _error == null)
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: SafeArea(
              top: false,
              child: Container(
                padding: const EdgeInsets.fromLTRB(12, 20, 12, 12),
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.bottomCenter,
                    end: Alignment.topCenter,
                    colors: [Colors.black87, Colors.transparent],
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    _CtrlBtn(
                      icon: _fullscreen ? Icons.fullscreen_exit_rounded : Icons.fullscreen_rounded,
                      label: _fullscreen ? 'Keluar' : 'Full',
                      onTap: _toggleFullscreen,
                    ),
                  ],
                ),
              ),
            ),
          ),
      ],
    );

    return Scaffold(
      backgroundColor: Colors.black,
      // Sembunyikan AppBar bawaan; pakai overlay sendiri
      body: body,
    );
  }
}

class _CtrlBtn extends StatelessWidget {
  const _CtrlBtn({
    required this.icon,
    required this.label,
    required this.onTap,
    this.big = false,
  });

  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool big;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(40),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, color: const Color(0xFFFFD88A), size: big ? 48 : 32),
              const SizedBox(height: 2),
              Text(label, style: const TextStyle(color: Colors.white70, fontSize: 11, fontWeight: FontWeight.w600)),
            ],
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Episode Download / Watch Page
// ---------------------------------------------------------------------------

class EpisodeDownloadPage extends StatefulWidget {
  const EpisodeDownloadPage({
    super.key,
    required this.episodeUrl,
    required this.episodeTitle,
    this.episodeSlug,
    this.animeTitle,
    this.coverUrl,
    this.seriesKey,
  });

  final String episodeUrl;
  final String episodeTitle;
  final String? episodeSlug;
  final String? animeTitle;
  final String? coverUrl;
  final String? seriesKey;

  @override
  State<EpisodeDownloadPage> createState() => _EpisodeDownloadPageState();
}

class _EpisodeDownloadPageState extends State<EpisodeDownloadPage> {
  final _api = const AnimeApiClient();
  EpisodePlayData? _data;
  bool _loading = true;
  String? _error;
  final Set<String> _downloading = {};
  String _batchQuality = ''; // '' | 360 | 480 | 720 | 1080

  WebViewController? _player;
  bool _playerLoading = false;
  bool _playerSettled = false;
  bool _fullscreen = false;
  String? _playerError;
  Timer? _playerTimeout;

  static const _playerHeaders = {
    'User-Agent':
        'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
    'Referer': 'https://otakudesu.blog/',
  };

  @override
  void initState() {
    super.initState();
    DownloadQualityPref.get().then((q) {
      if (mounted) setState(() => _batchQuality = q);
    });
    _load();
  }

  @override
  void dispose() {
    _playerTimeout?.cancel();
    // Kembalikan orientasi ke normal
    SystemChrome.setPreferredOrientations(const [
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  Future<void> _setFullscreen(bool on) async {
    if (!mounted) return;
    setState(() => _fullscreen = on);
    if (on) {
      await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
      await SystemChrome.setPreferredOrientations(const [
        DeviceOrientation.landscapeLeft,
        DeviceOrientation.landscapeRight,
      ]);
    } else {
      await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
      await SystemChrome.setPreferredOrientations(const [
        DeviceOrientation.portraitUp,
      ]);
      Future.delayed(const Duration(milliseconds: 280), () {
        SystemChrome.setPreferredOrientations(const [
          DeviceOrientation.portraitUp,
          DeviceOrientation.portraitDown,
          DeviceOrientation.landscapeLeft,
          DeviceOrientation.landscapeRight,
        ]);
      });
    }
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
      _player = null;
      _playerError = null;
    });
    try {
      final d = await _api.fetchEpisodePlay(
        episodeSlug: widget.episodeSlug,
        episodeUrl: widget.episodeUrl,
      );
      if (!mounted) return;
      setState(() {
        _data = d;
        _loading = false;
      });
      final stream = d.streamUrl;
      if (stream != null && stream.isNotEmpty) {
        _initPlayer(stream);
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = e.toString().replaceFirst('Exception: ', '');
        _loading = false;
      });
    }
  }

  void _markPlayerReady() {
    _playerTimeout?.cancel();
    _playerTimeout = null;
    if (!mounted) return;
    if (_playerSettled && !_playerLoading) return;
    setState(() {
      _playerLoading = false;
      _playerSettled = true;
    });
    // Landscape hanya setelah user tekan fullscreen — tidak auto di halaman ini
  }

  void _initPlayer(String url) {
    _playerTimeout?.cancel();
    setState(() {
      _playerLoading = true;
      _playerSettled = false;
      _playerError = null;
    });

    // Jangan biarkan spinner stuck selamanya
    _playerTimeout = Timer(const Duration(seconds: 12), () {
      if (!mounted || _playerSettled) return;
      setState(() {
        _playerLoading = false;
        _playerSettled = true;
        // jangan set error — biarkan user ketuk play di player
      });
    });

    late final WebViewController controller;
    controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF000000))
      ..enableZoom(false)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (_) {
            // Hanya loading di load pertama; navigasi iframe tidak usah spinner lagi
            if (!mounted || _playerSettled) return;
            setState(() => _playerLoading = true);
          },
          onProgress: (progress) {
            if (!mounted || _playerSettled) return;
            if (progress >= 80) _markPlayerReady();
          },
          onPageFinished: (_) async {
            if (!mounted) return;
            _markPlayerReady();
            try {
              await controller.runJavaScript(
                "(function(){var s=document.createElement('style');s.innerHTML='video,iframe{max-width:100%!important;width:100%!important;height:100%!important;object-fit:contain!important;}body{margin:0!important;background:#000!important;overflow:hidden!important;}';document.head.appendChild(s);var v=document.querySelector('video');if(v){try{v.setAttribute('playsinline','');v.setAttribute('controls','controls');v.play();}catch(e){}}})();",
              );
            } catch (_) {}
          },
          onWebResourceError: (error) {
            // Error resource (iklan/subtitle) jangan matikan player
            if (!mounted || _playerSettled) return;
            // Resource error (iklan/script) diabaikan; jangan stuck loading
            if (!_playerSettled) {
              _playerTimeout?.cancel();
              setState(() {
                _playerLoading = false;
                _playerSettled = true;
              });
            }
          },
          onNavigationRequest: (req) {
            final u = req.url.toLowerCase();
            // Blok skema non-http (intent, market, dll) biar tidak loncat app lain
            if (u.startsWith('http://') || u.startsWith('https://') || u.startsWith('about:')) {
              return NavigationDecision.navigate;
            }
            return NavigationDecision.prevent;
          },
        ),
      )
      ..loadRequest(Uri.parse(url), headers: _playerHeaders);

    setState(() => _player = controller);
  }


  String? _pixeldrainId(String url) {
    final u = Uri.tryParse(url);
    if (u != null) {
      final host = u.host.toLowerCase();
      if (host.contains('pixeldrain') || host.contains('pdrain')) {
        final segs = u.pathSegments.where((s) => s.isNotEmpty).toList();
        for (var i = 0; i < segs.length; i++) {
          if ((segs[i] == 'u' || segs[i] == 'file' || segs[i] == 'l') &&
              i + 1 < segs.length) {
            final id = segs[i + 1];
            if (RegExp(r'^[A-Za-z0-9]+$').hasMatch(id)) return id;
          }
        }
        if (segs.isNotEmpty && RegExp(r'^[A-Za-z0-9]+$').hasMatch(segs.last)) {
          return segs.last;
        }
      }
    }
    final m = RegExp(
      r'pixeldrain\.com/(?:u|file|l)/([A-Za-z0-9]+)',
      caseSensitive: false,
    ).firstMatch(url);
    return m?.group(1);
  }

  bool _looksLikeVideoUrl(String url) {
    final p = url.toLowerCase();
    return p.contains('.mp4') ||
        p.contains('.mkv') ||
        p.contains('.avi') ||
        p.contains('.ts') ||
        p.contains('/api/file/') ||
        p.contains('googlevideo.com') ||
        p.contains('download-token/') ||
        p.contains('force-download/');
  }

  String? _filedonSlug(String url) {
    final u = Uri.tryParse(url);
    if (u == null) return null;
    final host = u.host.toLowerCase();
    if (!host.contains('filedon')) return null;
    final segs = u.pathSegments.where((s) => s.isNotEmpty).toList();
    if (segs.isEmpty) return null;
    // /view/{slug}, /download/{slug}, /force-download/{slug}, /embed/{slug}, /{slug}
    final skip = {'view', 'download', 'force-download', 'embed', 'f', 'file', 'd'};
    if (segs.length >= 2 && skip.contains(segs.first.toLowerCase())) {
      return segs[1];
    }
    return segs.first;
  }

  /// Filedon: alur asli UI
  /// 1) buka /view/{slug} (CSRF + cookie)
  /// 2) tunggu ~6 detik (countdown "Preparing your download")
  /// 3) POST /download/{slug} (Inertia) → flash.download_url (signed R2)
  Future<String?> _resolveFiledon(String raw) async {
    final url = raw.trim();
    final slug = _filedonSlug(url);
    if (slug == null || slug.isEmpty) return null;

    final ua =
        'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36';
    final viewUrl = url.contains('/view/')
        ? url
        : 'https://filedon.co/view/$slug';

    try {
      // 1) Halaman view → CSRF + cookie
      final viewRes = await http
          .get(
            Uri.parse(viewUrl),
            headers: {
              'User-Agent': ua,
              'Accept': 'text/html,application/xhtml+xml',
              'Referer': 'https://filedon.co/',
            },
          )
          .timeout(const Duration(seconds: 20));

      if (viewRes.statusCode < 200 || viewRes.statusCode >= 400) {
        return null;
      }

      final body = viewRes.body;
      String? csrf;
      final csrfMeta = RegExp(
        r'name="csrf-token"\s+content="([^"]+)"',
        caseSensitive: false,
      ).firstMatch(body);
      if (csrfMeta != null) csrf = csrfMeta.group(1);

      String? inertiaVersion;
      final dataPage = RegExp(
        r'data-page="([^"]+)"',
        caseSensitive: false,
      ).firstMatch(body);
      if (dataPage != null) {
        final rawJson = dataPage
            .group(1)!
            .replaceAll('&quot;', '"')
            .replaceAll('&amp;', '&')
            .replaceAll('&#039;', "'")
            .replaceAll('&lt;', '<')
            .replaceAll('&gt;', '>');
        try {
          final decoded = jsonDecode(rawJson);
          if (decoded is Map) {
            inertiaVersion = decoded['version']?.toString();
            final flash = decoded['props']?['flash'];
            if (flash is Map && flash['_token'] != null) {
              csrf ??= flash['_token'].toString();
            }
          }
        } catch (_) {}
      }

      final sc = viewRes.headers['set-cookie'] ?? '';
      String? xsrf;
      final xsrfMatch = RegExp(r'XSRF-TOKEN=([^;,\s]+)').firstMatch(sc);
      if (xsrfMatch != null) {
        xsrf = Uri.decodeComponent(xsrfMatch.group(1)!);
      }
      final sessionMatch =
          RegExp(r'(filedon[^=;\s]*=[^;,\s]+)').firstMatch(sc);
      final cookieHeader = [
        if (xsrfMatch != null) 'XSRF-TOKEN=${xsrfMatch.group(1)}',
        if (sessionMatch != null) sessionMatch.group(1)!,
      ].join('; ');

      // 2) Countdown UI ads-on = 5 detik
      await Future<void>.delayed(const Duration(seconds: 6));

      // 3) POST Inertia /download/{slug}
      final postHeaders = <String, String>{
        'User-Agent': ua,
        'Accept': 'text/html, application/xhtml+xml',
        'Content-Type': 'application/json',
        'X-Requested-With': 'XMLHttpRequest',
        'X-Inertia': 'true',
        if (inertiaVersion != null && inertiaVersion.isNotEmpty)
          'X-Inertia-Version': inertiaVersion,
        if (csrf != null) 'X-CSRF-TOKEN': csrf,
        if (xsrf != null) 'X-XSRF-TOKEN': xsrf,
        if (cookieHeader.isNotEmpty) 'Cookie': cookieHeader,
        'Origin': 'https://filedon.co',
        'Referer': viewUrl,
      };

      final postRes = await http
          .post(
            Uri.parse('https://filedon.co/download/$slug'),
            headers: postHeaders,
            body: '{}',
          )
          .timeout(const Duration(seconds: 25));

      if (postRes.statusCode >= 200 && postRes.statusCode < 500) {
        try {
          final j = jsonDecode(postRes.body);
          if (j is Map) {
            final flash = j['props']?['flash'];
            if (flash is Map) {
              final du = flash['download_url']?.toString();
              if (du != null && du.startsWith('http')) {
                return du.replaceAll(r'\/', '/');
              }
            }
            final du2 = j['download_url']?.toString();
            if (du2 != null && du2.startsWith('http')) {
              return du2.replaceAll(r'\/', '/');
            }
          }
        } catch (_) {}

        final mUrl = RegExp(
          r'"download_url"\s*:\s*"(https?://[^"]+)"',
        ).firstMatch(postRes.body);
        if (mUrl != null) {
          return mUrl
              .group(1)!
              .replaceAll(r'\/', '/')
              .replaceAll(r'\u0026', '&');
        }
      }

      return 'https://filedon.co/force-download/$slug';
    } catch (_) {
      return 'https://filedon.co/force-download/$slug';
    }
  }

  Future<String?> _resolveToVideoUrl(String raw) async {
    final url = raw.trim();
    if (url.isEmpty) return null;

    // Prioritas tunggal: filedon.co (tunggu ~6 detik → unduh)
    if (_filedonSlug(url) != null) {
      final fd = await _resolveFiledon(url);
      if (fd != null && fd.isNotEmpty) return fd;
    }

    final pd = _pixeldrainId(url);
    if (pd != null) {
      return 'https://pixeldrain.com/api/file/$pd?download';
    }

    if (_looksLikeVideoUrl(url)) return url;

    try {
      final res = await http
          .get(
            Uri.parse(url),
            headers: {
              'User-Agent':
                  'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36',
              'Accept': 'text/html,application/xhtml+xml,*/*',
              'Referer': 'https://otakudesu.blog/',
            },
          )
          .timeout(const Duration(seconds: 15));
      if (res.statusCode >= 200 && res.statusCode < 400) {
        final body = res.body;
        final ctype = (res.headers['content-type'] ?? '').toLowerCase();
        if (ctype.contains('video/') ||
            ctype.contains('octet-stream') ||
            ctype.contains('mp4')) {
          return url;
        }

        final pdHtml = RegExp(
          r'https?://(?:www\.)?pixeldrain\.com/(?:u|file)/([A-Za-z0-9]+)',
          caseSensitive: false,
        ).firstMatch(body);
        if (pdHtml != null) {
          return 'https://pixeldrain.com/api/file/${pdHtml.group(1)}?download';
        }

        final videoHref = RegExp(
          r'href="([^"]+\.(?:mp4|mkv|avi|ts)[^"]*)"',
          caseSensitive: false,
        ).firstMatch(body) ??
            RegExp(
              r"href='([^']+\.(?:mp4|mkv|avi|ts)[^']*)'",
              caseSensitive: false,
            ).firstMatch(body);
        if (videoHref != null) {
          var href = videoHref.group(1)!;
          if (href.startsWith('//')) href = 'https:$href';
          if (href.startsWith('/')) {
            final base = Uri.parse(url);
            href = '${base.scheme}://${base.host}$href';
          }
          return href;
        }

        final dataUrl = RegExp(
          r'(?:data-url|data-download|downloadUrl|fileUrl)\s*[:=]\s*"([^"]+)"',
          caseSensitive: false,
        ).firstMatch(body) ??
            RegExp(
              r"(?:data-url|data-download|downloadUrl|fileUrl)\s*[:=]\s*'([^']+)'",
              caseSensitive: false,
            ).firstMatch(body);
        if (dataUrl != null) {
          var href = dataUrl.group(1)!;
          if (href.startsWith('//')) href = 'https:$href';
          final nested = _pixeldrainId(href);
          if (nested != null) {
            return 'https://pixeldrain.com/api/file/$nested?download';
          }
          if (_looksLikeVideoUrl(href)) return href;
        }
      }
    } catch (_) {}

    return url;
  }

  bool _isFiledon(String host) {
    final h = host.toLowerCase().replaceAll(' ', '');
    return h.contains('filedon');
  }

  bool _isDirectFriendly(String host) {
    // Hanya filedon.co yang dipakai sebagai host unduhan
    return _isFiledon(host);
  }

  String _safeFileName(String quality) {
    final base = widget.episodeTitle
        .replaceAll(RegExp(r'[^a-zA-Z0-9._\-\s]+'), '')
        .trim()
        .replaceAll(RegExp(r'\s+'), '_');
    final q = quality.replaceAll(RegExp(r'[^a-zA-Z0-9]+'), '_');
    final name = (base.isEmpty ? 'anime' : base) + '_' + q + '.mp4';
    return name.length > 80 ? name.substring(0, 80) + '.mp4' : name;
  }

  Future<void> _downloadQuality(String quality, List<DownloadItem> items) async {
    if (_downloading.contains(quality)) return;
    if (items.isEmpty) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Link unduhan tidak tersedia')),
      );
      return;
    }

    // Peringatan: jangan keluar app saat unduh
    final go = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF241C2C),
        title: const Text(
          'Unduh video',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800),
        ),
        content: const Text(
          'lagi konfirmasi unduh (tunggu ~6 detik), jangan keluar APK selama proses.',
          style: TextStyle(color: Colors.white70, height: 1.4),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text(
              'Oke',
              style: TextStyle(
                color: Color(0xFFFFD88A),
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ],
      ),
    );
    if (go != true || !mounted) return;

    // Hanya host filedon.co
    final ordered = [
      for (final it in items)
        if (_isFiledon(it.host) && it.link.isNotEmpty) it,
    ];
    if (ordered.isEmpty) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Link unduh tidak tersedia untuk kualitas ini')),
      );
      return;
    }

    setState(() => _downloading.add(quality));
    Object? lastError;
    try {
      final fileName = _safeFileName(quality);
      var ok = false;
      // Hanya host yang punya link valid
      final candidates = <DownloadItem>[
        for (final pick in ordered)
          if (pick.link.isNotEmpty) pick,
      ];
      for (var i = 0; i < candidates.length; i++) {
        final pick = candidates[i];
        final isLast = i == candidates.length - 1;
        final resolved = await _resolveToVideoUrl(pick.link);
        if (resolved == null || resolved.isEmpty) {
          if (isLast) {
            lastError = Exception('Tidak ada link video langsung');
          }
          continue;
        }
        try {
          final offlineDir = await resolveOfflineMediaDir(sub: 'anime');
          final result = await saveRemoteFile(
            url: resolved,
            fileName: fileName,
            notificationTitle: 'Download anime $quality',
            notify: true,
            notifyOnFailure: isLast,
            targetDir: offlineDir,
            headers: {
              'Referer': pick.link,
              'Accept': 'video/*,application/octet-stream,*/*',
              'User-Agent':
                  'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36',
            },
          );
          if (!mounted) return;
          final fpath = result.file.path;
          final f = File(fpath);
          if (!await f.exists()) {
            throw Exception('File unduhan tidak ditemukan setelah simpan');
          }
          final bytes = await f.length();
          // File terlalu kecil = unduhan gagal / HTML error — jangan masuk Offline
          if (bytes < 50 * 1024) {
            try {
              await f.delete();
            } catch (_) {}
            throw Exception('File unduhan tidak valid (terlalu kecil)');
          }
          final mb = (bytes / (1024 * 1024)).toStringAsFixed(1);
          final owner = await SessionStore.getUsername() ?? '';
          await OfflineIndex.register(
            key: 'anime:${widget.episodeSlug ?? widget.episodeTitle}:$quality',
            filePath: fpath,
            title: '${widget.episodeTitle} ($quality)',
            owner: owner,
            animeTitle: widget.animeTitle,
            coverUrl: widget.coverUrl,
            seriesKey: widget.seriesKey ??
                (widget.episodeSlug != null
                    ? 'anime:${widget.episodeSlug}'
                    : null),
          );
          try {
            await ApiSync.pushOffline(await OfflineIndex.listAll());
          } catch (_) {}
          if (!mounted) return;
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Tersimpan offline ($mb MB) — buka Unduhan Saya → Offline'),
              duration: const Duration(seconds: 3),
            ),
          );
          ok = true;
          break;
        } catch (e) {
          lastError = e;
        }
      }
      if (!ok) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Gagal unduh video. '
              '${(lastError ?? Exception("filedon.co gagal")).toString().replaceFirst("Exception: ", "")}',
            ),
            duration: const Duration(seconds: 5),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _downloading.remove(quality));
    }
  }

  Map<String, List<DownloadItem>> get _grouped {
    final map = <String, List<DownloadItem>>{};
    for (final item in _data?.downloads ?? []) {
      map.putIfAbsent(item.quality, () => []).add(item);
    }
    for (final list in map.values) {
      list.sort((a, b) {
        final ap = _isFiledon(a.host) ? 0 : 1;
        final bp = _isFiledon(b.host) ? 0 : 1;
        if (ap != bp) return ap.compareTo(bp);
        return a.host.toLowerCase().compareTo(b.host.toLowerCase());
      });
    }
    return map;
  }

  bool _isPdrain(String host) {
    final h = host.toLowerCase().replaceAll(' ', '');
    return h.contains('pdrain') || h.contains('pixeldrain');
  }

  @override
  Widget build(BuildContext context) {
    // Fullscreen: hanya player landscape, back = keluar fullscreen (bukan keluar halaman)
    if (_fullscreen) {
      return PopScope(
        canPop: false,
        onPopInvoked: (didPop) {
          if (!didPop) _setFullscreen(false);
        },
        child: Scaffold(
          backgroundColor: Colors.black,
          body: SafeArea(
            child: Stack(
              fit: StackFit.expand,
              children: [
                if (_player != null) WebViewWidget(controller: _player!),
                Positioned(
                  top: 8,
                  right: 8,
                  child: Material(
                    color: Colors.black54,
                    shape: const CircleBorder(),
                    child: IconButton(
                      tooltip: 'Keluar fullscreen',
                      icon: const Icon(Icons.fullscreen_exit_rounded, color: Colors.white),
                      onPressed: () => _setFullscreen(false),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: const Color(0xFF17121F),
      appBar: AppBar(
        backgroundColor: Colors.black54,
        foregroundColor: Colors.white,
        title: Text(
          widget.episodeTitle,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16),
        ),
        elevation: 0,
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: Color(0xFFFFD88A)))
          : _error != null
              ? Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(24),
                        child: Text(_error!, style: const TextStyle(color: Colors.white70), textAlign: TextAlign.center),
                      ),
                      TextButton(
                        onPressed: _load,
                        style: TextButton.styleFrom(foregroundColor: const Color(0xFFFFD88A)),
                        child: const Text('Coba lagi'),
                      ),
                    ],
                  ),
                )
              : _buildBody(),
    );
  }

  Widget _buildBody() {
    final stream = _data?.streamUrl;
    final hasDownloads = (_data?.downloads.isNotEmpty ?? false);

    return ListView(
      padding: const EdgeInsets.fromLTRB(0, 0, 0, 28),
      children: [
        if (stream != null && stream.isNotEmpty)
          AspectRatio(
            aspectRatio: 16 / 9,
            child: Stack(
              fit: StackFit.expand,
              children: [
                const ColoredBox(color: Colors.black),
                if (_player != null) WebViewWidget(controller: _player!),
                if (_playerLoading)
                  const ColoredBox(
                    color: Colors.black54,
                    child: Center(
                      child: CircularProgressIndicator(color: Color(0xFFFFD88A)),
                    ),
                  ),
                if (_playerError != null)
                  ColoredBox(
                    color: Colors.black87,
                    child: Center(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              'Gagal memuat player\n$_playerError',
                              textAlign: TextAlign.center,
                              style: const TextStyle(color: Colors.white70, fontSize: 13),
                            ),
                            const SizedBox(height: 10),
                            TextButton(
                              onPressed: () => _initPlayer(stream),
                              style: TextButton.styleFrom(foregroundColor: const Color(0xFFFFD88A)),
                              child: const Text('Coba lagi'),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                // Tombol fullscreen — landscape hanya setelah dipencet
                Positioned(
                  right: 8,
                  bottom: 8,
                  child: Material(
                    color: Colors.black54,
                    borderRadius: BorderRadius.circular(20),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(20),
                      onTap: () => _setFullscreen(true),
                      child: const Padding(
                        padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.fullscreen_rounded, color: Color(0xFFFFD88A), size: 20),
                            SizedBox(width: 6),
                            Text(
                              'Fullscreen',
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w700,
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          )
        else
          Container(
            height: 180,
            color: Colors.black,
            alignment: Alignment.center,
            child: const Text(
              'Stream tidak tersedia',
              style: TextStyle(color: Colors.white54),
            ),
          ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 6),
          child: Text(
            widget.episodeTitle,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w800,
              fontSize: 15,
              height: 1.3,
            ),
          ),
        ),
        const Padding(
          padding: EdgeInsets.fromLTRB(16, 12, 16, 4),
          child: Text(
            'Download',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 16),
          ),
        ),
        if (!hasDownloads)
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 24, horizontal: 16),
            child: Text(
              'Tidak ada link unduhan untuk episode ini',
              style: TextStyle(color: Colors.white54),
              textAlign: TextAlign.center,
            ),
          )
        else ...[
          // Resolusi untuk batch unduh (acefile) — sama opsi seperti pilih unduh
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 10),
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFF241C2C),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Colors.white10),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Resolusi batch (acefile)',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w700,
                      fontSize: 13,
                    ),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'Dipakai saat Batch unduh di halaman anime',
                    style: TextStyle(color: Colors.white38, fontSize: 11),
                  ),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      for (final q in ['', '360', '480', '720', '1080'])
                        ChoiceChip(
                          label: Text(q.isEmpty ? 'Otomatis' : '${q}p'),
                          selected: _batchQuality == q,
                          onSelected: (_) async {
                            setState(() => _batchQuality = q);
                            await DownloadQualityPref.set(q);
                          },
                          selectedColor: const Color(0xFFFFD88A),
                          labelStyle: TextStyle(
                            color: _batchQuality == q ? Colors.black : Colors.white70,
                            fontWeight: FontWeight.w700,
                            fontSize: 12,
                          ),
                          backgroundColor: const Color(0xFF2A2233),
                          visualDensity: VisualDensity.compact,
                          materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          ..._grouped.entries.map((entry) {
            final quality = entry.key;
            final busy = _downloading.contains(quality);
            return Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
              child: Material(
                color: const Color(0xFFFFD88A).withOpacity(0.14),
                borderRadius: BorderRadius.circular(14),
                child: InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: busy ? null : () => _downloadQuality(quality, entry.value),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                    child: Row(
                      children: [
                        if (busy)
                          const SizedBox(
                            width: 22,
                            height: 22,
                            child: CircularProgressIndicator(
                              strokeWidth: 2.2,
                              color: Color(0xFFFFD88A),
                            ),
                          )
                        else
                          const Icon(Icons.download_rounded, color: Color(0xFFFFD88A), size: 22),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            busy ? 'Mengunduh $quality...' : 'Unduh $quality',
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ),
                        const Icon(Icons.save_alt_rounded, color: Colors.white38, size: 18),
                      ],
                    ),
                  ),
                ),
              ),
            );
          }),
        ]
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// Halaman penuh Anime Ongoing (dibuka dari banner di Dashboard)
// ---------------------------------------------------------------------------

class AnimeOngoingPage extends StatefulWidget {
  const AnimeOngoingPage({super.key});

  @override
  State<AnimeOngoingPage> createState() => _AnimeOngoingPageState();
}

class _AnimeOngoingPageState extends State<AnimeOngoingPage> {
  final _sectionKey = GlobalKey<_AnimeOngoingSectionState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF17121F),
      body: Stack(
        fit: StackFit.expand,
        children: [
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xFF1E1528), Color(0xFF17121F)],
              ),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(8, 8, 16, 4),
                  child: Row(
                    children: [
                      IconButton(
                        onPressed: () => Navigator.of(context).pop(),
                        icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white, size: 20),
                      ),
                      const Expanded(
                        child: Text(
                          'Nonton Anime',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w800,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: RefreshIndicator(
                    color: const Color(0xFFFFD88A),
                    backgroundColor: const Color(0xFF2A2233),
                    onRefresh: () async {
                      await _sectionKey.currentState?.reload();
                    },
                    child: SingleChildScrollView(
                      physics: const AlwaysScrollableScrollPhysics(),
                      padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
                      child: AnimeOngoingSection(key: _sectionKey),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Widget list ongoing (dipakai di Dashboard tab & AnimeOngoingPage)
// ---------------------------------------------------------------------------

class AnimeOngoingSection extends StatefulWidget {
  const AnimeOngoingSection({super.key});

  @override
  State<AnimeOngoingSection> createState() => _AnimeOngoingSectionState();
}

class _AnimeOngoingSectionState extends State<AnimeOngoingSection> {
  final _api = const AnimeApiClient();
  List<AnimeOngoingItem> _items = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final list = await _api.fetchOngoing();
      if (!mounted) return;
      setState(() {
        _items = list;
        _loading = false;
      });
      // Cek episode baru untuk anime favorit (background)
      // ignore: unawaited_futures
      AnimeFavoriteStore.checkUpdates(_api);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = e.toString().replaceFirst('Exception: ', '');
        _loading = false;
      });
    }
  }

  /// Dipakai pull-to-refresh dari AnimeOngoingPage
  Future<void> reload() => _load();

  void _openSearch() {
    Navigator.of(context).push(_slideFadeRoute(const AnimeSearchPage()));
  }

  void _openDetail(AnimeOngoingItem item) {
    Navigator.of(context).push(
      _slideFadeRoute(
        AnimeDetailPage(
          animeUrl: item.link,
          titleHint: item.title,
          slug: item.slug,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          children: [
            const Expanded(
              child: Text(
                'Anime Ongoing',
                style: TextStyle(
                  fontSize: 19,
                  fontWeight: FontWeight.w800,
                  color: Colors.white,
                  shadows: [Shadow(color: Colors.black45, blurRadius: 8)],
                ),
              ),
            ),
            Material(
              color: Colors.black.withOpacity(0.35),
              borderRadius: BorderRadius.circular(14),
              child: InkWell(
                borderRadius: BorderRadius.circular(14),
                onTap: _openSearch,
                child: const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 12, vertical: 9),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.search_rounded, color: Color(0xFFFFD88A), size: 18),
                      SizedBox(width: 6),
                      Text('Cari', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13)),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 14),
        if (_loading)
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 40),
            child: Center(child: CircularProgressIndicator(color: Color(0xFFFFD88A))),
          )
        else if (_error != null)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 24),
            child: Column(
              children: [
                Text(_error!, style: const TextStyle(color: Colors.white70), textAlign: TextAlign.center),
                const SizedBox(height: 12),
                TextButton(
                  onPressed: _load,
                  style: TextButton.styleFrom(foregroundColor: const Color(0xFFFFD88A)),
                  child: const Text('Coba lagi'),
                ),
              ],
            ),
          )
        else if (_items.isEmpty)
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 32),
            child: Text('Tidak ada data ongoing', style: TextStyle(color: Colors.white54), textAlign: TextAlign.center),
          )
        else
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: _items.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              mainAxisSpacing: 10,
              crossAxisSpacing: 10,
              childAspectRatio: 0.62,
            ),
            itemBuilder: (context, i) {
              final item = _items[i];
              final day = item.type?.trim();
              return Material(
                color: Colors.transparent,
                child: InkWell(
                  borderRadius: BorderRadius.circular(12),
                  onTap: () => _openDetail(item),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        _animePoster(item.image, radius: BorderRadius.zero),
                        // gradient bawah biar teks kebaca
                        const DecoratedBox(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: [Colors.transparent, Color(0xCC000000)],
                              stops: [0.45, 1],
                            ),
                          ),
                        ),
                        if (day != null && day.isNotEmpty)
                          Positioned(
                            top: 6,
                            left: 6,
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                              decoration: BoxDecoration(
                                color: const Color(0xFFFFD88A).withOpacity(0.92),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Text(
                                day,
                                style: const TextStyle(
                                  color: Color(0xFF17121F),
                                  fontWeight: FontWeight.w800,
                                  fontSize: 10,
                                ),
                              ),
                            ),
                          ),
                        Positioned(
                          left: 6,
                          right: 6,
                          bottom: 7,
                          child: Text(
                            item.title,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w700,
                              fontSize: 11,
                              height: 1.2,
                              shadows: [Shadow(color: Colors.black54, blurRadius: 4)],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
      ],
    );
  }
}

class _GlassAnimeCard extends StatelessWidget {
  const _GlassAnimeCard({required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(18),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
        child: Material(
          color: Colors.white.withOpacity(0.12),
          borderRadius: BorderRadius.circular(18),
          child: child,
        ),
      ),
    );
  }
}
