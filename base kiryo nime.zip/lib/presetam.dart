import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

import 'api_config.dart';

/// Client untuk mencari komentar TikTok yang berisi preset Alight Motion.
///
/// Urutan pengambilan komentar:
///  1) LANGSUNG ke endpoint publik TikTok (`/api/comment/list/`) — sering
///     membalas 200 dengan body KOSONG saat membatasi akses (dianggap gagal).
///  2) tikwm comment/list (publik, tanpa login) — terbukti memuat komentar
///     berisi link preset alightcreative.com/am/share.
///  3) Api base (`POST /api/tiktok/comments`) sebagai fallback terakhir.
class TikTokPresetApiClient {
  const TikTokPresetApiClient({this.baseUrl = apiBaseUrl});

  final String baseUrl;

  static const String _mobileUserAgent =
      'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 '
      '(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36';

  /// ID video TikTok dari URL panjang: /video/123456… atau /photo/123456…
  static final RegExp _awemeIdPattern = RegExp('/(?:video|photo)/(\\d+)');

  /// Pola tambahan: /share/video/<id> dan /node/share/video/<id>.
  static final RegExp _shareAwemeIdPattern =
      RegExp('/(?:share|node/share)/video/(\\d{15,25})');

  /// ID video berupa deretan angka panjang di mana pun pada URL.
  static final RegExp _digitsOnly = RegExp('(\\d{15,25})');

  /// Link preset Alight Motion di dalam teks komentar.
  ///
  /// Pola longgar (boleh ada karakter path) + pola ketat struktur asli:
  /// `/u/<id>/p/<id>-<hash hex 16 karakter>`.
  /// Pola ketat mencegah teks setelah URL (WhatsApp, XML, emoji, dll)
  /// ikut tertangkap setelah whitespace di-compact.
  static final RegExp _presetUrlPattern = RegExp(
    r'''https?://alightcreative\.com/am/share[^\s"<>'\\]*''',
    caseSensitive: false,
  );
  static final RegExp _presetUrlPatternStrict = RegExp(
    r'https?://alightcreative\.com/am/share/u/[A-Za-z0-9\-_~]+/p/[A-Za-z0-9\-_~]+-[A-Fa-f0-9]{16}',
    caseSensitive: false,
  );

  Future<List<String>> findPresets({required String link, String? token}) async {
    // 1) UTAMA: langsung ke endpoint komentar TikTok dari Dart.
    Object? lastError;
    try {
      final comments = await _fetchDirectComments(link);
      final presets = _extractPresetUrls(comments);
      if (presets.isNotEmpty) return presets;
    } catch (error) {
      if (error is! _NoCommentsFound) lastError = error;
    }

    // 2) tikwm comment/list (publik, tanpa login) — dipakai juga oleh
    //    backend, jadi tetap berfungsi walau endpoint resmi diblokir.
    try {
      final comments = await _fetchViaTikwm(link);
      final presets = _extractPresetUrls(comments);
      if (presets.isNotEmpty) return presets;
    } catch (error) {
      lastError ??= error;
    }

    // 3) FALLBACK: lewat api base panel (POST /api/tiktok/comments).
    try {
      final comments = await _fetchViaBackend(link, token);
      final presets = _extractPresetUrls(comments);
      if (presets.isNotEmpty) return presets;
    } catch (error) {
      lastError ??= error;
    }

    if (lastError != null) {
      throw Exception(_describe(lastError));
    }
    return const [];
  }

  // ======================= tikwm comment/list =======================

  /// Ambil komentar lewat tikwm: GET /api/comment/list?url=...&cursor=...
  /// Respon: { code:0, data:{ comments:[{text,...}], cursor, hasMore } }.
  ///
  /// Reply sering kosong di list (meski reply_total > 0). Endpoint
  /// `/api/comment/reply?video_id=&comment_id=` dipakai untuk mengambil
  /// balasan — preset Alight Motion biasanya ada di reply creator.
  Future<List<String>> _fetchViaTikwm(String link) async {
    final comments = <String>[];
    final replyTargets = <({String videoId, String commentId, int total})>[];
    var cursor = 0;
    var hasMore = true;
    String? videoId;

    // Maksimal 5 halaman (cukup untuk menemukan komentar admin).
    for (var page = 0; page < 5 && hasMore; page++) {
      final uri = Uri.https(
        'www.tikwm.com',
        '/api/comment/list',
        <String, String>{'url': link, 'cursor': '$cursor'},
      );

      http.Response response;
      try {
        response = await http
            .get(uri, headers: const {'User-Agent': _mobileUserAgent})
            .timeout(const Duration(seconds: 30));
      } catch (_) {
        break;
      }
      if (response.statusCode < 200 || response.statusCode >= 300) break;
      if (response.body.trim().isEmpty) break;

      dynamic decoded;
      try {
        decoded = jsonDecode(response.body);
      } catch (_) {
        break;
      }
      if (decoded is Map && decoded['code'] != 0 && decoded['code'] != '0') break;
      final data = decoded is Map ? decoded['data'] : null;
      if (data is! Map) break;

      final list = data['comments'];
      if (list is List) {
        for (final item in list) {
          if (item is Map) {
            final text = item['text']?.toString() ?? '';
            if (text.trim().isNotEmpty) comments.add(text);

            final replies = item['replies'];
            var inlineReplyCount = 0;
            if (replies is List) {
              for (final reply in replies) {
                if (reply is Map) {
                  final replyText = reply['text']?.toString() ?? '';
                  if (replyText.trim().isNotEmpty) {
                    comments.add(replyText);
                    inlineReplyCount++;
                  }
                }
              }
            }

            // Ambil reply terpisah bila reply_total > jumlah yang sudah inline.
            final replyTotal = item['reply_total'];
            final total = replyTotal is int
                ? replyTotal
                : int.tryParse('$replyTotal') ?? 0;
            final cid = item['id']?.toString();
            final vid = item['video_id']?.toString();
            if (vid != null && vid.isNotEmpty) videoId = vid;
            if (cid != null &&
                cid.isNotEmpty &&
                total > inlineReplyCount &&
                (videoId != null || vid != null)) {
              replyTargets.add((
                videoId: vid ?? videoId!,
                commentId: cid,
                total: total,
              ));
            }
          }
        }
      }

      final more = data['hasMore'] ?? data['has_more'];
      hasMore = more == true || more == 1 || more == '1' || more == 'true';
      final nextCursor = data['cursor'] ?? data['next_cursor'];
      cursor = nextCursor is int
          ? nextCursor
          : int.tryParse('$nextCursor') ?? cursor + 20;
      // tikwm kadang mengembalikan hasMore=true tapi page berikutnya code=-1
      if (list is! List || list.isEmpty) break;
    }

    // Fetch reply threads (prioritas komentar yang punya banyak balasan).
    // Batasi agar tidak terlalu banyak request.
    replyTargets.sort((a, b) => b.total.compareTo(a.total));
    final seen = <String>{};
    var fetched = 0;
    for (final target in replyTargets) {
      if (fetched >= 12) break;
      if (!seen.add(target.commentId)) continue;
      try {
        final replyTexts = await _fetchTikwmReplies(
          videoId: target.videoId,
          commentId: target.commentId,
        );
        comments.addAll(replyTexts);
        fetched++;
      } catch (_) {
        // lanjut target berikutnya
      }
    }

    return comments;
  }

  /// GET www.tikwm.com/api/comment/reply?video_id=...&comment_id=...&cursor=...
  Future<List<String>> _fetchTikwmReplies({
    required String videoId,
    required String commentId,
  }) async {
    final out = <String>[];
    var cursor = 0;
    var hasMore = true;
    for (var page = 0; page < 3 && hasMore; page++) {
      final uri = Uri.https(
        'www.tikwm.com',
        '/api/comment/reply',
        <String, String>{
          'video_id': videoId,
          'comment_id': commentId,
          'cursor': '$cursor',
        },
      );
      http.Response response;
      try {
        response = await http
            .get(uri, headers: const {'User-Agent': _mobileUserAgent})
            .timeout(const Duration(seconds: 25));
      } catch (_) {
        break;
      }
      if (response.statusCode < 200 || response.statusCode >= 300) break;
      if (response.body.trim().isEmpty) break;
      dynamic decoded;
      try {
        decoded = jsonDecode(response.body);
      } catch (_) {
        break;
      }
      if (decoded is! Map || (decoded['code'] != 0 && decoded['code'] != '0')) {
        break;
      }
      final data = decoded['data'];
      if (data is! Map) break;
      final list = data['comments'];
      if (list is List) {
        for (final item in list) {
          if (item is Map) {
            final text = item['text']?.toString() ?? '';
            if (text.trim().isNotEmpty) out.add(text);
          }
        }
      }
      final more = data['hasMore'] ?? data['has_more'];
      hasMore = more == true || more == 1 || more == '1' || more == 'true';
      final next = data['cursor'] ?? data['next_cursor'];
      cursor = next is int ? next : int.tryParse('$next') ?? cursor + 20;
      if (list is! List || list.isEmpty) break;
    }
    return out;
  }

  // ======================= PANGGILAN LANGSUNG =======================

  Future<List<String>> _fetchDirectComments(String link) async {
    final resolution = await _resolveVideo(link);
    final resolvedUrl = resolution.resolvedUrl;
    final awemeId = resolution.awemeId;
    if (awemeId == null) {
      throw Exception('ID video tidak ditemukan dari link TikTok');
    }

    final headers = <String, String>{
      'User-Agent': _mobileUserAgent,
      'Accept': 'application/json, text/plain, */*',
      'Accept-Language': 'id-ID,id;q=0.9,en;q=0.8',
      'Referer': resolvedUrl,
    };

    final comments = <String>[];
    var cursor = 0;
    var hasMore = true;

    // Maksimal 6 halaman x 50 komentar (cukup untuk menemukan komentar admin).
    for (var page = 0; page < 6 && hasMore; page++) {
      final uri = Uri.https(
        'www.tiktok.com',
        '/api/comment/list/',
        <String, String>{
          'aid': '1988',
          'app_language': 'id-ID',
          'app_name': 'tiktok_web',
          'browser_language': 'id-ID',
          'browser_name': 'Mozilla',
          'browser_online': 'true',
          'browser_platform': 'Linux armv81',
          'browser_version': _mobileUserAgent,
          'channel': 'tiktok_web',
          'cookie_enabled': 'true',
          'count': '50',
          'cursor': '$cursor',
          'aweme_id': awemeId,
          'device_platform': 'web_mobile',
          'focus_state': 'true',
          'fromPage': 'video',
          'history_len': '2',
          'is_fullscreen': 'false',
          'is_page_visible': 'true',
          'language': 'id-ID',
          'os': 'android',
          'priority_region': 'ID',
          'referer': '',
          'region': 'ID',
          'screen_height': '800',
          'screen_width': '360',
          'tz_name': 'Asia/Jakarta',
          'webcast_language': 'id-ID',
        },
      );

      final response = await http
          .get(uri, headers: headers)
          .timeout(const Duration(seconds: 30));

      if (response.statusCode == 401 ||
          response.statusCode == 403 ||
          response.statusCode == 429) {
        throw Exception('Endpoint komentar TikTok menolak akses (${response.statusCode})');
      }
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw Exception('Endpoint komentar TikTok error (${response.statusCode})');
      }

      // TikTok kadang membalas 200 dengan body KOSONG saat membatasi akses:
      // hentikan pagination lalu lanjut ke fallback scraping (jangan throw).
      if (response.body.trim().isEmpty) break;

      dynamic decoded;
      try {
        decoded = jsonDecode(response.body);
      } catch (_) {
        break; // body bukan JSON (halaman blokir) -> lanjut scraping
      }
      if (decoded is! Map) {
        throw Exception('Respons komentar TikTok tidak valid');
      }

      final list = decoded['comments'];
      if (list is List) {
        for (final item in list) {
          if (item is Map) {
            final text = item['text']?.toString() ?? '';
            if (text.trim().isNotEmpty) comments.add(text);
            // Komentar balasan kadang menyimpan link preset.
            final replies = item['reply_comment'];
            if (replies is List) {
              for (final reply in replies) {
                if (reply is Map) {
                  final replyText = reply['text']?.toString() ?? '';
                  if (replyText.trim().isNotEmpty) comments.add(replyText);
                }
              }
            }
          }
        }
      }

      final more = decoded['has_more'] ?? decoded['hasMore'];
      hasMore = more == 1 || more == true || more == '1' || more == 'true';
      final nextCursor = decoded['cursor'] ?? decoded['next_cursor'];
      cursor = nextCursor is int ? nextCursor : int.tryParse('$nextCursor') ?? cursor + 50;
    }

    // Fallback langsung: scraping JSON halaman video bila endpoint kosong.
    if (comments.isEmpty) {
      final scraped = await _scrapeVideoPage(resolvedUrl);
      comments.addAll(scraped);
    }

    if (comments.isEmpty) throw const _NoCommentsFound();
    return comments;
  }

  /// Resolve link TikTok (pendek maupun panjang) menjadi URL yang memuat
  /// ID video + ID video-nya sekaligus.
  ///
  /// Strategi berlapis:
  ///  1) Link sudah memuat ID -> langsung dipakai.
  ///  2) Ikuti redirect secara MANUAL hop demi hop. Header `Location` dari
  ///     301 vt./vm.tiktok.com sudah berisi URL video lengkap, jadi ID tetap
  ///     didapat meskipun halaman tujuan diblokir (403) atau TikTok membalas
  ///     halaman interstitial (200) tanpa redirect.
  ///  3) Bila suatu hop membalas 200, cari ID di body HTML
  ///     (data-video-id / "videoId" / "awemeId").
  ///  4) Fallback terakhir: oembed resmi TikTok; ambil `data-video-id` dari
  ///     field `html`. PENTING: jangan ambil URL pertama di JSON oembed,
  ///     karena itu adalah author_url TANPA ID -> penyebab error
  ///     "ID video tidak ditemukan dari link TikTok".
  Future<_ResolvedVideo> _resolveVideo(String link) async {
    var uri = Uri.tryParse(link.trim());
    if (uri == null || !uri.hasScheme) {
      uri = Uri.tryParse('https://${link.trim()}');
    }
    if (uri == null) throw Exception('Link TikTok tidak valid');

    // 1) Link panjang yang sudah memuat ID tidak perlu di-resolve.
    final directId = _extractAwemeId(link);
    if (directId != null) return _ResolvedVideo(link, directId);

    // 2) + 3) Redirect manual + deteksi ID di body.
    final client = http.Client();
    try {
      var current = uri;
      for (var hop = 0; hop < 6; hop++) {
        http.StreamedResponse streamed;
        try {
          final request = http.Request('GET', current)
            ..followRedirects = false
            ..maxRedirects = 0
            ..headers.addAll({
              'User-Agent': _mobileUserAgent,
              'Accept': 'text/html,application/json,application/xhtml+xml,*/*',
              'Accept-Language': 'id-ID,id;q=0.9,en;q=0.8',
            });
          streamed = await client
              .send(request)
              .timeout(const Duration(seconds: 30));
        } catch (_) {
          break; // jaringan/timeout -> lanjut ke oembed
        }

        final location = streamed.headers['location'];
        if (streamed.statusCode >= 300 &&
            streamed.statusCode < 400 &&
            location != null &&
            location.isNotEmpty) {
          await streamed.stream.drain();
          // ID video biasanya sudah ada di Location pertama.
          final idInLocation = _extractAwemeId(location);
          if (idInLocation != null) {
            return _ResolvedVideo(location, idInLocation);
          }
          final next = Uri.tryParse(location);
          if (next == null) break;
          current = next.hasScheme ? next : current.resolveUri(next);
          continue;
        }

        // Hop membalas 200 (halaman interstitial/video): cari ID di body.
        final body = await streamed.stream.bytesToString();
        final idInBody = _extractAwemeId(body) ?? _extractVideoIdFromHtml(body);
        if (idInBody != null) {
          final url = _extractAwemeId(current.toString()) != null
              ? current.toString()
              : 'https://www.tiktok.com/video/$idInBody';
          return _ResolvedVideo(url, idInBody);
        }
        break;
      }
    } finally {
      client.close();
    }

    // 4) Fallback oembed resmi (tanpa login).
    try {
      final oembed = await http
          .get(
            Uri.parse(
                'https://www.tiktok.com/oembed?url=${Uri.encodeComponent(link)}'),
            headers: const {'User-Agent': _mobileUserAgent},
          )
          .timeout(const Duration(seconds: 20));
      if (oembed.statusCode >= 200 && oembed.statusCode < 300) {
        final id = _extractVideoIdFromHtml(oembed.body) ??
            _extractAwemeId(oembed.body);
        if (id != null) {
          return _ResolvedVideo('https://www.tiktok.com/video/$id', id);
        }
      }
    } catch (_) {
      // Abaikan.
    }

    return _ResolvedVideo(link, null);
  }

  /// Cari ID video langsung di HTML/JSON mentah.
  /// Menangani `data-video-id="..."` (termasuk versi escaped `\"` dari JSON
  /// oembed) dan `"videoId"`/`"awemeId"`/`"aweme_id"`.
  String? _extractVideoIdFromHtml(String html) {
    for (final pattern in [
      RegExp(r'data-video-id=\\?"(\d{15,25})'),
      RegExp(r'\\?"(?:videoId|awemeId|aweme_id)\\?"\s*:\s*\\?"(\d{15,25})'),
    ]) {
      final match = pattern.firstMatch(html);
      if (match != null) return match.group(1);
    }
    return null;
  }

  String? _extractAwemeId(String url) {
    final byPath = _awemeIdPattern.firstMatch(url);
    if (byPath != null) return byPath.group(1);
    final byShare = _shareAwemeIdPattern.firstMatch(url);
    if (byShare != null) return byShare.group(1);
    final byDigits = _digitsOnly.firstMatch(url);
    return byDigits?.group(1);
  }

  /// Fallback scraping: ambil komentar awal dari JSON halaman video.
  Future<List<String>> _scrapeVideoPage(String resolvedUrl) async {
    try {
      final response = await http.get(
        Uri.parse(resolvedUrl),
        headers: const {
          'User-Agent': _mobileUserAgent,
          'Accept-Language': 'id-ID,id;q=0.9,en;q=0.8',
        },
      ).timeout(const Duration(seconds: 30));
      if (response.statusCode != 200) return const [];

      final html = response.body;
      for (final marker in const [
        '__UNIVERSAL_DATA_FOR_REHYDRATION__',
        'SIGI_STATE',
      ]) {
        final pattern = RegExp(
          '<script id="' + marker + r'"[^>]*>([\s\S]*?)</script>',
        );
        final match = pattern.firstMatch(html);
        if (match == null) continue;
        try {
          final json = jsonDecode(match.group(1)!);
          final found = <String>[];
          _collectCommentTexts(json, found);
          if (found.isNotEmpty) return found;
        } catch (_) {
          // lanjut ke marker berikutnya
        }
      }
    } catch (_) {
      // abaikan, scraping hanya fallback
    }
    return const [];
  }

  // ======================= FALLBACK API BASE =======================

  Future<List<String>> _fetchViaBackend(String link, String? token) async {
    final headers = <String, String>{
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'User-Agent': _mobileUserAgent,
    };
    if (token != null && token.isNotEmpty) {
      headers['Authorization'] = 'Bearer $token';
    }

    final response = await http
        .post(
          Uri.parse('$baseUrl/api/tiktok/comments'),
          headers: headers,
          body: jsonEncode({'url': link, 'link': link}),
        )
        .timeout(const Duration(seconds: 30));

    final body = response.body.trimLeft();
    if (body.isEmpty ||
        body.startsWith('<!') ||
        body.startsWith('<html') ||
        body.startsWith('<HTML')) {
      throw Exception(
        'Server panel mengembalikan halaman web, bukan data komentar. Coba lagi nanti.',
      );
    }

    dynamic decoded;
    try {
      decoded = jsonDecode(response.body);
    } catch (_) {
      throw Exception(
        'Respons API komentar TikTok tidak valid (bukan JSON). Server mungkin sedang gangguan.',
      );
    }

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception(
          _message(decoded) ?? 'Komentar TikTok tidak dapat diambil');
    }

    final comments = <String>[];
    _collectCommentTexts(decoded, comments);
    return comments;
  }

  // ======================= EKSTRAKSI PRESET =======================

  /// Ambil link berawalan https://alightcreative.com/am/share dari komentar.
  List<String> _extractPresetUrls(List<String> comments) {
    final results = <String>[];
    void addUrl(String? url) {
      if (url != null && url.isNotEmpty && !results.contains(url)) {
        results.add(url);
      }
    }

    for (final comment in comments) {
      // 1) Pola ketat pada teks asli (link utuh 1 baris).
      for (final match in _presetUrlPatternStrict.allMatches(comment)) {
        addUrl(_normalizePresetUrl(match.group(0)!));
      }
      // 2) Compact whitespace: menyelamatkan link yang terpotong antar-baris.
      //    Pola ketat memastikan teks setelah URL (WhatsApp/XML/emoji) tidak ikut.
      final compact = comment.replaceAll(RegExp(r'\s+'), '');
      for (final match in _presetUrlPatternStrict.allMatches(compact)) {
        addUrl(_normalizePresetUrl(match.group(0)!));
      }
      // 3) Fallback longgar hanya jika belum ketemu (struktur non-standar).
      if (results.isEmpty) {
        for (final match in _presetUrlPattern.allMatches(compact)) {
          addUrl(_normalizePresetUrl(match.group(0)!));
        }
      }
      // Kompatibel dengan format lama: komentar diawali kata "alightcreative".
      final normalized = comment.trim();
      if (normalized.toLowerCase().startsWith('alightcreative')) {
        addUrl(normalized);
      }
    }
    return results;
  }

  String? _normalizePresetUrl(String raw) {
    var url = raw.trim();
    // Buang karakter buntut yang bukan bagian link (emoji/ttd umum).
    url = url.replaceAll(RegExp(r"[^A-Za-z0-9\-._~:/?#\[\]@!$&'()*+,;=%]+$"), '');
    if (!url.toLowerCase().startsWith('https://alightcreative.com/am/share')) {
      if (url.toLowerCase().startsWith('http://alightcreative.com/am/share')) {
        url = 'https://${url.substring(7)}';
      } else {
        return null;
      }
    }
    // Potong di hash 16-hex bila ada trailing sampah setelah pola ketat gagal.
    final strict = _presetUrlPatternStrict.firstMatch(url);
    if (strict != null) return strict.group(0);
    return url;
  }

  void _collectCommentTexts(dynamic value, List<String> output) {
    if (value is String) {
      output.add(value);
      return;
    }
    if (value is List) {
      for (final item in value) {
        _collectCommentTexts(item, output);
      }
      return;
    }
    if (value is Map) {
      for (final entry in value.entries) {
        final key = entry.key.toString().toLowerCase();
        final child = entry.value;
        if (key == 'comment' || key == 'text' || key == 'content' || key == 'comments') {
          _collectCommentTexts(child, output);
        } else if (child is List || child is Map) {
          _collectCommentTexts(child, output);
        }
      }
    }
  }

  String _describe(Object error) {
    final raw = error.toString()
        .replaceFirst('Exception: ', '')
        .replaceFirst('FormatException: ', '');
    final low = raw.toLowerCase();
    if (low.contains('unexpected token') ||
        low.contains('doctype') ||
        low.contains('bukan json') ||
        low.contains('not valid json') ||
        low.contains('halaman web') ||
        low.contains('<!doctype') ||
        low.contains('<html')) {
      return 'Server mengembalikan data tidak valid (bukan JSON). Coba lagi sebentar atau ganti link.';
    }
    if (low.contains('socketexception') ||
        low.contains('failed host lookup') ||
        low.contains('timed out') ||
        low.contains('timeout') ||
        low.contains('connection')) {
      return 'Tidak ada internet / koneksi bermasalah. Cek Wi-Fi atau data seluler.';
    }
    if (low.contains('id video tidak ditemukan')) {
      return 'ID video tidak ditemukan dari link TikTok. Pastikan link valid.';
    }
    if (raw.trim().isEmpty) {
      return 'Preset tidak dapat diambil. Coba lagi.';
    }
    return raw;
  }

  String? _message(dynamic value) =>
      value is Map ? value['message']?.toString() : null;
}

class _NoCommentsFound implements Exception {
  const _NoCommentsFound();
}

/// Hasil resolve link TikTok: URL terbaik (untuk Referer & scraping)
/// beserta ID video (aweme_id) bila berhasil ditemukan.
class _ResolvedVideo {
  const _ResolvedVideo(this.resolvedUrl, this.awemeId);

  final String resolvedUrl;
  final String? awemeId;
}

class PresetAMPage extends StatefulWidget {
  const PresetAMPage({super.key, required this.token, this.apiClient = const TikTokPresetApiClient()});

  final String token;
  final TikTokPresetApiClient apiClient;

  @override
  State<PresetAMPage> createState() => _PresetAMPageState();
}

class _PresetAMPageState extends State<PresetAMPage> {
  final _controller = TextEditingController();
  bool _loading = false;
  List<String> _presets = const [];

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _findPresets() async {
    final link = _controller.text.trim();
    if (link.isEmpty) {
      _showMessage('Masukkan link TikTok terlebih dahulu');
      return;
    }
    setState(() {
      _loading = true;
      _presets = const [];
    });
    try {
      final result = await widget.apiClient.findPresets(link: link, token: widget.token);
      if (mounted) setState(() => _presets = result);
      if (mounted && result.isEmpty) {
        _showMessage('Tidak ditemukan komentar berisi link https://alightcreative.com/am/share');
      }
    } catch (error) {
      if (mounted) {
        final msg = error
            .toString()
            .replaceFirst('Exception: ', '')
            .replaceFirst('FormatException: ', '');
        _showMessage(msg);
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _copyPreset(String preset) async {
    await Clipboard.setData(ClipboardData(text: preset));
    if (mounted) _showMessage('Preset berhasil disalin');
  }

  Future<void> _openPreset(String preset) async {
    final value = preset.trim();
    final uri = Uri.tryParse(value);
    final browserUri = uri != null && (uri.hasScheme || value.startsWith('www.'))
        ? (value.startsWith('www.') ? Uri.parse('https://$value') : uri)
        : Uri.tryParse('https://$value');

    if (browserUri == null || !await launchUrl(browserUri, mode: LaunchMode.externalApplication)) {
      if (mounted) _showMessage('Link preset tidak dapat dibuka');
    }
  }

  void _showMessage(String message) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F7FC),
      appBar: AppBar(title: const Text('Cari Preset Alight Motion'), backgroundColor: Colors.transparent, elevation: 0),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(22, 16, 22, 30),
        children: [
          Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF17121F), Color(0xFF4A315D)]), borderRadius: BorderRadius.circular(26)),
            child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Icon(Icons.auto_awesome_rounded, color: Color(0xFFFFD88A), size: 34),
              SizedBox(height: 16),
              Text('Cari preset Alight Motion', style: TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.w800)),
              SizedBox(height: 6),
              Text('Masukkan link TikTok. Komentar berisi link alightcreative.com/am/share akan ditampilkan otomatis.', style: TextStyle(color: Colors.white70, height: 1.35)),
            ]),
          ),
          const SizedBox(height: 22),
          TextField(
            controller: _controller,
            keyboardType: TextInputType.url,
            textInputAction: TextInputAction.done,
            onSubmitted: (_) => _findPresets(),
            decoration: InputDecoration(
              labelText: 'Link video TikTok',
              hintText: 'https://www.tiktok.com/@user/video/...',
              prefixIcon: const Icon(Icons.link_rounded),
              suffixIcon: IconButton(icon: const Icon(Icons.clear_rounded), onPressed: () => _controller.clear()),
              filled: true,
              fillColor: Colors.white,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
            ),
          ),
          const SizedBox(height: 14),
          SizedBox(
            height: 54,
            child: ElevatedButton.icon(
              onPressed: _loading ? null : _findPresets,
              icon: _loading ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.search_rounded),
              label: Text(_loading ? 'Mencari komentar...' : 'CARI PRESET'),
              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF17121F), foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
            ),
          ),
          if (_presets.isNotEmpty) ...[
            const SizedBox(height: 26),
            const Text('Preset ditemukan', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 10),
            ..._presets.asMap().entries.map((entry) {
              final index = entry.key + 1;
              final preset = entry.value;
              return Container(
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), boxShadow: const [BoxShadow(color: Color(0x12000000), blurRadius: 12, offset: Offset(0, 4))]),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CircleAvatar(radius: 14, backgroundColor: const Color(0xFFEDE5F5), child: Text('$index', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800))),
                    const SizedBox(width: 12),
                    Expanded(child: SelectableText(preset, style: const TextStyle(height: 1.35))),
                    const SizedBox(width: 8),
                    Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        TextButton.icon(
                          onPressed: () => _openPreset(preset),
                          icon: const Icon(Icons.open_in_browser_rounded, size: 18),
                          label: const Text('Buka'),
                          style: TextButton.styleFrom(foregroundColor: const Color(0xFF4A315D), padding: const EdgeInsets.symmetric(horizontal: 8)),
                        ),
                        IconButton(tooltip: 'Salin preset', onPressed: () => _copyPreset(preset), icon: const Icon(Icons.copy_rounded, color: Color(0xFF4A315D))),
                      ],
                    ),
                  ],
                ),
              );
            }),
          ],
        ],
      ),
    );
  }
}
