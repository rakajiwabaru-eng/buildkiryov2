import 'dart:io';

import 'package:flutter/material.dart';

import 'anime.dart';
import 'api_sync.dart';
import 'local_library.dart';
import 'session.dart';
import 'manga.dart';
import 'offline_player.dart';
import 'app_features.dart';
import 'smart_image.dart';

/// Riwayat + Bookmark + Offline
class LibraryHubPage extends StatefulWidget {
  const LibraryHubPage({super.key});

  @override
  State<LibraryHubPage> createState() => _LibraryHubPageState();
}

class _LibraryHubPageState extends State<LibraryHubPage> with SingleTickerProviderStateMixin {
  late final TabController _tabs;
  List<LibraryEntry> _history = [];
  List<LibraryEntry> _bookmarks = [];
  List<Map<String, dynamic>> _offline = [];
  String _histFilter = 'all'; // all | today | week | anime | manga
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 3, vsync: this);
    _reload();
  }

  @override
  void dispose() {
    _tabs.dispose();
    super.dispose();
  }

  Future<void> _reload() async {
    setState(() => _loading = true);
    final h = await HistoryStore.list();
    var b = await BookmarkStore.list();
    // Gabungkan favorit komik (manga/manhua/manhwa) ke tab Favorit,
    // sekaligus migrasi data lama yang hanya tersimpan di store favorit komik.
    try {
      final favs = await MangaFavoriteStore.list();
      final seen = b.map((e) => '${e.kind}:${e.id}').toSet();
      final missing = <LibraryEntry>[];
      for (final f in favs) {
        if (f.slug.isEmpty || seen.contains('manga:${f.slug}')) continue;
        seen.add('manga:${f.slug}');
        missing.add(LibraryEntry(
          id: f.slug,
          title: f.title,
          coverUrl: f.coverUrl,
          kind: 'manga',
          subtitle: f.type,
          progress: f.latestChapter,
        ));
      }
      if (missing.isNotEmpty) {
        for (final e in missing.reversed) {
          await BookmarkStore.add(e);
        }
        b = await BookmarkStore.list();
      }
    } catch (_) {}
    final uname = await SessionStore.getUsername() ?? '';
    final o = await OfflineIndex.listForUser(uname);
    if (!mounted) return;
    setState(() {
      _history = h;
      _bookmarks = b;
      _offline = o;
      _loading = false;
    });
  }

  Future<void> _confirmDeleteOffline({
    required String message,
    required List<String> keys,
  }) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF241C2C),
        title: const Text(
          'Hapus unduhan?',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800),
        ),
        content: Text(
          message,
          style: const TextStyle(color: Colors.white70, height: 1.4),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Tidak', style: TextStyle(color: Colors.white54)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text(
              'Ya',
              style: TextStyle(color: Colors.redAccent, fontWeight: FontWeight.w800),
            ),
          ),
        ],
      ),
    );
    if (ok != true) return;
    await OfflineIndex.removeKeys(keys);
    try {
      await ApiSync.pushOffline(await OfflineIndex.listAll());
    } catch (_) {}
    if (mounted) await _reload();
  }

  void _openEntry(LibraryEntry e) {
    if (e.kind == 'manga') {
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => MangaDetailPage(
            slug: e.id,
            titleHint: e.title,
          ),
        ),
      );
    } else if (e.kind == 'anime') {
      final link = e.extra?['link']?.toString() ?? '';
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => AnimeDetailPage(
            animeUrl: link.isNotEmpty ? link : e.id,
            titleHint: e.title,
            slug: e.id,
          ),
        ),
      );
    }
  }


  Widget _buildOfflineGrid() {
    final groups = OfflineIndex.groupBySeries(_offline);
    return GridView.builder(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 20),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: 12,
        crossAxisSpacing: 12,
        childAspectRatio: 0.68,
      ),
      itemCount: groups.length,
      itemBuilder: (_, i) {
        final g = groups[i];
        final title = (g['animeTitle'] ?? 'Anime').toString();
        final cover = (g['coverUrl'] ?? '').toString();
        final items = (g['items'] as List).cast<Map<String, dynamic>>();
        final count = items.length;
        return Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => OfflineSeriesPage(
                    animeTitle: title,
                    coverUrl: cover,
                    items: items,
                  ),
                ),
              ).then((_) => _reload());
            },
            onLongPress: () {
              final keys = [
                for (final it in items) (it['key'] ?? '').toString(),
              ].where((k) => k.isNotEmpty).toList();
              if (keys.isEmpty) return;
              _confirmDeleteOffline(
                message:
                    'Apakah kamu ingin menghapus "$title" beserta semua episode offline-nya?',
                keys: keys,
              );
            },
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.06),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Colors.white12),
              ),
              clipBehavior: Clip.antiAlias,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Expanded(
                    child: cover.isNotEmpty
                        ? SmartCover(url: cover, borderRadius: 0)
                        : Container(
                            color: const Color(0xFF2A2235),
                            child: const Icon(
                              Icons.movie_outlined,
                              color: Colors.white38,
                              size: 42,
                            ),
                          ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(10, 8, 10, 10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          title,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w700,
                            fontSize: 13,
                            height: 1.25,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          '$count episode',
                          style: const TextStyle(
                            color: Color(0xFFFFD88A),
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _entryTile(LibraryEntry e, {VoidCallback? onRemove}) {
    return ListTile(
      onTap: () => _openEntry(e),
      leading: SizedBox(
        width: 48,
        height: 64,
        child: SmartCover(url: e.coverUrl, borderRadius: 8),
      ),
      title: Text(e.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13)),
      subtitle: Text(
        [
          e.kind.toUpperCase(),
          if (e.subtitle != null && e.subtitle!.isNotEmpty) e.subtitle!,
          if (e.progress != null && e.progress!.isNotEmpty) e.progress!,
        ].join(' · '),
        style: const TextStyle(color: Colors.white54, fontSize: 11),
      ),
      trailing: onRemove == null
          ? null
          : IconButton(
              icon: const Icon(Icons.close, color: Colors.white38, size: 18),
              onPressed: onRemove,
            ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF17121F),
      appBar: AppBar(
        backgroundColor: const Color(0xFF17121F),
        foregroundColor: Colors.white,
        title: const Text('Unduhan Saya'),
        bottom: TabBar(
          controller: _tabs,
          indicatorColor: const Color(0xFFFFD88A),
          labelColor: const Color(0xFFFFD88A),
          unselectedLabelColor: Colors.white54,
          tabs: const [
            Tab(text: 'Riwayat'),
            Tab(text: 'Favorit'),
            Tab(text: 'Offline'),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, color: Colors.white70),
            onPressed: _reload,
            tooltip: 'Muat ulang',
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: Color(0xFFFFD88A)))
          : TabBarView(
              controller: _tabs,
              children: [
                _HistoryTab(
                  history: _history,
                  filter: _histFilter,
                  onFilter: (f) => setState(() => _histFilter = f),
                  onRemove: (e) async {
                    await HistoryStore.remove(e.id, kind: e.kind);
                    await _reload();
                  },
                ),
                _bookmarks.isEmpty
                    ? const Center(child: Text('Belum ada favorit', style: TextStyle(color: Colors.white54)))
                    : ListView.separated(
                        itemCount: _bookmarks.length,
                        separatorBuilder: (_, __) => const Divider(color: Colors.white10, height: 1),
                        itemBuilder: (_, i) {
                          final e = _bookmarks[i];
                          return _entryTile(
                            e,
                            onRemove: () async {
                              await BookmarkStore.remove(e.id, kind: e.kind);
                              await _reload();
                            },
                          );
                        },
                      ),
                _offline.isEmpty
                    ? const Center(
                        child: Text(
                          'Belum ada unduhan offline',
                          style: TextStyle(color: Colors.white54),
                        ),
                      )
                    : _buildOfflineGrid(),
              ],
            ),
    );
  }
}


/// Daftar episode offline untuk satu serial anime.
class OfflineSeriesPage extends StatefulWidget {
  const OfflineSeriesPage({
    super.key,
    required this.animeTitle,
    required this.coverUrl,
    required this.items,
  });

  final String animeTitle;
  final String coverUrl;
  final List<Map<String, dynamic>> items;

  @override
  State<OfflineSeriesPage> createState() => _OfflineSeriesPageState();
}

class _OfflineSeriesPageState extends State<OfflineSeriesPage> {
  late List<Map<String, dynamic>> _items;

  @override
  void initState() {
    super.initState();
    _items = List<Map<String, dynamic>>.from(widget.items);
  }

  Future<void> _deleteOne(Map<String, dynamic> item) async {
    final key = (item['key'] ?? '').toString();
    final title = (item['title'] ?? 'Video').toString();
    if (key.isEmpty) return;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF241C2C),
        title: const Text(
          'Hapus unduhan?',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800),
        ),
        content: Text(
          'Apakah kamu ingin menghapusnya?\n\n$title',
          style: const TextStyle(color: Colors.white70, height: 1.4),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Tidak', style: TextStyle(color: Colors.white54)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text(
              'Ya',
              style: TextStyle(color: Colors.redAccent, fontWeight: FontWeight.w800),
            ),
          ),
        ],
      ),
    );
    if (ok != true) return;
    await OfflineIndex.remove(key);
    try {
      await ApiSync.pushOffline(await OfflineIndex.listAll());
    } catch (_) {}
    if (!mounted) return;
    setState(() => _items.removeWhere((e) => (e['key'] ?? '') == key));
    if (_items.isEmpty && mounted) {
      Navigator.of(context).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF17121F),
      appBar: AppBar(
        backgroundColor: Colors.black54,
        foregroundColor: Colors.white,
        title: Text(
          widget.animeTitle,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16),
        ),
      ),
      body: Column(
        children: [
          if (widget.coverUrl.isNotEmpty)
            SizedBox(
              height: 160,
              width: double.infinity,
              child: SmartCover(url: widget.coverUrl, borderRadius: 0),
            ),
          Expanded(
            child: ListView.separated(
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 24),
              itemCount: _items.length,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (context, i) {
                final item = _items[i];
                final title = (item['title'] ?? 'Episode').toString();
                final path = (item['path'] ?? '').toString();
                final exists = path.isNotEmpty && File(path).existsSync();
                return Material(
                  color: Colors.white.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(12),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(12),
                    onTap: () {
                      if (!exists) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text(
                              'File tidak ada. Unduh ulang dari halaman episode.',
                            ),
                          ),
                        );
                        return;
                      }
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (_) => OfflineVideoPage(
                            filePath: path,
                            title: title,
                          ),
                        ),
                      );
                    },
                    onLongPress: () => _deleteOne(item),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 14),
                      child: Row(
                        children: [
                          Icon(
                            exists
                                ? Icons.play_circle_fill_rounded
                                : Icons.cloud_off_outlined,
                            color: exists
                                ? const Color(0xFFFFD88A)
                                : Colors.white38,
                            size: 28,
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              title,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                color: exists ? Colors.white : Colors.white54,
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                          const Icon(Icons.chevron_right,
                              color: Colors.white38),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}


class _HistoryTab extends StatelessWidget {
  const _HistoryTab({
    required this.history,
    required this.filter,
    required this.onFilter,
    required this.onRemove,
  });

  final List<LibraryEntry> history;
  final String filter;
  final ValueChanged<String> onFilter;
  final Future<void> Function(LibraryEntry e) onRemove;

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final filtered = history.where((h) {
      if (filter == 'anime') return h.kind == 'anime';
      if (filter == 'manga') return h.kind == 'manga';
      final u = h.updatedAt;
      if (filter == 'today' && u != null) {
        return u.year == now.year && u.month == now.month && u.day == now.day;
      }
      if (filter == 'week' && u != null) {
        return now.difference(u).inDays <= 7;
      }
      return true;
    }).toList();

    return Column(
      children: [
        SizedBox(
          height: 42,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            children: [
              for (final e in [
                ('all', 'Semua'),
                ('today', 'Hari ini'),
                ('week', 'Minggu ini'),
                ('anime', 'Anime'),
                ('manga', 'Manga'),
              ])
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Text(e.$2),
                    selected: filter == e.$1,
                    onSelected: (_) => onFilter(e.$1),
                    selectedColor: const Color(0xFFFFD88A),
                    labelStyle: TextStyle(
                      color: filter == e.$1 ? Colors.black : Colors.white70,
                      fontWeight: FontWeight.w700,
                      fontSize: 12,
                    ),
                    backgroundColor: const Color(0xFF2A2233),
                    visualDensity: VisualDensity.compact,
                  ),
                ),
            ],
          ),
        ),
        Expanded(
          child: filtered.isEmpty
              ? const Center(
                  child: Text('Belum ada riwayat', style: TextStyle(color: Colors.white54)),
                )
              : ListView.separated(
                  itemCount: filtered.length,
                  separatorBuilder: (_, __) => const Divider(color: Colors.white10, height: 1),
                  itemBuilder: (ctx, i) {
                    final e = filtered[i];
                    return ListTile(
                      onLongPress: () async => onRemove(e),
                      leading: e.coverUrl.isNotEmpty
                          ? ClipRRect(
                              borderRadius: BorderRadius.circular(8),
                              child: Image.network(e.coverUrl, width: 48, height: 48, fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) => const Icon(Icons.movie, color: Colors.white54),
                              ),
                            )
                          : const Icon(Icons.history, color: Colors.white54),
                      title: Text(e.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
                      subtitle: Text(
                        [e.kind, e.subtitle, e.progress].where((x) => x != null && '$x'.isNotEmpty).join(' · '),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: Colors.white54, fontSize: 12),
                      ),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete_outline, color: Colors.white38),
                        onPressed: () async => onRemove(e),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }
}
