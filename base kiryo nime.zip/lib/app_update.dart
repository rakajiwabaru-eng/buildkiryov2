import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';

import 'api_config.dart';
import 'direct_download.dart';

/// Versi APK yang sedang dipakai.
/// Saat build bisa diisi otomatis:
///   flutter build apk --dart-define=APP_VERSION=1.2.0
const String appVersion = String.fromEnvironment(
  'APP_VERSION',
  defaultValue: '1.0.0',
);

class UpdateInfo {
  const UpdateInfo({
    required this.needUpdate,
    required this.force,
    required this.latest,
    required this.message,
    required this.updateUrl,
    required this.downloadUrl,
    required this.channel,
  });

  final bool needUpdate;
  final bool force;
  final String latest;
  final String message;
  final String updateUrl;
  final String downloadUrl;
  final String channel;

  static const fallbackMessage =
      'versi terbaru telah rilis di wajibkan update apk ke versi terbaru!! ^⁠_⁠^';

  factory UpdateInfo.fromJson(Map<String, dynamic> j) {
    final url = ((j['downloadUrl'] ?? j['updateUrl'] ?? '') as Object)
        .toString()
        .trim();
    return UpdateInfo(
      needUpdate: j['needUpdate'] == true,
      force: j['force'] == true || j['needUpdate'] == true,
      latest: (j['latest'] ?? '').toString(),
      message: ((j['message'] ?? '') as Object).toString().isEmpty
          ? fallbackMessage
          : j['message'].toString(),
      updateUrl: url,
      downloadUrl: url,
      channel: (j['channel'] ?? '@kiryochannel').toString(),
    );
  }
}

/// Cek versi ke base API lalu paksa update kalau APK-nya lama.
class AppUpdate {
  static bool _dialogOpen = false;
  static bool _downloading = false;

  static const _installChannel = MethodChannel('com.kiryomanz.app/install');

  /// Ubah link halaman MediaFire menjadi URL unduhan langsung.
  /// Boleh pakai:
  ///   https://www.mediafire.com/file/KEY/nama.apk/file
  ///   https://www.mediafire.com/file/KEY/nama.apk
  ///   https://downloadXXXX.mediafire.com/... (sudah direct)
  static Future<String> resolveDownloadUrl(String raw) async {
    final input = raw.trim();
    if (input.isEmpty) return input;

    final uri = Uri.tryParse(input);
    if (uri == null || !uri.hasScheme) return input;

    final host = uri.host.toLowerCase();

    // Sudah link CDN direct
    if (host.contains('download') && host.contains('mediafire.com')) {
      return input;
    }

    // Bukan MediaFire → pakai apa adanya
    if (!host.contains('mediafire.com')) {
      return input;
    }

    final client = http.Client();
    try {
      final req = http.Request('GET', uri);
      req.followRedirects = true;
      req.headers['User-Agent'] =
          'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36';
      req.headers['Accept'] =
          'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8';
      req.headers['Accept-Language'] = 'en-US,en;q=0.9,id;q=0.8';

      final streamed =
          await client.send(req).timeout(const Duration(seconds: 25));
      final res = await http.Response.fromStream(streamed);
      final html = res.body;

      // 1) Link CDN langsung di HTML
      final cdnRe = RegExp(
        r'https?://download\d*\.mediafire\.com/[^\s<>]+',
        caseSensitive: false,
      );
      final cdnMatch = cdnRe.firstMatch(html);
      if (cdnMatch != null) {
        return cdnMatch.group(0)!.replaceAll('&amp;', '&');
      }

      // 2) Semua href yang mengarah ke download mediafire
      final hrefRe = RegExp(
        r'''href=["'](https?://[^"']+)["']''',
        caseSensitive: false,
      );
      for (final m in hrefRe.allMatches(html)) {
        final h = m.group(1)!.replaceAll('&amp;', '&');
        final hl = h.toLowerCase();
        if (hl.contains('download') && hl.contains('mediafire.com')) {
          return h;
        }
      }

      // 3) Protocol-relative //download.mediafire.com/...
      final protoRe = RegExp(
        r'''["'](//download\d*\.mediafire\.com/[^"']+)["']''',
        caseSensitive: false,
      );
      final pr = protoRe.firstMatch(html);
      if (pr != null) {
        return 'https:${pr.group(1)}';
      }

      // 4) Coba /download/KEY dari path /file/KEY/...
      final keyMatch = RegExp(
        r'mediafire\.com/file/([a-zA-Z0-9]+)',
        caseSensitive: false,
      ).firstMatch(input);
      if (keyMatch != null) {
        final key = keyMatch.group(1)!;
        final tryUrl = Uri.parse('https://www.mediafire.com/download/$key');
        final r2 = await client
            .get(
              tryUrl,
              headers: {
                'User-Agent':
                    'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36',
              },
            )
            .timeout(const Duration(seconds: 20));

        final loc = r2.headers['location'];
        if (loc != null) {
          final locL = loc.toLowerCase();
          if (locL.contains('download') && locL.contains('mediafire')) {
            if (loc.startsWith('http')) return loc;
            return 'https://www.mediafire.com$loc';
          }
        }
        final cdn2 = cdnRe.firstMatch(r2.body);
        if (cdn2 != null) {
          return cdn2.group(0)!.replaceAll('&amp;', '&');
        }

        // Kadang redirect chain: ikuti sekali lagi
        if (loc != null && loc.isNotEmpty) {
          final next = loc.startsWith('http')
              ? Uri.parse(loc)
              : Uri.parse('https://www.mediafire.com$loc');
          final r3 = await client
              .get(
                next,
                headers: {
                  'User-Agent':
                      'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36',
                },
              )
              .timeout(const Duration(seconds: 20));
          final cdn3 = cdnRe.firstMatch(r3.body);
          if (cdn3 != null) {
            return cdn3.group(0)!.replaceAll('&amp;', '&');
          }
          final loc3 = r3.headers['location'];
          if (loc3 != null &&
              loc3.toLowerCase().contains('download') &&
              loc3.toLowerCase().contains('mediafire')) {
            return loc3.startsWith('http') ? loc3 : 'https://www.mediafire.com$loc3';
          }
        }
      }

      throw Exception(
        'Gagal mengambil link unduhan MediaFire. Pastikan file publik.',
      );
    } finally {
      client.close();
    }
  }

  /// Tanya ke server: versi ini masih boleh dipakai?
  static Future<UpdateInfo?> check() async {
    try {
      final res = await http
          .get(Uri.parse('$apiBaseUrl/api/version/check?version=$appVersion'))
          .timeout(const Duration(seconds: 12));
      final body = jsonDecode(res.body);
      if (body is Map && body['ok'] == true) {
        return UpdateInfo.fromJson(Map<String, dynamic>.from(body));
      }
    } catch (_) {
      // Offline / server tidak terjangkau → jangan ganggu user.
    }
    return null;
  }

  /// Dipanggil saat app dibuka & setiap kembali dari background.
  /// Versi terbaru → langsung lewat tanpa notifikasi.
  static Future<void> enforce(BuildContext context) async {
    if (_dialogOpen) return;
    final info = await check();
    if (info == null || !info.needUpdate) return;
    if (!context.mounted) return;
    await _show(context, info);
  }

  static Future<void> _show(BuildContext context, UpdateInfo info) async {
    _dialogOpen = true;
    try {
      while (context.mounted) {
        await showDialog<void>(
          context: context,
          barrierDismissible: false,
          useRootNavigator: true,
          builder: (ctx) => _UpdateDialog(info: info),
        );
        if (!context.mounted) break;
        final again = await check();
        if (again == null || !again.needUpdate) break;
      }
    } finally {
      _dialogOpen = false;
    }
  }

  /// Unduh APK di background (notif progress) lalu buka installer.
  static Future<void> downloadAndInstall(
    BuildContext context,
    UpdateInfo info,
  ) async {
    if (_downloading) return;
    final url = info.downloadUrl.trim();
    if (url.isEmpty) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Link unduhan belum diset di server (.env)'),
            backgroundColor: Colors.redAccent,
          ),
        );
      }
      return;
    }

    _downloading = true;
    try {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Menyiapkan unduhan…'),
            duration: Duration(seconds: 2),
          ),
        );
      }

      // Resolve halaman MediaFire → link direct (otomatis)
      final directUrl = await resolveDownloadUrl(url);

      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Mengunduh update… progress di notifikasi'),
            duration: Duration(seconds: 3),
          ),
        );
      }

      final base = await getExternalStorageDirectory() ??
          await getApplicationDocumentsDirectory();
      final dir = Directory('${base.path}/updates');
      if (!await dir.exists()) await dir.create(recursive: true);

      final fileName =
          'kiryo_nime_${info.latest.isEmpty ? "update" : info.latest}.apk';

      final result = await saveRemoteFile(
        url: directUrl,
        fileName: fileName,
        notificationTitle: 'Update KIRYO NIME',
        targetDir: dir,
        timeout: const Duration(minutes: 30),
        minBytes: 100 * 1024,
        allowAnyContent: true,
        headers: {
          'User-Agent':
              'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36',
          'Accept': '*/*',
        },
      );

      if (!context.mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Unduhan selesai — membuka installer…'),
          duration: Duration(seconds: 2),
        ),
      );

      await installApk(result.file.path);
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Gagal update: $e'),
            backgroundColor: Colors.redAccent,
            duration: const Duration(seconds: 5),
          ),
        );
      }
    } finally {
      _downloading = false;
    }
  }

  /// Buka package installer Android untuk file APK.
  static Future<void> installApk(String path) async {
    try {
      await _installChannel.invokeMethod('installApk', {'path': path});
    } on PlatformException catch (e) {
      throw Exception(e.message ?? 'Gagal membuka installer');
    }
  }
}

class _UpdateDialog extends StatefulWidget {
  const _UpdateDialog({required this.info});

  final UpdateInfo info;

  @override
  State<_UpdateDialog> createState() => _UpdateDialogState();
}

class _UpdateDialogState extends State<_UpdateDialog> {
  bool _busy = false;

  Future<void> _onUpdate() async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      await AppUpdate.downloadAndInstall(context, widget.info);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      child: AlertDialog(
        backgroundColor: const Color(0xFF221A2D),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: Row(
          children: const [
            Icon(Icons.system_update, color: Color(0xFFFFD88A)),
            SizedBox(width: 10),
            Expanded(
              child: Text(
                'Update Tersedia',
                style: TextStyle(
                  color: Color(0xFFFFD88A),
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              widget.info.message,
              style: const TextStyle(color: Colors.white, height: 1.4),
            ),
            const SizedBox(height: 12),
            Text(
              'Versi kamu: $appVersion'
              '${widget.info.latest.isEmpty ? '' : '  •  Terbaru: ${widget.info.latest}'}',
              style: const TextStyle(color: Colors.white54, fontSize: 12),
            ),
            if (_busy) ...[
              const SizedBox(height: 16),
              const Center(
                child: SizedBox(
                  width: 28,
                  height: 28,
                  child: CircularProgressIndicator(
                    strokeWidth: 3,
                    color: Color(0xFFFFD88A),
                  ),
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'Mengunduh di latar belakang…\nLihat progress di notifikasi.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white54, fontSize: 12),
              ),
            ],
          ],
        ),
        actions: [
          FilledButton(
            style: FilledButton.styleFrom(
              backgroundColor: const Color(0xFFFFD88A),
              foregroundColor: const Color(0xFF17121F),
            ),
            onPressed: _busy ? null : _onUpdate,
            child: Text(_busy ? 'Mengunduh…' : 'Update'),
          ),
        ],
      ),
    );
  }
}
