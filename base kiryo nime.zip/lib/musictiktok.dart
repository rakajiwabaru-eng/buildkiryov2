import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'api_config.dart';
import 'direct_download.dart';

/// Client untuk endpoint pengunduh musik TikTok.
///
/// Coba panel dulu, lalu fallback ke tikwm (publik) bila panel
/// mengembalikan HTML / JSON tidak valid.
class TikTokMusicApiClient {
  const TikTokMusicApiClient({this.baseUrl = apiBaseUrl});

  final String baseUrl;

  static const _ua =
      'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 '
      '(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36';

  Future<TikTokMusicResult> download({required String link, String? token}) async {
    Object? panelError;
    try {
      return await _downloadViaPanel(link: link, token: token);
    } catch (e) {
      panelError = e;
    }
    try {
      return await _downloadViaTikwm(link);
    } catch (_) {
      throw Exception(_friendly(panelError) ??
          'Musik TikTok tidak dapat diproses. Coba link lain atau cek koneksi.');
    }
  }

  Future<TikTokMusicResult> _downloadViaPanel({
    required String link,
    String? token,
  }) async {
    final endpoint = _endpoint('/api/tiktok/music');
    final headers = <String, String>{
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'User-Agent': _ua,
    };
    if (token != null && token.isNotEmpty) {
      headers['Authorization'] = 'Bearer $token';
    }

    final response = await http
        .post(
          endpoint,
          headers: headers,
          body: jsonEncode({'url': link, 'link': link}),
        )
        .timeout(const Duration(seconds: 30));

    final body = response.body.trimLeft();
    if (body.isEmpty ||
        body.startsWith('<!') ||
        body.startsWith('<html') ||
        body.startsWith('<HTML')) {
      throw Exception(
        'Server panel mengembalikan halaman web, bukan data musik. Coba lagi nanti.',
      );
    }

    dynamic decoded;
    try {
      decoded = jsonDecode(response.body);
    } catch (_) {
      throw Exception(
        'Respons API musik TikTok tidak valid (bukan JSON). Server mungkin sedang gangguan.',
      );
    }

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception(_message(decoded) ?? 'Musik TikTok tidak dapat diproses');
    }

    final maps = _maps(decoded);
    final audioUrl = _firstStringAll(maps, [
      'audio',
      'audioUrl',
      'audio_url',
      'music',
      'musicUrl',
      'music_url',
      'download_url',
      'downloadUrl',
      'url',
    ]);

    if (audioUrl == null || audioUrl.isEmpty) {
      throw Exception('Link musik tidak ditemukan dari API');
    }

    return TikTokMusicResult(
      audioUrl: audioUrl,
      title: _firstStringAll(
          maps, ['title', 'music_title', 'musicTitle', 'name']),
      artist: _firstStringAll(
          maps, ['artist', 'author', 'music_author', 'musicAuthor']),
      coverUrl: _firstStringAll(
          maps, ['cover', 'coverUrl', 'cover_url', 'thumbnail', 'thumbnailUrl']),
    );
  }

  /// Fallback: tikwm mengembalikan field `music` (URL audio).
  Future<TikTokMusicResult> _downloadViaTikwm(String link) async {
    final uri = Uri.https('www.tikwm.com', '/api/', {
      'url': link,
      'hd': '1',
    });
    final response = await http
        .get(
          uri,
          headers: {
            'Accept': 'application/json',
            'User-Agent': _ua,
            'Referer': 'https://www.tikwm.com/',
          },
        )
        .timeout(const Duration(seconds: 30));

    final body = response.body.trimLeft();
    if (body.isEmpty || body.startsWith('<!') || body.startsWith('<html')) {
      throw Exception('Layanan cadangan musik TikTok mengembalikan halaman web');
    }

    dynamic decoded;
    try {
      decoded = jsonDecode(response.body);
    } catch (_) {
      throw Exception('Respons cadangan musik TikTok tidak valid');
    }

    final maps = _maps(decoded);
    final audioUrl = _firstStringAll(maps, [
      'music',
      'audio',
      'audioUrl',
      'audio_url',
      'musicUrl',
      'music_url',
      'download_url',
      'url',
    ]);
    if (audioUrl == null || audioUrl.isEmpty) {
      throw Exception('Link musik tidak ditemukan (cadangan)');
    }

    return TikTokMusicResult(
      audioUrl: audioUrl,
      title: _firstStringAll(
          maps, ['title', 'music_title', 'musicTitle', 'name']),
      artist: _firstStringAll(maps, [
        'author',
        'artist',
        'music_author',
        'musicAuthor',
        'nickname',
      ]),
      coverUrl: _firstStringAll(maps, [
        'cover',
        'origin_cover',
        'thumbnail',
        'thumbnailUrl',
      ]),
    );
  }

  static String? _friendly(Object? error) {
    if (error == null) return null;
    final raw = error.toString().replaceFirst('Exception: ', '');
    final low = raw.toLowerCase();
    if (low.contains('html') ||
        low.contains('doctype') ||
        low.contains('bukan json') ||
        low.contains('unexpected token') ||
        low.contains('halaman web')) {
      return 'Server sedang gangguan atau link tidak valid. Coba lagi sebentar.';
    }
    if (raw.trim().isEmpty) return null;
    return raw;
  }

  Uri _endpoint(String path) {
    var root = baseUrl.trim();
    while (root.endsWith('/')) {
      root = root.substring(0, root.length - 1);
    }
    return Uri.parse('$root$path');
  }

  List<Map<String, dynamic>> _maps(dynamic value) {
    final out = <Map<String, dynamic>>[];
    void visit(dynamic item) {
      if (item is Map) {
        final map = Map<String, dynamic>.from(item);
        out.add(map);
        for (final child in map.values) {
          if (child is Map || child is List) visit(child);
        }
      } else if (item is List) {
        for (final child in item) {
          visit(child);
        }
      }
    }

    visit(value);
    return out;
  }

  String? _firstStringAll(List<Map<String, dynamic>> maps, List<String> keys) {
    for (final map in maps) {
      final value = _firstString(map, keys);
      if (value != null) return value;
    }
    return null;
  }

  String? _firstString(Map<String, dynamic> data, List<String> keys) {
    for (final key in keys) {
      final value = data[key]?.toString();
      if (value != null && value.isNotEmpty && value != 'null') return value;
    }
    return null;
  }

  String? _message(dynamic value) =>
      value is Map<String, dynamic> ? value['message']?.toString() : null;
}

class TikTokMusicResult {
  const TikTokMusicResult({required this.audioUrl, this.title, this.artist, this.coverUrl});

  final String audioUrl;
  final String? title;
  final String? artist;
  final String? coverUrl;
}

class TikTokMusicPage extends StatefulWidget {
  const TikTokMusicPage({super.key, required this.token, this.apiClient = const TikTokMusicApiClient()});

  final String token;
  final TikTokMusicApiClient apiClient;

  @override
  State<TikTokMusicPage> createState() => _TikTokMusicPageState();
}

class _TikTokMusicPageState extends State<TikTokMusicPage> {
  final _controller = TextEditingController();
  bool _loading = false;
  TikTokMusicResult? _result;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _download() async {
    final link = _controller.text.trim();
    if (link.isEmpty) {
      _showMessage('Masukkan link TikTok terlebih dahulu');
      return;
    }
    setState(() {
      _loading = true;
      _result = null;
    });
    try {
      final result = await widget.apiClient.download(link: link, token: widget.token);
      if (mounted) setState(() => _result = result);
    } catch (error) {
      if (mounted) _showMessage(error.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _saveAudio() async {
    final result = _result;
    if (result == null) return;
    setState(() => _loading = true);
    try {
      final acak = DateTime.now().millisecondsSinceEpoch.toRadixString(36);
      final name = 'music_kiryo_$acak.mp3';
      // Paksa simpan ke /storage/emulated/0/Download/
      final folder = await resolvePublicDownloadDir();
      final saved = await saveRemoteFile(
        url: result.audioUrl,
        fileName: name,
        notificationTitle: 'Download musik TikTok',
        minBytes: 4 * 1024,
        referer: 'https://www.tiktok.com/',
        targetDir: folder,
      );
      if (mounted) {
        _showMessage(
          'Musik tersimpan di /storage/emulated/0/Download/$name '
          '(${(saved.bytes / 1024 / 1024).toStringAsFixed(1)} MB)',
        );
      }
    } catch (error) {
      if (mounted) {
        _showMessage(error.toString().replaceFirst('Exception: ', ''));
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _showMessage(String message) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F7FC),
      appBar: AppBar(title: const Text('Download Musik TikTok'), backgroundColor: Colors.transparent, elevation: 0),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(22, 16, 22, 30),
        children: [
          Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF17121F), Color(0xFF4A315D)]), borderRadius: BorderRadius.circular(26)),
            child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Icon(Icons.music_note_rounded, color: Color(0xFFFFD88A), size: 34),
              SizedBox(height: 16),
              Text('Ambil musik dari TikTok', style: TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.w800)),
              SizedBox(height: 6),
              Text('Tempel link TikTok untuk mendapatkan audio atau musiknya.', style: TextStyle(color: Colors.white70, height: 1.35)),
            ]),
          ),
          const SizedBox(height: 22),
          TextField(
            controller: _controller,
            keyboardType: TextInputType.url,
            textInputAction: TextInputAction.done,
            onSubmitted: (_) => _download(),
            decoration: InputDecoration(
              labelText: 'Link video TikTok',
              hintText: 'https://www.tiktok.com/@user/video/...',
              prefixIcon: const Icon(Icons.link_rounded),
              suffixIcon: IconButton(icon: const Icon(Icons.clear_rounded), onPressed: () => _controller.clear()),
              filled: true,
              fillColor: Colors.white,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
            ),
          ),
          const SizedBox(height: 14),
          SizedBox(
            height: 54,
            child: ElevatedButton.icon(
              onPressed: _loading ? null : _download,
              icon: _loading ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.search_rounded),
              label: Text(_loading ? 'Mencari...' : 'CARI'),
              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF17121F), foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
            ),
          ),
          if (_result case final result?) ...[
            const SizedBox(height: 26),
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22), boxShadow: const [BoxShadow(color: Color(0x12000000), blurRadius: 14, offset: Offset(0, 5))]),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Row(children: [Icon(Icons.check_circle_rounded, color: Colors.green), SizedBox(width: 8), Text('Musik siap diunduh', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17))]),
                if (result.coverUrl != null) ...[const SizedBox(height: 14), ClipRRect(borderRadius: const BorderRadius.all(Radius.circular(14)), child: Image.network(result.coverUrl!, height: 180, width: double.infinity, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const SizedBox.shrink()))],
                if (result.title != null) ...[const SizedBox(height: 12), Text(result.title!, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700))],
                if (result.artist != null) ...[const SizedBox(height: 4), Text(result.artist!, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.black54))],
                const SizedBox(height: 16),
                SizedBox(width: double.infinity, child: OutlinedButton.icon(onPressed: _loading ? null : _saveAudio, icon: const Icon(Icons.save_alt_rounded), label: const Text('SIMPAN MUSIK KE HP'))),
              ]),
            ),
          ],
        ],
      ),
    );
  }
}
