import 'dart:io';

import 'package:path_provider/path_provider.dart';

/// Lokasi data app di external storage:
/// /storage/emulated/0/Android/data/com.kiryomanz.app/files/assets/
///   avatars/  — foto profil
///   video/    — unduhan anime offline
class AppPaths {
  static const packageId = 'com.kiryomanz.app';
  static const _baseFixed =
      '/storage/emulated/0/Android/data/$packageId/files/assets';

  static Future<Directory> _ensure(String path) async {
    final dir = Directory(path);
    try {
      if (!await dir.exists()) await dir.create(recursive: true);
      // probe tulis
      final probe = File('${dir.path}/.w');
      await probe.writeAsString('1', flush: true);
      await probe.delete();
      return dir;
    } catch (_) {
      // Fallback: external storage app dirs dari path_provider
      try {
        final ext = await getExternalStorageDirectory();
        if (ext != null) {
          final alt = Directory('${ext.path}/assets/${path.split('/').last}');
          if (!await alt.exists()) await alt.create(recursive: true);
          return alt;
        }
      } catch (_) {}
      final docs = await getApplicationDocumentsDirectory();
      final alt = Directory('${docs.path}/assets/${path.split('/').last}');
      if (!await alt.exists()) await alt.create(recursive: true);
      return alt;
    }
  }

  static Future<Directory> assetsRoot() => _ensure(_baseFixed);

  static Future<Directory> avatars() => _ensure('$_baseFixed/avatars');

  static Future<Directory> video() => _ensure('$_baseFixed/video');

  static Future<String> avatarFile(String username) async {
    final dir = await avatars();
    final safe =
        username.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9_-]'), '_');
    return '${dir.path}/$safe.jpg';
  }
}
