import 'dart:convert';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

import 'api_config.dart';
import 'api_sync.dart';
import 'app_notifications.dart';
import 'welcome_overlay.dart';
import 'avatar_persist.dart';
import 'dashboard.dart';
import 'session.dart';

class ApiClient {
  const ApiClient();

  String get _base {
    var b = apiBaseUrl.trim();
    if (b.endsWith('/')) b = b.substring(0, b.length - 1);
    return b;
  }

  Future<Map<String, dynamic>> _postJson(String path, Map<String, dynamic> payload) async {
    final uri = Uri.parse('$_base$path');
    try {
      final response = await http
          .post(
            uri,
            headers: const {
              'Content-Type': 'application/json; charset=utf-8',
              'Accept': 'application/json',
            },
            body: jsonEncode(payload),
          )
          .timeout(const Duration(seconds: 25));

      final raw = response.body;
      if (raw.isEmpty) {
        throw Exception('No connection');
      }
      dynamic body;
      try {
        body = jsonDecode(raw);
      } catch (_) {
        throw Exception('No connection');
      }
      if (body is Map) return Map<String, dynamic>.from(body);
      throw Exception('Format respons tidak valid');
    } on http.ClientException {
      throw Exception('No connection');
    } on FormatException {
      throw Exception('No connection');
    } catch (e) {
      final s = e.toString();
      if (s.contains('SocketException') ||
          s.contains('TimeoutException') ||
          s.contains('timed out') ||
          s.contains('Connection reset') ||
          s.contains('Connection refused') ||
          s.contains('Failed host lookup') ||
          s.contains('Network is unreachable') ||
          s.contains('ClientException')) {
        throw Exception('No connection');
      }
      rethrow;
    }
  }

  Future<Map<String, dynamic>> login({
    required String username,
    required String password,
  }) async {
    final body = await _postJson('/api/login', {
      'username': username,
      'password': password,
    });
    if (body['ok'] == true && body['token'] is String) return body;
    throw Exception(body['message']?.toString() ?? 'Login gagal');
  }

  Future<Map<String, dynamic>> register({
    required String email,
    required String username,
    required String password,
  }) async {
    final body = await _postJson('/api/register', {
      'email': email,
      'username': username,
      'password': password,
    });
    if (body['ok'] == true && body['token'] is String) return body;
    throw Exception(body['message']?.toString() ?? 'Daftar gagal');
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({
    super.key,
    this.apiClient = const ApiClient(),
    this.serverDown = false,
  });

  final ApiClient apiClient;
  /// True jika server terdeteksi mati saat buka app → tampilkan dialog maintenance.
  final bool serverDown;

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> with SingleTickerProviderStateMixin {
  late final TabController _tab;
  final _loginForm = GlobalKey<FormState>();
  final _regForm = GlobalKey<FormState>();

  final _loginUser = TextEditingController();
  final _loginPass = TextEditingController();
  final _regEmail = TextEditingController();
  final _regUser = TextEditingController();
  final _regPass = TextEditingController();

  bool _loading = false;
  bool _obscureLogin = true;
  bool _obscureReg = true;
  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 2, vsync: this);
    _tab.addListener(() {
      if (!_tab.indexIsChanging && mounted) setState(() {});
    });
    // Server terdeteksi mati → tampilkan notifikasi di menu login
    if (widget.serverDown) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _showServerDownDialog();
      });
    }
  }

  @override
  void dispose() {
    _tab.dispose();
    _loginUser.dispose();
    _loginPass.dispose();
    _regEmail.dispose();
    _regUser.dispose();
    _regPass.dispose();
    super.dispose();
  }

  String _friendlyError(Object e) {
    final s = e.toString().replaceFirst('Exception: ', '').trim();
    final low = s.toLowerCase();
    if (low.contains('no connection') ||
        low.contains('socket') ||
        low.contains('timeout') ||
        low.contains('connection reset') ||
        low.contains('connection refused') ||
        low.contains('failed host') ||
        low.contains('clientexception') ||
        low.contains('network') ||
        low.contains('http://') ||
        low.contains('https://') ||
        low.contains(':2139') ||
        low.contains('/api/')) {
      return 'Tidak ada koneksi internet. Cek Wi-Fi atau data seluler.';
    }
    if (low.contains('password salah') || low.contains('password incorrect')) {
      return 'Password salah!';
    }
    if (low.contains('username tidak ditemukan') ||
        low.contains('user not found') ||
        low.contains('tidak ditemukan')) {
      return 'Username tidak ditemukan!';
    }
    if (low.contains('sudah terdaftar') ||
        low.contains('already exists') ||
        low.contains('already registered')) {
      return 'Akun sudah terdaftar!';
    }
    if (low.contains('email sudah')) {
      return 'Email sudah terdaftar!';
    }
    if (low.contains('dinonaktifkan') || low.contains('disabled')) {
      return 'Akun dinonaktifkan. Hubungi admin.';
    }
    if (low.contains('wajib') || low.contains('minimal')) {
      return s;
    }
    if (s.isEmpty) return 'Terjadi kesalahan. Coba lagi.';
    return s;
  }

  /// Layer dialog baru: teks pesan + tombol OKE
  Future<void> _showAlert(
    String message, {
    String title = 'Pemberitahuan',
  }) async {
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      barrierDismissible: true,
      barrierColor: Colors.black.withOpacity(0.55),
      builder: (ctx) {
        return Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.symmetric(horizontal: 36, vertical: 24),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(22),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
              child: Container(
                padding: const EdgeInsets.fromLTRB(22, 22, 22, 18),
                decoration: BoxDecoration(
                  color: const Color(0xFF1E1628).withOpacity(0.92),
                  borderRadius: BorderRadius.circular(22),
                  border: Border.all(color: Colors.white24),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0x66000000),
                      blurRadius: 24,
                      offset: Offset(0, 10),
                    ),
                  ],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(
                      title,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: Color(0xFFFFD88A),
                        fontWeight: FontWeight.w800,
                        fontSize: 16,
                        letterSpacing: 0.3,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      message,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                        height: 1.35,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const SizedBox(height: 20),
                    SizedBox(
                      height: 48,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFFFFD88A),
                          foregroundColor: const Color(0xFF17121F),
                          elevation: 0,
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                        ),
                        onPressed: () => Navigator.of(ctx).pop(),
                        child: const Text(
                          'OKE',
                          style: TextStyle(
                            fontWeight: FontWeight.w900,
                            fontSize: 15,
                            letterSpacing: 0.6,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Future<void> _showServerDownDialog() async {
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      useRootNavigator: true,
      barrierColor: Colors.black.withOpacity(0.7),
      builder: (ctx) {
        return PopScope(
          canPop: false,
          child: Dialog(
            backgroundColor: Colors.transparent,
            insetPadding: const EdgeInsets.symmetric(horizontal: 28, vertical: 24),
            child: Container(
              constraints: const BoxConstraints(maxWidth: 380),
              padding: const EdgeInsets.fromLTRB(22, 26, 22, 20),
              decoration: BoxDecoration(
                color: const Color(0xFF2B2537),
                borderRadius: BorderRadius.circular(22),
                border: Border.all(color: Colors.white24, width: 1),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text(
                    'server mati ❌',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Color(0xFFFFD88A),
                      fontWeight: FontWeight.w800,
                      fontSize: 20,
                    ),
                  ),
                  const SizedBox(height: 14),
                  Text(
                    'server sedang maintance/mati proses pemindahan server agak lama tolong bersabar dan di mohon untuk menunggu 🙏\n\n'
                    'cek channel telegram saya secara berkala untuk informasi lebih lanjut 😁',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.92),
                      fontSize: 14,
                      height: 1.45,
                    ),
                  ),
                  const SizedBox(height: 22),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      style: FilledButton.styleFrom(
                        backgroundColor: const Color(0xFFFFD88A),
                        foregroundColor: const Color(0xFF17121F),
                        padding: const EdgeInsets.symmetric(vertical: 13),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                      ),
                      onPressed: () async {
                        final uri = Uri.parse('https://t.me/kiryochannel');
                        if (await canLaunchUrl(uri)) {
                          await launchUrl(uri, mode: LaunchMode.externalApplication);
                        }
                      },
                      child: const Text(
                        'cek sekarang',
                        style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15),
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    child: TextButton(
                      onPressed: () {
                        SystemNavigator.pop();
                      },
                      style: TextButton.styleFrom(
                        foregroundColor: Colors.white70,
                        padding: const EdgeInsets.symmetric(vertical: 12),
                      ),
                      child: const Text(
                        'nanti saja',
                        style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Future<void> _doLogin() async {
    // Maintenance manual saja — offline boleh coba login (error biasa kalau gagal)
    if (!apiActive) {
      await _showServerDownDialog();
      return;
    }
    if (!_loginForm.currentState!.validate()) return;
    setState(() => _loading = true);
    try {
      final res = await widget.apiClient.login(
        username: _loginUser.text.trim(),
        password: _loginPass.text,
      );
      final token = res['token'] as String;
      final user = res['user'];
      final uname = user is Map
          ? (user['username']?.toString() ?? _loginUser.text.trim())
          : _loginUser.text.trim();
      final email = user is Map ? user['email']?.toString() : null;
      await SessionStore.saveLogin(token: token, username: uname, email: email);
      // Cepat masuk dulu — sync & notif dijalankan di Dashboard (background)
      final userMap = user is Map ? Map<String, dynamic>.from(user as Map) : null;
      // ignore: unawaited_futures
      Future(() async {
        try {
          await AvatarPersist.restoreFromUserMap(uname, userMap);
        } catch (_) {}
        try {
          await ApiSync.syncOnLogin();
        } catch (_) {}
      });
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (_) => DashboardPage(token: token, showWelcomeFlow: true),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      await _showAlert(_friendlyError(e), title: 'Gagal Masuk');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _doRegister() async {
    if (!apiActive) {
      await _showServerDownDialog();
      return;
    }
    if (!_regForm.currentState!.validate()) return;
    setState(() => _loading = true);
    try {
      final res = await widget.apiClient.register(
        email: _regEmail.text.trim(),
        username: _regUser.text.trim(),
        password: _regPass.text,
      );
      final token = res['token'] as String;
      final user = res['user'];
      final uname = user is Map
          ? (user['username']?.toString() ?? _regUser.text.trim())
          : _regUser.text.trim();
      await SessionStore.saveLogin(
        token: token,
        username: uname,
        email: _regEmail.text.trim(),
      );
      final userMap = user is Map ? Map<String, dynamic>.from(user as Map) : null;
      // ignore: unawaited_futures
      Future(() async {
        try {
          await AvatarPersist.restoreFromUserMap(uname, userMap);
        } catch (_) {}
        try {
          await ApiSync.syncOnLogin();
        } catch (_) {}
      });
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (_) => DashboardPage(token: token, showWelcomeFlow: true),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      await _showAlert(_friendlyError(e), title: 'Gagal Daftar');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  InputDecoration _dec(String label, IconData icon, {Widget? suffix}) {
    return InputDecoration(
      labelText: label,
      labelStyle: const TextStyle(color: Colors.white70),
      prefixIcon: Icon(icon, color: Colors.white70),
      suffixIcon: suffix,
      filled: true,
      fillColor: Colors.white.withOpacity(0.10),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide(color: Colors.white.withOpacity(0.20)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: Color(0xFFFFD88A)),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: Colors.redAccent),
      ),
      focusedErrorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: Colors.redAccent),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset('assets/images/login_background.jpg', fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => const ColoredBox(color: Color(0xFF17121F))),
          Container(color: Colors.black.withOpacity(0.28)),
          SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(20, 20, 20, 28),
                keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(24),
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
                    child: Container(
                      constraints: const BoxConstraints(maxWidth: 400),
                      width: double.infinity,
                      padding: const EdgeInsets.fromLTRB(22, 22, 22, 28),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.12),
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(color: Colors.white24),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          const Center(
                            child: Text(
                              'KIRYO NIME',
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w900,
                                fontSize: 22,
                                letterSpacing: 1.2,
                              ),
                            ),
                          ),
                          const SizedBox(height: 6),
                          const Center(
                            child: Text(
                              'Masuk atau daftar akun',
                              style: TextStyle(color: Colors.white60, fontSize: 13),
                            ),
                          ),
                          const SizedBox(height: 16),
                          TabBar(
                            controller: _tab,
                            indicatorColor: const Color(0xFFFFD88A),
                            labelColor: const Color(0xFFFFD88A),
                            unselectedLabelColor: Colors.white54,
                            onTap: (_) => setState(() {}),
                            tabs: const [
                              Tab(text: 'Masuk'),
                              Tab(text: 'Daftar'),
                            ],
                          ),
                          const SizedBox(height: 16),
                          // Form aktif mengikuti tab — tinggi menyesuaikan (tidak terpotong)
                          AnimatedSize(
                            duration: const Duration(milliseconds: 220),
                            curve: Curves.easeInOut,
                            alignment: Alignment.topCenter,
                            child: _tab.index == 0
                                ? Form(
                                    key: _loginForm,
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.stretch,
                                      children: [
                                        TextFormField(
                                          controller: _loginUser,
                                          style: const TextStyle(color: Colors.white),
                                          decoration: _dec('Username', Icons.person_outline),
                                          textInputAction: TextInputAction.next,
                                          validator: (v) =>
                                              v == null || v.trim().isEmpty ? 'Username wajib' : null,
                                        ),
                                        const SizedBox(height: 14),
                                        TextFormField(
                                          controller: _loginPass,
                                          obscureText: _obscureLogin,
                                          style: const TextStyle(color: Colors.white),
                                          decoration: _dec(
                                            'Password',
                                            Icons.lock_outline,
                                            suffix: IconButton(
                                              icon: Icon(
                                                _obscureLogin
                                                    ? Icons.visibility
                                                    : Icons.visibility_off,
                                                color: Colors.white70,
                                              ),
                                              onPressed: () => setState(
                                                  () => _obscureLogin = !_obscureLogin),
                                            ),
                                          ),
                                          onFieldSubmitted: (_) => _loading ? null : _doLogin(),
                                          validator: (v) =>
                                              v == null || v.isEmpty ? 'Password wajib' : null,
                                        ),
                                        const SizedBox(height: 22),
                                        SizedBox(
                                          height: 54,
                                          child: ElevatedButton(
                                            style: ElevatedButton.styleFrom(
                                              backgroundColor: const Color(0xFFFFD88A),
                                              foregroundColor: const Color(0xFF17121F),
                                              elevation: 0,
                                              padding: const EdgeInsets.symmetric(
                                                  horizontal: 20, vertical: 14),
                                              shape: RoundedRectangleBorder(
                                                borderRadius: BorderRadius.circular(14),
                                              ),
                                            ),
                                            onPressed: _loading ? null : _doLogin,
                                            child: _loading
                                                ? const SizedBox(
                                                    width: 22,
                                                    height: 22,
                                                    child: CircularProgressIndicator(
                                                      strokeWidth: 2,
                                                      color: Color(0xFF17121F),
                                                    ),
                                                  )
                                                : const Text(
                                                    'MASUK',
                                                    style: TextStyle(
                                                      fontWeight: FontWeight.w900,
                                                      fontSize: 15,
                                                      letterSpacing: 0.8,
                                                    ),
                                                  ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  )
                                : Form(
                                    key: _regForm,
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.stretch,
                                      children: [
                                        TextFormField(
                                          controller: _regEmail,
                                          keyboardType: TextInputType.emailAddress,
                                          style: const TextStyle(color: Colors.white),
                                          decoration: _dec('Email', Icons.email_outlined),
                                          textInputAction: TextInputAction.next,
                                          validator: (v) {
                                            if (v == null || v.trim().isEmpty) {
                                              return 'Email wajib';
                                            }
                                            if (!v.contains('@')) return 'Email tidak valid';
                                            return null;
                                          },
                                        ),
                                        const SizedBox(height: 14),
                                        TextFormField(
                                          controller: _regUser,
                                          style: const TextStyle(color: Colors.white),
                                          decoration: _dec('Username', Icons.person_outline),
                                          textInputAction: TextInputAction.next,
                                          validator: (v) =>
                                              v == null || v.trim().isEmpty ? 'Username wajib' : null,
                                        ),
                                        const SizedBox(height: 14),
                                        TextFormField(
                                          controller: _regPass,
                                          obscureText: _obscureReg,
                                          style: const TextStyle(color: Colors.white),
                                          decoration: _dec(
                                            'Password',
                                            Icons.lock_outline,
                                            suffix: IconButton(
                                              icon: Icon(
                                                _obscureReg
                                                    ? Icons.visibility
                                                    : Icons.visibility_off,
                                                color: Colors.white70,
                                              ),
                                              onPressed: () =>
                                                  setState(() => _obscureReg = !_obscureReg),
                                            ),
                                          ),
                                          onFieldSubmitted: (_) =>
                                              _loading ? null : _doRegister(),
                                          validator: (v) {
                                            if (v == null || v.isEmpty) return 'Password wajib';
                                            if (v.length < 4) return 'Minimal 4 karakter';
                                            return null;
                                          },
                                        ),
                                        const SizedBox(height: 22),
                                        SizedBox(
                                          height: 54,
                                          child: ElevatedButton(
                                            style: ElevatedButton.styleFrom(
                                              backgroundColor: const Color(0xFFFFD88A),
                                              foregroundColor: const Color(0xFF17121F),
                                              elevation: 0,
                                              padding: const EdgeInsets.symmetric(
                                                  horizontal: 20, vertical: 14),
                                              shape: RoundedRectangleBorder(
                                                borderRadius: BorderRadius.circular(14),
                                              ),
                                            ),
                                            onPressed: _loading ? null : _doRegister,
                                            child: _loading
                                                ? const SizedBox(
                                                    width: 22,
                                                    height: 22,
                                                    child: CircularProgressIndicator(
                                                      strokeWidth: 2,
                                                      color: Color(0xFF17121F),
                                                    ),
                                                  )
                                                : const Text(
                                                    'DAFTAR',
                                                    style: TextStyle(
                                                      fontWeight: FontWeight.w900,
                                                      fontSize: 15,
                                                      letterSpacing: 0.8,
                                                    ),
                                                  ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
