/// Alamat panel API dapat diganti saat build menggunakan:
/// flutter build apk --dart-define=API_BASE_URL=https://panel.example.com
const String apiBaseUrl = String.fromEnvironment(
  'API_BASE_URL',
  defaultValue: 'http://console.jhonaleystore.id:2139',
);

/// Set ke `false` HANYA saat maintenance / server sengaja dimatikan.
/// Offline user (tidak ada internet) TIDAK memakai flag ini —
/// mereka tetap bisa buka offline library / data lokal.
const bool apiActive = true;
