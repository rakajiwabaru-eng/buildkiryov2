import 'package:flutter_local_notifications/flutter_local_notifications.dart';

/// Notifikasi sistem (muncul di luar APK: status bar / shade).
class AppNotifications {
  AppNotifications._();

  static final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();
  static bool _ready = false;
  static bool _permissionAsked = false;

  static const _chManga = 'manga_updates';
  static const _chAnime = 'anime_updates';
  static const _chLiveChart = 'livechart_releases';

  /// Init plugin + channel. Aman dipanggil berulang.
  static Future<void> init() async {
    if (_ready) return;
    try {
      const android = AndroidInitializationSettings('@mipmap/ic_launcher');
      await _plugin.initialize(
        const InitializationSettings(android: android),
      );
      final androidPlugin = _plugin.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();

      await androidPlugin?.createNotificationChannel(
        const AndroidNotificationChannel(
          _chManga,
          'Update Manga',
          description: 'Chapter baru di favorit / bookmark',
          importance: Importance.high,
          playSound: true,
          enableVibration: true,
          showBadge: true,
        ),
      );
      await androidPlugin?.createNotificationChannel(
        const AndroidNotificationChannel(
          _chAnime,
          'Update Anime',
          description: 'Episode anime baru',
          importance: Importance.high,
          playSound: true,
          enableVibration: true,
          showBadge: true,
        ),
      );
      await androidPlugin?.createNotificationChannel(
        const AndroidNotificationChannel(
          _chLiveChart,
          'Rilis Anime',
          description: 'Anime upcoming yang di-bookmark rilis',
          importance: Importance.high,
          playSound: true,
          enableVibration: true,
          showBadge: true,
        ),
      );
      _ready = true;
    } catch (_) {
      _ready = false;
    }
  }

  /// Tampilkan dialog sistem izinkan/tolak notifikasi (Android 13+).
  /// Panggil setelah login/daftar atau saat app buka dengan sesi aktif.
  static Future<bool> requestPermission() async {
    await init();
    _permissionAsked = true;
    try {
      final androidPlugin = _plugin.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();
      final granted =
          await androidPlugin?.requestNotificationsPermission() ?? true;
      return granted;
    } catch (_) {
      return false;
    }
  }

  static Future<void> ensurePermissionOnce() async {
    if (_permissionAsked) {
      await init();
      return;
    }
    await requestPermission();
  }

  static Future<void> showManga({
    required String title,
    required String body,
    required int id,
  }) =>
      _show(
        channelId: _chManga,
        channelName: 'Update Manga',
        title: title,
        body: body,
        id: id,
      );

  static Future<void> showAnime({
    required String title,
    required String body,
    required int id,
  }) =>
      _show(
        channelId: _chAnime,
        channelName: 'Update Anime',
        title: title,
        body: body,
        id: id,
      );

  static Future<void> showLiveChart({
    required String title,
    required String body,
    required int id,
  }) =>
      _show(
        channelId: _chLiveChart,
        channelName: 'Rilis Anime',
        title: title,
        body: body,
        id: id,
      );

  static Future<void> _show({
    required String channelId,
    required String channelName,
    required String title,
    required String body,
    required int id,
  }) async {
    try {
      await init();
      if (!_ready) return;
      await _plugin.show(
        id & 0x7fffffff,
        title,
        body,
        NotificationDetails(
          android: AndroidNotificationDetails(
            channelId,
            channelName,
            channelDescription: channelName,
            importance: Importance.high,
            priority: Priority.high,
            icon: '@mipmap/ic_launcher',
            playSound: true,
            enableVibration: true,
            category: AndroidNotificationCategory.recommendation,
            visibility: NotificationVisibility.public,
            ticker: title,
          ),
        ),
      );
    } catch (_) {}
  }
}
