import 'package:flutter/material.dart';

import 'api_config.dart';
import 'dashboard.dart';
import 'login.dart';
import 'avatar_persist.dart';
import 'session.dart';
import 'app_notifications.dart';
import 'app_update.dart';
import 'welcome_overlay.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Siapkan channel notifikasi sedini mungkin
  await AppNotifications.init();
  runApp(const FlutterBaseApp());
}

class FlutterBaseApp extends StatelessWidget {
  const FlutterBaseApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'KIRYO NIME',
      theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo), useMaterial3: true),
      home: const AuthGate(),
    );
  }
}

/// Cek sesi tersimpan: ada token → Dashboard, tidak ada → Login
class AuthGate extends StatefulWidget {
  const AuthGate({super.key});

  @override
  State<AuthGate> createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  @override
  void initState() {
    super.initState();
    _check();
  }

  Future<void> _check() async {
    // Maintenance manual (apiActive = false) → logout + dialog server mati.
    // Offline / tidak ada internet TIDAK masuk ke sini — user tetap bisa
    // masuk dashboard pakai sesi lokal & fitur offline.
    if (!apiActive) {
      await SessionStore.clear();
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (_) => const LoginPage(serverDown: true),
        ),
      );
      return;
    }

    // Cek versi APK dulu. Kalau versi lama → notifikasi wajib update dan
    // tidak bisa ditutup sampai user update ke versi terbaru.
    // ignore: unawaited_futures
    Future.delayed(const Duration(milliseconds: 400), () {
      if (mounted) AppUpdate.enforce(context);
    });
    final token = await SessionStore.getToken();
    if (!mounted) return;
    if (token != null && token.isNotEmpty) {
      // Minta izin notifikasi (dialog sistem Izinkan/Tolak)
      // Masuk cepat ke beranda — notif + sambutan di atas dashboard
      final uname = await SessionStore.getUsername();
      if (uname != null && uname.isNotEmpty) {
        // ignore: unawaited_futures
        AvatarPersist.restore(uname).catchError((_) => null);
      }
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (_) => DashboardPage(token: token, showWelcomeFlow: true),
        ),
      );
    } else {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const LoginPage()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: Color(0xFF17121F),
      body: Center(
        child: CircularProgressIndicator(color: Color(0xFFFFD88A)),
      ),
    );
  }
}
