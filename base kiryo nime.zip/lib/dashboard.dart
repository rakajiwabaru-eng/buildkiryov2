import 'package:flutter/material.dart';

import 'account.dart';
import 'blue_archive.dart';
import 'tiktok.dart';
import 'musictiktok.dart';
import 'presetam.dart';
import 'anime.dart';
import 'manga.dart';
import 'livechart.dart';
import 'library_hub.dart';
import 'net_status.dart';
import 'app_notifications.dart';
import 'app_update.dart';
import 'welcome_overlay.dart';
import 'api_sync.dart';
import 'app_features.dart';
import 'local_library.dart';


class DashboardPage extends StatefulWidget {
  const DashboardPage({
    super.key,
    required this.token,
    this.showWelcomeFlow = false,
  });

  final String token;
  /// true = tampilkan izin notifikasi + sambutan di atas beranda
  final bool showWelcomeFlow;

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with WidgetsBindingObserver {
  /// 0 = Dashboard (rumah), 1 = Tools (perkakas)
  int _currentIndex = 0;
  late final PageController _pageController;
  bool _online = true;
  bool _checkingNet = false;
  List<Map<String, dynamic>> _continueList = [];
  List<dynamic> _freshFavs = [];
  int _queuePending = 0;


  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _pageController = PageController();
    _checkNet();
    _loadFeatureCards();
    // Setelah beranda tampil: izin notif + sambutan + cek update
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (!mounted) return;
      try {
        await AppNotifications.requestPermission();
      } catch (_) {}
      if (!mounted) return;
      try {
        await WelcomeOverlay.showIfNeeded(context);
      } catch (_) {}
      if (!mounted) return;
      await _runBackgroundChecks();
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _runBackgroundChecks();
    }
  }

  
  Future<void> _runWelcomeFlowIfNeeded() async {
    if (!widget.showWelcomeFlow) return;
    // Beranda sudah terlihat di belakang
    try {
      await AppNotifications.requestPermission();
    } catch (_) {}
    if (!mounted) return;
    try {
      await WelcomeOverlay.showIfNeeded(context);
    } catch (_) {}
    // Sync data di belakang layar (tidak tahan UI)
    // ignore: unawaited_futures
    ApiSync.syncOnLogin().catchError((_) {});
  }

  Future<void> _runBackgroundChecks() async {
    // Notifikasi wajib update muncul lagi setiap app dibuka/kembali aktif.
    if (mounted) {
      // ignore: unawaited_futures
      AppUpdate.enforce(context);
    }
    try {
      await AppNotifications.init();
      await LiveChartBookmarkStore.checkReleases();
    } catch (_) {}
  }


  Future<void> _loadFeatureCards() async {
    try {
      final cont = await WatchProgressStore.continueList(max: 8);
      final favs = await AnimeFavoriteStore.list();
      var fresh = <dynamic>[];
      try {
        fresh = await AnimeFavoriteStore.checkUpdates(const AnimeApiClient());
      } catch (_) {}
      final q = DownloadQueue.instance;
      await q.load();
      final lines = <String>[];
      for (final f in favs.take(5)) {
        final ep = f.latestEpisode ?? '';
        lines.add(ep.isEmpty ? f.title : '${f.title} — $ep');
      }
      await WidgetBridge.update(favoriteLines: lines, favoriteCount: favs.length);
      if (!mounted) return;
      setState(() {
        _continueList = cont;
        _freshFavs = fresh;
        _queuePending = q.pendingCount;
      });
    } catch (_) {}
  }

  Future<void> _checkNet() async {
    if (_checkingNet) return;
    setState(() => _checkingNet = true);
    final ok = await NetStatus.hasConnection();
    if (!mounted) return;
    setState(() {
      _online = ok;
      _checkingNet = false;
    });
  }

  void _openDownloads() {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const LibraryHubPage()),
    );
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _pageController.dispose();
    super.dispose();
  }

  void _goTab(int index) {
    if (index == _currentIndex) return;
    setState(() => _currentIndex = index);
    // Tombol: animasi singkat; geser jari tetap native PageView (mulus)
    _pageController.animateToPage(
      index,
      duration: const Duration(milliseconds: 120),
      curve: Curves.easeOutCubic,
    );
  }
  Future<void> _openAccount() async {
    // Tanpa geser — langsung tampil (fade singkat)
    final changed = await Navigator.of(context).push<bool>(
      PageRouteBuilder<bool>(
        pageBuilder: (_, __, ___) => const AccountPage(),
        transitionDuration: const Duration(milliseconds: 180),
        reverseTransitionDuration: const Duration(milliseconds: 150),
        transitionsBuilder: (_, anim, __, child) =>
            FadeTransition(opacity: anim, child: child),
      ),
    );
  }

  Widget _bottomItem({
    required bool selected,
    required IconData icon,
    required IconData selectedIcon,
    required String label,
    required VoidCallback onTap,
  }) {
    final color = selected ? const Color(0xFFFFD88A) : Colors.white70;
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 120),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              decoration: BoxDecoration(
                color: selected ? Colors.white.withOpacity(0.16) : Colors.transparent,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Icon(selected ? selectedIcon : icon, color: color, size: 24),
            ),
            const SizedBox(height: 4),
            Text(
              label,
              style: TextStyle(color: color, fontWeight: FontWeight.w700, fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF17121F),
      body: Stack(
        fit: StackFit.expand,
        children: [
          // ===== FOTO LATAR FULL LAYAR (ukuran pas layar HP) =====
          Positioned.fill(
            child: Image.asset(
              'assets/images/dashboard_background.jpg',
              fit: BoxFit.cover,
              alignment: Alignment.center,
              errorBuilder: (_, __, ___) =>
                  Container(color: const Color(0xFF17121F)),
            ),
          ),

          // ===== LAPISAN GELAP AGAR TEKS TETAP TERBACA =====
          const DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0x66000000), Color(0x33000000), Color(0x59000000)],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
          ),

          // ===== ISI (tanpa header avatar/nama — konten langsung ke atas) =====
          SafeArea(
            bottom: false,
            child: PageView(
              controller: _pageController,
              physics: const BouncingScrollPhysics(
                parent: PageScrollPhysics(),
              ),
              allowImplicitScrolling: true,
              onPageChanged: (i) {
                if (_currentIndex != i) {
                  setState(() => _currentIndex = i);
                }
              },
              children: [
                RepaintBoundary(
                  child: _online
                      ? _buildDashboardTab()
                      : NoConnectionView(onRetry: _checkNet, busy: _checkingNet),
                ),
                RepaintBoundary(
                  child: _online
                      ? _buildToolsTab()
                      : NoConnectionView(onRetry: _checkNet, busy: _checkingNet),
                ),
              ],
            ),
          ),
        ],
      ),

      // ===== NAVIGASI BAWAH: Dashboard | Tools | Account =====
      bottomNavigationBar: Container(
            color: const Color(0xE6120E18),
            padding: const EdgeInsets.fromLTRB(8, 6, 8, 10),
            child: Row(
              children: [
                Expanded(child: _bottomItem(
                  selected: _currentIndex == 0,
                  icon: Icons.home_outlined,
                  selectedIcon: Icons.home_rounded,
                  label: 'Dashboard',
                  onTap: () => _goTab(0),
                )),
                Expanded(child: _bottomItem(
                  selected: _currentIndex == 1,
                  icon: Icons.handyman_outlined,
                  selectedIcon: Icons.handyman_rounded,
                  label: 'Tools',
                  onTap: () => _goTab(1),
                )),
                Expanded(child: _bottomItem(
                  selected: false,
                  icon: Icons.download_outlined,
                  selectedIcon: Icons.download_rounded,
                  label: 'Unduhan Saya',
                  onTap: _openDownloads,
                )),
                Expanded(child: _bottomItem(
                  selected: false,
                  icon: Icons.account_circle_outlined,
                  selectedIcon: Icons.account_circle_rounded,
                  label: 'Account',
                  onTap: _openAccount,
                )),
              ],
            ),
      ),
    );
  }


  /// ===== TAB DASHBOARD (ikon rumah) =====
  Widget _buildDashboardTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(22, 16, 22, 28),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Banner anime + manga langsung di atas (header avatar dihapus)
          _buildContinueCard(),
          _buildScheduleCard(),
          _buildQuickToolsRow(),
          _buildAnimeBannerCard(),
          const SizedBox(height: 16),
          _buildMangaBannerCard(),
          const SizedBox(height: 16),
          _buildUpcomingAnimeBannerCard(),
        ],
      ),
    );
  }

  /// Kartu banner anime yang lebih menarik (glass + shadow + glow)

  Widget _buildContinueCard() {
    if (_continueList.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Lanjut nonton', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 16)),
          const SizedBox(height: 10),
          SizedBox(
            height: 120,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: _continueList.length,
              separatorBuilder: (_, __) => const SizedBox(width: 10),
              itemBuilder: (ctx, i) {
                final e = _continueList[i];
                final title = '${e['animeTitle'] ?? e['title'] ?? ''}';
                final ep = '${e['episodeTitle'] ?? ''}';
                final ratio = (e['ratio'] is num) ? (e['ratio'] as num).toDouble() : 0.0;
                return Container(
                  width: 200,
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: const Color(0xFF241C2C),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: Colors.white10),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13)),
                      const SizedBox(height: 4),
                      Text(ep, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white54, fontSize: 11)),
                      const Spacer(),
                      LinearProgressIndicator(value: ratio.clamp(0.0, 1.0), backgroundColor: Colors.white12, color: const Color(0xFFFFD88A)),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildScheduleCard() {
    if (_freshFavs.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: const Color(0xFF241C2C),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: const Color(0xFFFFD88A).withOpacity(0.35)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(children: [
              Icon(Icons.notifications_active_rounded, color: Color(0xFFFFD88A), size: 18),
              SizedBox(width: 8),
              Text('Episode baru di favorit', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
            ]),
            const SizedBox(height: 10),
            for (final f in _freshFavs.take(5))
              Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Text(
                  () {
                    final title = '${f.title}';
                    final ep = '${f.latestEpisode ?? ''}';
                    return ep.isEmpty ? '• $title' : '• $title — $ep';
                  }(),
                  style: const TextStyle(color: Colors.white70, fontSize: 13),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickToolsRow() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
      child: Row(
        children: [
          Expanded(child: _miniTool(Icons.queue_rounded, _queuePending > 0 ? 'Antrian ($_queuePending)' : 'Antrian', () {
            Navigator.of(context).push(MaterialPageRoute(builder: (_) => const DownloadQueuePage()));
          })),
          const SizedBox(width: 10),
          Expanded(child: _miniTool(Icons.bar_chart_rounded, 'Statistik', () {
            Navigator.of(context).push(MaterialPageRoute(builder: (_) => const StatsPage()));
          })),
        ],
      ),
    );
  }

  Widget _miniTool(IconData icon, String label, VoidCallback onTap) {
    return Material(
      color: const Color(0xFF241C2C),
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
          child: Row(children: [
            Icon(icon, color: const Color(0xFFFFD88A), size: 20),
            const SizedBox(width: 10),
            Expanded(child: Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13))),
          ]),
        ),
      ),
    );
  }

  Widget _buildAnimeBannerCard() {
    return _GlassBox(
      borderRadius: 22,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(22),
          onTap: () {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => const AnimeOngoingPage(),
              ),
            );
          },
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: Colors.white.withOpacity(0.22)),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFFFF4D9E).withOpacity(0.25),
                  blurRadius: 12,
                  spreadRadius: 0,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(22),
              child: Stack(
                children: [
                  // Banner image
                  AspectRatio(
                    aspectRatio: 16 / 9,
                    child: Image.asset(
                      'assets/images/anime_banner.png',
                      fit: BoxFit.cover,
                      width: double.infinity,
                      filterQuality: FilterQuality.low,
                      gaplessPlayback: true,
                    ),
                  ),
                  // Gradient overlay biar teks/ikon tetap kebaca
                  Positioned.fill(
                    child: DecoratedBox(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Colors.black.withOpacity(0.05),
                            Colors.black.withOpacity(0.55),
                          ],
                          stops: const [0.55, 1],
                        ),
                      ),
                    ),
                  ),
                  // Label kecil di pojok
                  Positioned(
                    left: 14,
                    bottom: 14,
                    right: 14,
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                          decoration: BoxDecoration(
                            color: const Color(0xFFFF4D9E).withOpacity(0.9),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: const Text(
                            'STREAMING LENGKAP',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w800,
                              fontSize: 11,
                              letterSpacing: 0.4,
                            ),
                          ),
                        ),
                        const Spacer(),
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.45),
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.white30),
                          ),
                          child: const Icon(
                            Icons.play_arrow_rounded,
                            color: Color(0xFFFFD88A),
                            size: 22,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  /// Kartu banner manga / manhua / manhwa
  Widget _buildMangaBannerCard() {
    return _GlassBox(
      borderRadius: 22,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(22),
          onTap: () {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => const MangaHomePage(),
              ),
            );
          },
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: Colors.white.withOpacity(0.22)),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFF5B8CFF).withOpacity(0.28),
                  blurRadius: 12,
                  spreadRadius: 0,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(22),
              child: Stack(
                children: [
                  AspectRatio(
                    aspectRatio: 16 / 9,
                    child: Image.asset(
                      'assets/images/manga_banner.png',
                      fit: BoxFit.cover,
                      width: double.infinity,
                      filterQuality: FilterQuality.low,
                      gaplessPlayback: true,
                    ),
                  ),
                  Positioned.fill(
                    child: DecoratedBox(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Colors.black.withOpacity(0.05),
                            Colors.black.withOpacity(0.55),
                          ],
                          stops: const [0.55, 1],
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    left: 14,
                    bottom: 14,
                    right: 14,
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                          decoration: BoxDecoration(
                            color: const Color(0xFF5B8CFF).withOpacity(0.92),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: const Text(
                            'BACA KOMIK',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w800,
                              fontSize: 11,
                              letterSpacing: 0.4,
                            ),
                          ),
                        ),
                        const Spacer(),
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.45),
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.white30),
                          ),
                          child: const Icon(
                            Icons.menu_book_rounded,
                            color: Color(0xFFFFD88A),
                            size: 20,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }


  /// Banner anime yang akan datang (LiveChart.me)
  Widget _buildUpcomingAnimeBannerCard() {
    return _GlassBox(
      borderRadius: 22,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(22),
          onTap: () {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => const UpcomingAnimePage(),
              ),
            );
          },
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: Colors.white.withOpacity(0.22)),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFFFF9A3C).withOpacity(0.28),
                  blurRadius: 12,
                  spreadRadius: 0,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(22),
              child: Stack(
                children: [
                  AspectRatio(
                    aspectRatio: 16 / 9,
                    child: Image.asset(
                      'assets/images/upcoming_anime_banner.png',
                      fit: BoxFit.cover,
                      width: double.infinity,
                      filterQuality: FilterQuality.low,
                      gaplessPlayback: true,
                      errorBuilder: (_, __, ___) => Container(
                        decoration: const BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [
                              Color(0xFF5C3A1A),
                              Color(0xFF2A1810),
                              Color(0xFF1A1020),
                            ],
                          ),
                        ),
                        child: const Center(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.calendar_month_rounded,
                                  color: Color(0xFFFFD88A), size: 40),
                              SizedBox(height: 8),
                              Text(
                                'Anime yang akan datang',
                                style: TextStyle(
                                  color: Color(0xFFFFD88A),
                                  fontWeight: FontWeight.w800,
                                  fontSize: 14,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned.fill(
                    child: DecoratedBox(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Colors.black.withOpacity(0.05),
                            Colors.black.withOpacity(0.55),
                          ],
                          stops: const [0.55, 1],
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    left: 14,
                    bottom: 14,
                    right: 14,
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 5),
                          decoration: BoxDecoration(
                            color: const Color(0xFFFF9A3C).withOpacity(0.92),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: const Text(
                            'SEASON BARU',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w800,
                              fontSize: 11,
                              letterSpacing: 0.4,
                            ),
                          ),
                        ),
                        const Spacer(),
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.45),
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.white30),
                          ),
                          child: const Icon(
                            Icons.calendar_month_rounded,
                            color: Color(0xFFFFD88A),
                            size: 20,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  /// ===== TAB TOOLS (ikon tools) =====
  Widget _buildToolsTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(22, 16, 22, 30),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Kartu tools langsung di atas (header avatar/judul dihapus)
          _buildToolCard(
            icon: Icons.play_circle_fill_rounded,
            title: 'TikTok No Watermark',
            subtitle: 'Simpan video TikTok tanpa watermark',
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => TikTokPage(token: widget.token))),
          ),
          const SizedBox(height: 14),
          _buildToolCard(
            icon: Icons.music_note_rounded,
            title: 'Download Musik TikTok',
            subtitle: 'Ambil audio dari video TikTok',
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => TikTokMusicPage(token: widget.token))),
          ),
          const SizedBox(height: 14),
          _buildToolCard(
            icon: Icons.auto_awesome_rounded,
            title: 'Cari Preset Alight Motion',
            subtitle: 'Cari preset dari komentar TikTok',
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => PresetAMPage(token: widget.token))),
          ),
          const SizedBox(height: 14),
          _buildToolCard(
            icon: Icons.photo_library_rounded,
            title: 'Blue Archive Random',
            subtitle: 'Foto karakter Blue Archive acak',
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const BlueArchivePage()),
            ),
          ),
        ],
      ),
    );
  }

  /// Kartu satu tools (dipakai ulang oleh semua tools)
  Widget _buildToolCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return _GlassBox(
      borderRadius: 24,
      child: Material(
        color: Colors.white.withOpacity(0.14),
        borderRadius: BorderRadius.circular(24),
        child: InkWell(
          borderRadius: BorderRadius.circular(24),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Row(
              children: [
                Container(
                  width: 58,
                  height: 58,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: Colors.white.withOpacity(0.3)),
                  ),
                  child: Icon(icon, color: const Color(0xFFFFD88A), size: 32),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: Colors.white)),
                      const SizedBox(height: 5),
                      Text(subtitle, style: const TextStyle(color: Colors.white70, height: 1.3)),
                    ],
                  ),
                ),
                const Icon(Icons.arrow_forward_ios_rounded, size: 18, color: Colors.white70),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Kotak kaca ringan (tanpa BackdropFilter biar geser tab tetap mulus)
class _GlassBox extends StatelessWidget {
  const _GlassBox({required this.child, required this.borderRadius});

  final Widget child;
  final double borderRadius;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(borderRadius),
      child: DecoratedBox(
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.10),
          borderRadius: BorderRadius.circular(borderRadius),
        ),
        child: child,
      ),
    );
  }
}
