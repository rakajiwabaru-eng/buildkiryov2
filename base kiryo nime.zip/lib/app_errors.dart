import 'dart:io';

/// Pesan error yang jelas untuk user.
class AppErrors {
  static String describe(Object error) {
    final raw = error.toString().replaceFirst('Exception: ', '');
    final low = raw.toLowerCase();

    if (low.contains('socketexception') ||
        low.contains('failed host lookup') ||
        low.contains('network is unreachable') ||
        low.contains('connection refused') ||
        low.contains('connection reset') ||
        low.contains('timed out') ||
        low.contains('timeout')) {
      return 'Tidak ada internet / koneksi bermasalah. Cek Wi-Fi atau data seluler.';
    }

    if (low.contains('permission') ||
        low.contains('errno = 13') ||
        low.contains('read-only') ||
        low.contains('operation not permitted')) {
      return 'Tidak bisa menulis file. Izinkan akses penyimpanan di pengaturan app.';
    }

    if (low.contains('no space') ||
        low.contains('enospc') ||
        low.contains('storage penuh') ||
        low.contains('not enough space')) {
      return 'Storage penuh. Hapus file lama lalu coba lagi.';
    }

    if (low.contains('halaman web') ||
        low.contains('bukan file video') ||
        low.contains('konten tidak valid') ||
        low.contains('link host') ||
        low.contains('tidak ada link video') ||
        low.contains('unexpected token') ||
        low.contains('doctype') ||
        low.contains('bukan json') ||
        low.contains('not valid json') ||
        low.contains('formatexception')) {
      return 'Server mengembalikan data tidak valid (bukan JSON). Coba lagi sebentar atau ganti link.';
    }

    if (low.contains('404') || low.contains('not found')) {
      return 'Data tidak ditemukan (mungkin dihapus dari server).';
    }

    if (low.contains('401') || low.contains('403') || low.contains('unauthorized')) {
      return 'Akses ditolak server. Coba login ulang atau ganti sumber.';
    }

    if (raw.trim().isEmpty) return 'Terjadi kesalahan. Coba lagi.';
    return raw;
  }

  static bool isNetwork(Object error) {
    final d = describe(error).toLowerCase();
    return d.contains('internet') || d.contains('koneksi');
  }

  static Future<bool> isStorageFull(String path) async {
    try {
      // rough probe
      final f = File('$path/.space_probe');
      await f.writeAsBytes(List.filled(64 * 1024, 0), flush: true);
      await f.delete();
      return false;
    } catch (e) {
      final low = e.toString().toLowerCase();
      return low.contains('no space') || low.contains('enospc');
    }
  }
}
