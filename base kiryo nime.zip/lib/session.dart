import 'package:shared_preferences/shared_preferences.dart';

/// Sesi login + profil lokal.
/// PP dan data user disimpan **per username**.
class SessionStore {
  static const _keyToken = 'auth_token';
  static const _keyUsername = 'auth_username';
  static const _keyEmail = 'auth_email';
  static const _keyPassword = 'profile_password';
  static const _keyAvatarLegacy = 'profile_avatar_global';
  static const _keyAvatarVeryOld = 'profile_avatar';

  static const defaultAvatar = 'assets/images/default_avatar.jpg';

  static String _avatarKey(String username) {
    final safe =
        username.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9_-]'), '_');
    return 'profile_avatar_user_$safe';
  }

  /// Username aman untuk key SharedPreferences.
  static String safeUser(String username) {
    return username.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9_-]'), '_');
  }

  static Future<void> saveLogin({
    required String token,
    String? username,
    String? email,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyToken, token);
    if (username != null && username.isNotEmpty) {
      await prefs.setString(_keyUsername, username);
    }
    if (email != null && email.isNotEmpty) {
      await prefs.setString(_keyEmail, email);
    }
  }

  static Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    final t = prefs.getString(_keyToken);
    if (t == null || t.isEmpty) return null;
    return t;
  }

  static Future<String?> getUsername() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_keyUsername);
  }

  static Future<String?> getEmail() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_keyEmail);
  }

  /// Hanya avatar milik username tersebut.
  static Future<String> getAvatar({String? username}) async {
    final prefs = await SharedPreferences.getInstance();
    final uname = (username ?? prefs.getString(_keyUsername) ?? '').trim();
    if (uname.isEmpty) return defaultAvatar;
    final perUser = prefs.getString(_avatarKey(uname));
    if (perUser != null && perUser.isNotEmpty) return perUser;
    return defaultAvatar;
  }

  static Future<void> updateProfile({
    String? username,
    String? avatarAsset,
    String? password,
    String? email,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    if (username != null && username.trim().isNotEmpty) {
      await prefs.setString(_keyUsername, username.trim());
    }
    if (email != null && email.isNotEmpty) {
      await prefs.setString(_keyEmail, email);
    }
    if (password != null && password.isNotEmpty) {
      await prefs.setString(_keyPassword, password);
    }
    if (avatarAsset != null && avatarAsset.isNotEmpty) {
      final uname = (username ?? prefs.getString(_keyUsername) ?? '').trim();
      if (uname.isNotEmpty) {
        await prefs.setString(_avatarKey(uname), avatarAsset);
      }
      await prefs.remove(_keyAvatarLegacy);
      await prefs.remove(_keyAvatarVeryOld);
    }
  }

  static Future<void> setDefaultAvatar(String username) async {
    final uname = username.trim();
    if (uname.isEmpty) return;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_avatarKey(uname), defaultAvatar);
    await prefs.remove(_keyAvatarLegacy);
    await prefs.remove(_keyAvatarVeryOld);
  }

  static Future<void> clear() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_keyToken);
    await prefs.remove(_keyUsername);
    await prefs.remove(_keyEmail);
    await prefs.remove(_keyPassword);
    await prefs.remove(_keyAvatarLegacy);
    await prefs.remove(_keyAvatarVeryOld);
  }
}

/// Key SharedPreferences yang di-scope per username aktif.
/// Akun A dan B tidak saling melihat data favorit / history / progress.
class UserDataKeys {
  static Future<String> of(String base) async {
    final u = await SessionStore.getUsername();
    final safe = SessionStore.safeUser(u ?? '');
    if (safe.isEmpty) return '${base}__guest';
    return '${base}__u_$safe';
  }
}

/// Preferensi lokal (baca manga, notifikasi).
class AppPrefs {
  static const _kNotifChapter = 'pref_notif_chapter';
  static const _kNotifComment = 'pref_notif_comment';
  static const _kOrientation = 'pref_reader_orientation';

  static Future<bool> getNotifChapter() async {
    final p = await SharedPreferences.getInstance();
    return p.getBool(_kNotifChapter) ?? true;
  }

  static Future<void> setNotifChapter(bool v) async {
    final p = await SharedPreferences.getInstance();
    await p.setBool(_kNotifChapter, v);
  }

  static Future<bool> getNotifComment() async {
    final p = await SharedPreferences.getInstance();
    return p.getBool(_kNotifComment) ?? true;
  }

  static Future<void> setNotifComment(bool v) async {
    final p = await SharedPreferences.getInstance();
    await p.setBool(_kNotifComment, v);
  }

  static Future<String> getOrientation() async {
    final p = await SharedPreferences.getInstance();
    return p.getString(_kOrientation) ?? 'system';
  }

  static Future<void> setOrientation(String v) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_kOrientation, v);
  }
}
