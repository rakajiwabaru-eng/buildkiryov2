import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';

import 'api_config.dart';
import 'app_paths.dart';
import 'session.dart';

/// PP: simpan lokal per-user, upload ke API (timpa avatar lama di server).
/// Saat login ulang / install ulang APK → [restore] / [applyFromServer]
/// mengambil data URL dari server dan menulis ulang file lokal.
class AvatarPersist {
  static Future<Uint8List> _shrink(Uint8List src, {int maxSide = 480}) async {
    try {
      final codec = await ui.instantiateImageCodec(
        src,
        targetWidth: maxSide,
        targetHeight: maxSide,
      );
      final frame = await codec.getNextFrame();
      final img = frame.image;
      final bd = await img.toByteData(format: ui.ImageByteFormat.png);
      img.dispose();
      if (bd == null) return src;
      return bd.buffer.asUint8List();
    } catch (_) {
      return src;
    }
  }

  static Future<String> _localPathFor(String username) async {
    try {
      return await AppPaths.avatarFile(username);
    } catch (_) {
      final docs = await _docsProfileDir();
      final safe =
          username.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9_-]'), '_');
      return '${docs.path}/avatar_$safe.png';
    }
  }

  /// Path file LOKAL BARU yang UNIK setiap simpan.
  /// Path tetap (avatar_kiryo.jpg) membuat cache gambar Flutter menampilkan
  /// byte lama / layar hitam sampai app direstart — karena itu path dibuat
  /// unik per-simpan agar tidak pernah menimpa file yang sedang dirender.
  static Future<String> _newLocalPathFor(String username) async {
    final base = await _localPathFor(username);
    final dot = base.lastIndexOf('.');
    final stem = dot > 0 ? base.substring(0, dot) : base;
    final ext = dot > 0 ? base.substring(dot) : '.png';
    return '${stem}_${DateTime.now().millisecondsSinceEpoch}$ext';
  }

  /// LANGKAH 1 (instan): tulis file lokal per-user, return path-nya.
  /// Dipanggil SEBELUM setState supaya UI langsung menampilkan foto baru.
  static Future<String> writeLocalOnly({
    required String sourcePath,
    required String username,
  }) async {
    final src = File(sourcePath);
    if (!await src.exists()) {
      throw Exception('File foto tidak ditemukan');
    }

    var bytes = await src.readAsBytes();
    if (bytes.isEmpty) throw Exception('File foto kosong');
    bytes = await _shrink(bytes, maxSide: 480);
    if (bytes.length > 900 * 1024) {
      bytes = await _shrink(bytes, maxSide: 320);
    }

    final localPath = await _newLocalPathFor(username);
    await File(localPath).writeAsBytes(bytes, flush: true);
    if (!await File(localPath).exists()) {
      throw Exception('Gagal menulis foto profil');
    }
    return localPath;
  }

  /// LANGKAH 2 (background): simpan ke SessionStore + upload ke API
  /// (timpa avatar lama di server), lalu hapus file lama user ini.
  static Future<void> persistExisting({
    required String localPath,
    required String username,
  }) async {
    try {
      final old = await SessionStore.getAvatar(username: username);
      await SessionStore.updateProfile(
        username: username,
        avatarAsset: localPath,
      );
      if (old.isNotEmpty &&
          !old.startsWith('assets/') &&
          old != localPath &&
          await File(old).exists()) {
        try {
          await File(old).delete();
        } catch (_) {}
      }

      // Upload ke server — TIMPA avatar lama di profile
      final token = await SessionStore.getToken();
      if (token != null && token.isNotEmpty) {
        final bytes = await File(localPath).readAsBytes();
        final dataUrl = 'data:image/png;base64,${base64Encode(bytes)}';
        final res = await http
            .put(
              Uri.parse('$apiBaseUrl/api/me/profile'),
              headers: {
                'Content-Type': 'application/json; charset=utf-8',
                'Authorization': 'Bearer $token',
                'Accept': 'application/json',
              },
              body: jsonEncode({'avatar': dataUrl}),
            )
            .timeout(const Duration(seconds: 45));
        if (res.statusCode < 200 || res.statusCode >= 300) {
          // lokal sudah OK; server gagal tidak gagalkan UI
        }
      }
    } catch (_) {}
  }

  /// Versi gabungan (dipakai caller lama): tulis lokal + SessionStore + upload.
  static Future<String> persist({
    required String sourcePath,
    required String username,
  }) async {
    final localPath =
        await writeLocalOnly(sourcePath: sourcePath, username: username);
    await persistExisting(localPath: localPath, username: username);
    return localPath;
  }

  static Future<Directory> _docsProfileDir() async {
    try {
      return await AppPaths.avatars();
    } catch (_) {}
    final docs = await getApplicationDocumentsDirectory();
    final d = Directory('${docs.path}/profile');
    if (!await d.exists()) await d.create(recursive: true);
    return d;
  }

  /// Tulis bytes (dari data URL server) ke disk + SessionStore.
  static Future<String?> applyFromServer({
    required String username,
    required String dataUrlOrPath,
  }) async {
    final avatar = dataUrlOrPath.trim();
    if (avatar.isEmpty) return null;

    // Sudah path lokal yang masih ada
    if (!avatar.startsWith('data:image') &&
        !avatar.startsWith('http') &&
        await File(avatar).exists()) {
      await SessionStore.updateProfile(
        username: username,
        avatarAsset: avatar,
      );
      return avatar;
    }

    if (!avatar.startsWith('data:image')) return null;

    final comma = avatar.indexOf(',');
    if (comma < 0) return null;
    Uint8List raw;
    try {
      raw = base64Decode(avatar.substring(comma + 1));
    } catch (_) {
      return null;
    }
    if (raw.isEmpty) return null;

    final local = await _localPathFor(username);
    await File(local).writeAsBytes(raw, flush: true);
    await SessionStore.updateProfile(username: username, avatarAsset: local);
    return local;
  }

  /// Ambil PP dari GET /api/me lalu simpan lokal (untuk install ulang / login ulang).
  static Future<String?> restore(String username) async {
    final token = await SessionStore.getToken();
    if (token == null || token.isEmpty) return null;

    try {
      final res = await http
          .get(
            Uri.parse('$apiBaseUrl/api/me'),
            headers: {
              'Authorization': 'Bearer $token',
              'Accept': 'application/json',
            },
          )
          .timeout(const Duration(seconds: 20));

      if (res.statusCode < 200 || res.statusCode >= 300) return null;
      final body = jsonDecode(res.body);
      if (body is! Map || body['ok'] != true || body['user'] is! Map) {
        return null;
      }

      final profile = body['user']['profile'];
      final avatar = profile is Map ? profile['avatar']?.toString() : null;
      if (avatar == null || avatar.isEmpty) return null;

      return applyFromServer(username: username, dataUrlOrPath: avatar);
    } catch (_) {
      return null;
    }
  }

  /// Pakai object user dari response login/register (hemat 1 request).
  static Future<String?> restoreFromUserMap(
    String username,
    Map? user,
  ) async {
    if (user == null) return restore(username);
    final profile = user['profile'];
    final avatar = profile is Map ? profile['avatar']?.toString() : null;
    if (avatar != null && avatar.isNotEmpty) {
      final path =
          await applyFromServer(username: username, dataUrlOrPath: avatar);
      if (path != null) return path;
    }
    return restore(username);
  }
}
