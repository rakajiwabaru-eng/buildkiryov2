import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:url_launcher/url_launcher.dart';

import 'net_status.dart';
import 'api_sync.dart';
import 'app_notifications.dart';

/// Data anime upcoming dari LiveChart.me
class LiveChartAnime {
  const LiveChartAnime({
    required this.id,
    required this.title,
    this.englishTitle,
    this.nativeTitle,
    this.posterUrl,
    this.premiereUnix,
    this.scheduleLabel,
    this.tags = const [],
  });

  final int id;
  final String title;
  final String? englishTitle;
  final String? nativeTitle;
  final String? posterUrl;
  final int? premiereUnix;
  final String? scheduleLabel;
  final List<String> tags;

  DateTime? get premiereAt {
    final u = premiereUnix;
    if (u == null || u <= 0) return null;
    return DateTime.fromMillisecondsSinceEpoch(u * 1000, isUtc: true).toLocal();
  }

  String get countdownText {
    final t = premiereAt;
    if (t == null) return '';
    final d = t.difference(DateTime.now());
    if (d.isNegative) {
      final ago = d.abs();
      if (ago.inDays > 0) return 'Sudah tayang · ${ago.inDays}h lalu';
      return 'Sudah tayang';
    }
    final days = d.inDays;
    final hours = d.inHours % 24;
    final mins = d.inMinutes % 60;
    if (days > 0) return '${days}d ${hours}h ${mins}m';
    if (hours > 0) return '${hours}h ${mins}m';
    return '${mins}m';
  }

  String get posterLarge {
    final p = posterUrl ?? '';
    if (p.isEmpty) return '';
    if (p.contains('/small.')) return p.replaceFirst('/small.', '/large.');
    if (p.endsWith('.jpg') || p.endsWith('.webp')) {
      if (!p.contains('/large.') && !p.contains('/small.')) {
        return '$p/large.jpg';
      }
    }
    return p;
  }
}

class LiveChartSeason {
  const LiveChartSeason({
    required this.slug,
    required this.title,
    this.year,
    this.season,
    this.startDate,
    this.endDate,
    this.nextSlug,
    this.prevSlug,
  });

  final String slug;
  final String title;
  final int? year;
  final String? season;
  final String? startDate;
  final String? endDate;
  final String? nextSlug;
  final String? prevSlug;

  String get subtitle {
    if (startDate != null && endDate != null) {
      return _fmtRange(startDate!, endDate!);
    }
    return season?.toUpperCase() ?? '';
  }

  static String _fmtRange(String a, String b) {
    try {
      final da = DateTime.parse(a);
      final db = DateTime.parse(b);
      const months = [
        '', 'Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun',
        'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des',
      ];
      return '${months[da.month]}–${months[db.month]} ${db.year}';
    } catch (_) {
      return '$a – $b';
    }
  }
}

class LiveChartApi {
  static const _base = 'https://www.livechart.me';
  static const _ua = {
    'User-Agent':
        'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 '
            '(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
    'Accept': 'text/html,application/json',
  };

  /// Season slug berdasarkan bulan sekarang / berikutnya.
  static String seasonSlugFor(DateTime dt) {
    final y = dt.year;
    final m = dt.month;
    if (m <= 3) return 'winter-$y';
    if (m <= 6) return 'spring-$y';
    if (m <= 9) return 'summer-$y';
    return 'fall-$y';
  }

  /// Season yang "akan datang": jika masih di awal season, tampilkan current;
  /// prefer next season untuk "upcoming".
  static String upcomingSlug([DateTime? now]) {
    final n = now ?? DateTime.now();
    // Default: season berikutnya biar benar-benar "akan datang"
    final m = n.month;
    if (m <= 3) return 'spring-${n.year}';
    if (m <= 6) return 'summer-${n.year}';
    if (m <= 9) return 'fall-${n.year}';
    return 'winter-${n.year + 1}';
  }

  Future<LiveChartSeason> fetchSeasonMeta(String slug) async {
    try {
      final res = await http
          .get(Uri.parse('$_base/api/v1/charts/$slug'), headers: {
        ..._ua,
        'Accept': 'application/json',
      }).timeout(const Duration(seconds: 10));
      if (res.statusCode >= 200 && res.statusCode < 300) {
        final d = jsonDecode(res.body);
        if (d is Map) {
          return LiveChartSeason(
            slug: '${d['slug'] ?? slug}',
            title: '${d['title'] ?? slug}',
            year: d['year'] is int ? d['year'] as int : int.tryParse('${d['year']}'),
            season: d['season']?.toString(),
            startDate: d['start_date']?.toString(),
            endDate: d['end_date']?.toString(),
            nextSlug: d['next_chart_slug']?.toString(),
            prevSlug: d['previous_chart_slug']?.toString(),
          );
        }
      }
    } catch (_) {}
    // fallback title dari slug
    final parts = slug.split('-');
    final season = parts.isNotEmpty ? parts.first : slug;
    final year = parts.length > 1 ? parts[1] : '';
    final cap = season.isEmpty
        ? slug
        : '${season[0].toUpperCase()}${season.substring(1)} $year';
    return LiveChartSeason(slug: slug, title: cap.trim());
  }

  /// Scrape daftar anime dari halaman season LiveChart.
  /// [kind]: tv | movies | ovas
  Future<List<LiveChartAnime>> fetchSeasonList(
    String slug, {
    String kind = 'tv',
  }) async {
    final path = kind == 'all' ? '/$slug' : '/$slug/$kind';
    final res = await http
        .get(Uri.parse('$_base$path'), headers: _ua)
        .timeout(const Duration(seconds: 18));
    if (res.statusCode < 200 || res.statusCode >= 300) {
      throw Exception('Gagal memuat data LiveChart (${res.statusCode})');
    }
    return _parseSeasonHtml(res.body);
  }

  List<LiveChartAnime> _parseSeasonHtml(String html) {
    final out = <LiveChartAnime>[];
    final seen = <int>{};

    // article.anime dengan data-* attributes
    final articleRe = RegExp(
      r'<article[^>]*class="[^"]*\banime\b[^"]*"[^>]*>',
      caseSensitive: false,
    );

    final matches = articleRe.allMatches(html).toList();
    for (final m in matches) {
      // Ambil tag pembuka + sedikit konten untuk poster & schedule
      final start = m.start;
      final end = (start + 3500).clamp(0, html.length);
      final chunk = html.substring(start, end);

      final id = int.tryParse(_attr(chunk, 'data-anime-id') ?? '') ?? 0;
      if (id <= 0 || seen.contains(id)) continue;
      seen.add(id);

      final romaji = _decode(_attr(chunk, 'data-romaji') ?? '');
      final english = _decode(_attr(chunk, 'data-english') ?? '');
      final native = _decode(_attr(chunk, 'data-native') ?? '');
      final premiere = int.tryParse(_attr(chunk, 'data-premiere') ?? '');

      String? poster;
      final posterM = RegExp(
        r'srcset="(https://u\.livechart\.me/anime/' +
            '$id' +
            r'/poster_image/[^"\s]+)"',
      ).firstMatch(chunk);
      if (posterM != null) {
        poster = posterM.group(1)!.split(',').first.trim().split(' ').first;
      } else {
        final imgM = RegExp(
          r'src="(https://u\.livechart\.me/anime/' +
              '$id' +
              r'/poster_image/[^"]+)"',
        ).firstMatch(chunk);
        poster = imgM?.group(1);
      }

      String? schedule;
      final sch = RegExp(
        r'class="release-schedule-info"[^>]*>([^<]+)<',
      ).firstMatch(chunk);
      if (sch != null) schedule = _decode(sch.group(1)!.trim());

      final tags = <String>[];
      for (final tm in RegExp(r'<ol class="anime-tags">([\s\S]*?)</ol>')
          .allMatches(chunk)
          .take(1)) {
        for (final a in RegExp(r'<a[^>]*>([^<]+)</a>').allMatches(tm.group(1)!)) {
          final t = _decode(a.group(1)!.trim());
          if (t.isNotEmpty) tags.add(t);
        }
      }

      if (romaji.isEmpty && english.isEmpty) continue;
      out.add(LiveChartAnime(
        id: id,
        title: romaji.isNotEmpty ? romaji : english,
        englishTitle: english.isNotEmpty ? english : null,
        nativeTitle: native.isNotEmpty ? native : null,
        posterUrl: poster,
        premiereUnix: premiere,
        scheduleLabel: schedule,
        tags: tags,
      ));
    }

    // Fallback: mainTitle links saja
    if (out.isEmpty) {
      for (final m in RegExp(
        r'data-anime-card-target="mainTitle" href="/anime/(\d+)">([^<]+)</a>',
      ).allMatches(html)) {
        final id = int.tryParse(m.group(1) ?? '') ?? 0;
        if (id <= 0 || seen.contains(id)) continue;
        seen.add(id);
        out.add(LiveChartAnime(id: id, title: _decode(m.group(2)!.trim())));
      }
    }

    return out;
  }

  static String? _attr(String html, String name) {
    final m = RegExp('$name="([^"]*)"').firstMatch(html);
    return m?.group(1);
  }

  static String _decode(String s) {
    return s
        .replaceAll('&amp;', '&')
        .replaceAll('&quot;', '"')
        .replaceAll('&#39;', "'")
        .replaceAll('&lt;', '<')
        .replaceAll('&gt;', '>')
        .replaceAll('&nbsp;', ' ');
  }

  Future<LiveChartDetail> fetchDetail(int id) async {
    final res = await http
        .get(Uri.parse('$_base/anime/$id'), headers: _ua)
        .timeout(const Duration(seconds: 18));
    if (res.statusCode < 200 || res.statusCode >= 300) {
      throw Exception('Gagal memuat detail anime');
    }
    return LiveChartDetail.parse(id, res.body);
  }

  Future<String> _getHtml(String path) async {
    final res = await http
        .get(Uri.parse('$_base$path'), headers: _ua)
        .timeout(const Duration(seconds: 18));
    if (res.statusCode < 200 || res.statusCode >= 300) {
      throw Exception('Gagal memuat data (${res.statusCode})');
    }
    return res.body;
  }

  Future<List<LcVideo>> fetchVideos(int id) async {
    final html = await _getHtml('/anime/$id/videos');
    final out = <LcVideo>[];
    final re = RegExp(
      r'data-video-embed-url="([^"]+)"\s*data-video-thumbnail-url="([^"]+)"'
      r'[^>]*data-video-duration="([^"]*)"[^>]*data-video-uploaded-at="([^"]*)"',
    );
    var i = 0;
    for (final m in re.allMatches(html)) {
      i++;
      final embed = m.group(1)!;
      var watch = embed;
      final yt = RegExp(r'youtube\.com/embed/([A-Za-z0-9_-]+)').firstMatch(embed);
      if (yt != null) {
        watch = 'https://www.youtube.com/watch?v=${yt.group(1)}';
      }
      out.add(LcVideo(
        title: 'Video $i',
        embedUrl: embed,
        watchUrl: watch,
        thumbUrl: m.group(2),
        duration: m.group(3),
        uploadedAt: m.group(4),
      ));
    }
    return out;
  }

  Future<List<LcStream>> fetchStreams(int id) async {
    final html = await _getHtml('/anime/$id/streams');
    final out = <LcStream>[];
    final seen = <String>{};
    final parts = html.split('flex-1 flex items-center gap-4 p-4');
    for (final part in parts.skip(1)) {
      final alt = RegExp(r'alt="([^"]+?)(?: logo)?"').firstMatch(part);
      final href = RegExp(
        r'href="(https?://(?!www\.livechart)[^"]+)"',
      ).firstMatch(part);
      final logo = RegExp(
        r'src="(https://u\.livechart\.me/streaming_service/[^"]+)"',
      ).firstMatch(part);
      if (href == null) continue;
      final url = href.group(1)!;
      if (!seen.add(url)) continue;
      var name = alt?.group(1) ?? 'Stream';
      name = name.replaceAll(' logo', '');
      out.add(LcStream(name: name, url: url, logoUrl: logo?.group(1)));
    }
    if (out.isEmpty) {
      for (final m in RegExp(
        r'href="(https?://(?:www\.)?(?:crunchyroll|netflix|bilibili|primevideo|disneyplus|hidive)\.[^"]+)"',
        caseSensitive: false,
      ).allMatches(html)) {
        final url = m.group(1)!;
        if (!seen.add(url)) continue;
        out.add(LcStream(name: Uri.parse(url).host, url: url));
      }
    }
    return out;
  }

  Future<List<LcSchedule>> fetchSchedules(int id) async {
    final html = await _getHtml('/anime/$id/schedules');
    final out = <LcSchedule>[];
    final arts = RegExp(
      r'<article class="card[^"]*" data-controller="release-schedule"[^>]*>([\s\S]*?)</article>',
    ).allMatches(html);
    for (final a in arts) {
      final chunk = a.group(1)!;
      final ts = int.tryParse(
        RegExp(r'data-timestamp="(\d+)"').firstMatch(chunk)?.group(1) ?? '',
      );
      // EP label from data-label or text
      var ep = RegExp(r'data-label="(EP\d+)"').firstMatch(chunk)?.group(1);
      ep ??= RegExp(r'>(EP\d+)').firstMatch(chunk)?.group(1);
      ep ??= 'EP';

      // date fallback: "Oct  7, 2026 (Time TBD)"
      String? dateLabel;
      final dt = RegExp(
        r'data-intl-time-placeholder="([^"]+)"',
      ).firstMatch(chunk);
      if (dt != null) {
        dateLabel = LiveChartApi._decode(dt.group(1)!.trim());
        if (chunk.contains('Time TBD')) dateLabel = '$dateLabel (Time TBD)';
      }

      // kind: Broadcast / Simulcast / Streaming
      final kindM = RegExp(
        r'title="(Broadcast[^"]*|Simulcast[^"]*|Streaming[^"]*)"',
      ).firstMatch(chunk);
      final kind = kindM != null
          ? LiveChartApi._decode(kindM.group(1)!)
          : null;

      // platform display name (Crunchyroll etc)
      String? platformName;
      final pn = RegExp(
        r'lc-text-contextual-accent[^>]*>([^<]+)<',
      ).firstMatch(chunk);
      if (pn != null) {
        platformName = LiveChartApi._decode(pn.group(1)!.trim());
      }
      final plat = RegExp(
        r'href="(https?://(?!www\.livechart)(?!pages/)[^"]+)"',
      ).firstMatch(chunk)?.group(1);

      // languages from tracklist-json or <li>
      final langs = <String>[];
      final jsonLang = RegExp(
        r'data-tracklist-json="([^"]+)"',
      ).firstMatch(chunk);
      if (jsonLang != null) {
        final raw = LiveChartApi._decode(jsonLang.group(1)!);
        for (final lm in RegExp(r'\[&quot;([A-Z]{2})&quot;\]|"([A-Z]{2})"').allMatches(raw)) {
          final code = lm.group(1) ?? lm.group(2);
          if (code != null && !langs.contains(code)) langs.add(code);
        }
        // also plain
        for (final lm in RegExp(r'"([A-Z]{2})"').allMatches(raw)) {
          final code = lm.group(1)!;
          if (!langs.contains(code)) langs.add(code);
        }
      }
      for (final lm in RegExp(r'<li>([A-Z]{2}(?:\s*\([^)]*\))?)</li>').allMatches(chunk)) {
        final code = lm.group(1)!.trim();
        if (!langs.contains(code)) langs.add(code);
      }

      String? badge;
      final isDefault = chunk.contains('YOUR DEFAULT') || chunk.contains('Your Default');
      if (isDefault) badge = 'Your Default';
      if (RegExp(r'>\s*NEW\s*<').hasMatch(chunk) || chunk.contains('>NEW<')) {
        badge = badge ?? 'New';
      }

      out.add(LcSchedule(
        label: ep,
        premiereUnix: ts,
        dateLabel: dateLabel,
        platformUrl: plat,
        platformName: platformName,
        kind: kind,
        languages: langs,
        badge: badge,
        isDefault: isDefault,
      ));
    }
    return out;
  }

  Future<List<String>> fetchVisuals(int id) async {
    final html = await _getHtml('/anime/$id/visuals');
    final out = <String>[];
    final seen = <String>{};

    String normalize(String u) {
      // samakan size variant supaya tidak double
      var x = u.split('?').first;
      x = x.replaceAll('/small.jpg', '/large.jpg');
      x = x.replaceAll('/small.webp', '/large.webp');
      x = x.replaceAll('/medium.jpg', '/large.jpg');
      // key: path tanpa size suffix
      final key = x
          .replaceAll('/large.jpg', '')
          .replaceAll('/large.webp', '')
          .replaceAll('/small.jpg', '')
          .replaceAll('/small.webp', '');
      return key;
    }

    void add(String u) {
      final key = normalize(u);
      if (!seen.add(key)) return;
      var preferred = u;
      if (preferred.contains('/small.')) {
        preferred = preferred.replaceFirst('/small.', '/large.');
      }
      out.add(preferred);
    }

    for (final m in RegExp(
      r'(https://u\.livechart\.me/(?:anime/visual|anime_visuals)/[^"\s]+\.(?:jpg|webp|png)(?:/(?:large|small|medium)\.(?:jpg|webp))?)',
    ).allMatches(html)) {
      add(m.group(1)!);
    }
    // jangan dobel poster utama kecuali tidak ada visual lain
    if (out.isEmpty) {
      for (final m in RegExp(
        'https://u\\.livechart\\.me/anime/$id/poster_image/[^"\\s]+/large\\.(?:jpg|webp)',
      ).allMatches(html)) {
        add(m.group(0)!);
      }
    }
    return out;
  }

  Future<List<LcHeadline>> fetchHeadlines(int id) async {
    final html = await _getHtml('/anime/$id/headlines');
    final out = <LcHeadline>[];
    final seen = <String>{};
    for (final m in RegExp(
      r'href="(https?://(?!www\.livechart\.me)[^"]+)"[^>]*>([^<]{8,160})<',
    ).allMatches(html)) {
      final url = m.group(1)!;
      var title = LiveChartApi._decode(m.group(2)!.trim());
      if (title.toLowerCase() == 'official x') continue;
      if (url.contains('LiveChart')) continue;
      if (!seen.add(url)) continue;
      out.add(LcHeadline(title: title, url: url));
      if (out.length >= 40) break;
    }
    return out;
  }
}

class LcVideo {
  const LcVideo({
    required this.title,
    required this.embedUrl,
    required this.watchUrl,
    this.thumbUrl,
    this.duration,
    this.uploadedAt,
  });
  final String title;
  final String embedUrl;
  final String watchUrl;
  final String? thumbUrl;
  final String? duration;
  final String? uploadedAt;
}

class LcStream {
  const LcStream({required this.name, required this.url, this.logoUrl});
  final String name;
  final String url;
  final String? logoUrl;
}

class LcSchedule {
  const LcSchedule({
    required this.label,
    this.premiereUnix,
    this.dateLabel,
    this.platformUrl,
    this.platformName,
    this.kind,
    this.languages = const [],
    this.badge,
    this.isDefault = false,
  });
  final String label; // EP1
  final int? premiereUnix;
  final String? dateLabel; // "7 Okt 2026 (Time TBD)" if no unix
  final String? platformUrl;
  final String? platformName;
  final String? kind; // Broadcast (Japan) / Simulcast: Subbed
  final List<String> languages;
  final String? badge; // NEW / YOUR DEFAULT
  final bool isDefault;

  DateTime? get at {
    final u = premiereUnix;
    if (u == null || u <= 0) return null;
    return DateTime.fromMillisecondsSinceEpoch(u * 1000, isUtc: true).toLocal();
  }

  String countdownNow([DateTime? now]) {
    final t = at;
    if (t == null) return dateLabel ?? '';
    final d = t.difference(now ?? DateTime.now());
    if (d.isNegative) return 'Sudah lewat';
    final days = d.inDays;
    final hours = d.inHours % 24;
    final mins = d.inMinutes % 60;
    final secs = d.inSeconds % 60;
    return '${days}d ${hours.toString().padLeft(2, '0')}h '
        '${mins.toString().padLeft(2, '0')}m ${secs.toString().padLeft(2, '0')}s';
  }
}

class LcHeadline {
  const LcHeadline({required this.title, required this.url});
  final String title;
  final String url;
}

/// Detail lengkap satu anime (halaman info LiveChart).
class LiveChartDetail {
  LiveChartDetail({
    required this.id,
    required this.title,
    this.englishTitle,
    this.nativeTitle,
    this.posterUrl,
    this.synopsis,
    this.genres = const [],
    this.studios = const [],
    this.format,
    this.source,
    this.episodes,
    this.runtime,
    this.premiereLabel,
    this.premiereUnix,
    this.scheduleLabel,
    this.websiteUrl,
    this.twitterUrl,
    this.malUrl,
    this.anilistUrl,
    this.anidbUrl,
    this.annUrl,
    this.related = const [],
  });

  final int id;
  final String title;
  final String? englishTitle;
  final String? nativeTitle;
  final String? posterUrl;
  final String? synopsis;
  final List<String> genres;
  final List<String> studios;
  final String? format;
  final String? source;
  final String? episodes;
  final String? runtime;
  final String? premiereLabel;
  final int? premiereUnix;
  final String? scheduleLabel;
  final String? websiteUrl;
  final String? twitterUrl;
  final String? malUrl;
  final String? anilistUrl;
  final String? anidbUrl;
  final String? annUrl;
  final List<LiveChartAnime> related;

  DateTime? get premiereAt {
    final u = premiereUnix;
    if (u == null || u <= 0) return null;
    return DateTime.fromMillisecondsSinceEpoch(u * 1000, isUtc: true).toLocal();
  }

  String get countdownText {
    final t = premiereAt;
    if (t == null) return '';
    final d = t.difference(DateTime.now());
    if (d.isNegative) return 'Sudah tayang';
    final days = d.inDays;
    final hours = d.inHours % 24;
    final mins = d.inMinutes % 60;
    final secs = d.inSeconds % 60;
    if (days > 0) return '${days}d ${hours}h ${mins}m ${secs}s';
    if (hours > 0) return '${hours}h ${mins}m ${secs}s';
    return '${mins}m ${secs}s';
  }

  static LiveChartDetail parse(int id, String html) {
    String? attrChunk(String name) {
      final m = RegExp('$name="([^"]*)"').firstMatch(html);
      return m?.group(1);
    }

    String decode(String s) => LiveChartApi._decode(s);

    String? meta(String label) {
      final m = RegExp(
        '$label</div>\\s*<div[^>]*>([\\s\\S]*?)</div>',
        caseSensitive: false,
      ).firstMatch(html);
      if (m == null) return null;
      final text = m.group(1)!.replaceAll(RegExp(r'<[^>]+>'), ' ');
      return decode(text.replaceAll(RegExp(r'\s+'), ' ').trim());
    }

    // JSON-LD
    String? title;
    String? synopsis;
    String? poster;
    final genres = <String>[];
    final ld = RegExp(
      r'<script type="application/ld\+json">(\{[\s\S]*?"@type"\s*:\s*"TVSeries"[\s\S]*?\})</script>',
    ).firstMatch(html);
    if (ld != null) {
      try {
        final d = jsonDecode(ld.group(1)!) as Map<String, dynamic>;
        title = d['name']?.toString();
        synopsis = decode((d['description'] ?? '').toString());
        poster = d['image']?.toString();
        final g = d['genre'];
        if (g is List) {
          for (final x in g) {
            final s = x.toString().trim();
            if (s.isNotEmpty) genres.add(s);
          }
        }
      } catch (_) {}
    }

    // Fallback title from <title>
    title ??= RegExp(r'<title>([^|<]+)').firstMatch(html)?.group(1)?.trim();
    title = decode(title ?? 'Anime #$id');

    // English / native from og or data
    final english = RegExp(
      r'property="og:title" content="([^"]+)"',
    ).firstMatch(html)?.group(1);

    // Poster fallback
    poster ??= RegExp(
      r'(https://u\.livechart\.me/anime/' + '$id' + r'/poster_image/[^"\s]+)',
    ).firstMatch(html)?.group(1);

    // Studios
    final studios = <String>[];
    for (final m in RegExp(r'href="/studios/[^"]+"[^>]*>([^<]+)<').allMatches(html)) {
      final s = decode(m.group(1)!.trim());
      if (s.isNotEmpty && !studios.contains(s)) studios.add(s);
    }

    // Tags if genres empty
    if (genres.isEmpty) {
      for (final m in RegExp(r'href="/tags/\d+"[^>]*>([^<]+)<').allMatches(html)) {
        final s = decode(m.group(1)!.trim());
        if (s.isNotEmpty && !genres.contains(s)) genres.add(s);
      }
    }

    // Links
    String? findLink(List<String> needles) {
      for (final n in needles) {
        final m = RegExp(
          'href="(https?://[^"]*' + n + '[^"]*)"',
          caseSensitive: false,
        ).firstMatch(html);
        if (m != null) return m.group(1);
      }
      return null;
    }

    String? website;
    final wm = RegExp(
      r'href="(https?://[^"]+)"[^>]*>\s*Website\s*<',
      caseSensitive: false,
    ).firstMatch(html);
    if (wm != null) website = wm.group(1);

    String? twitter;
    final xm = RegExp(
      r'href="(https?://(?:x|twitter)\.com/[^"]+)"[^>]*>\s*Official X\s*<',
      caseSensitive: false,
    ).firstMatch(html);
    if (xm != null) {
      twitter = xm.group(1);
    } else {
      twitter = findLink(['x.com/', 'twitter.com/']);
      // skip livechart official
      if (twitter != null && twitter.contains('LiveChart')) twitter = null;
    }

    // Premiere unix from data-premiere on page if any
    int? premiereUnix = int.tryParse(attrChunk('data-premiere') ?? '');
    premiereUnix ??= int.tryParse(
      RegExp(r'data-timestamp="(\d+)"').firstMatch(html)?.group(1) ?? '',
    );

    // Related: links to other /anime/id near poster thumbs
    final related = <LiveChartAnime>[];
    final seen = {id};
    for (final m in RegExp(
      r'href="/anime/(\d+)"[^>]*>\s*(?:<img[^>]*alt="([^"]*)"[^>]*>)?',
    ).allMatches(html)) {
      final rid = int.tryParse(m.group(1) ?? '') ?? 0;
      if (rid <= 0 || seen.contains(rid)) continue;
      seen.add(rid);
      final alt = decode((m.group(2) ?? '').trim());
      if (alt.isEmpty) continue;
      // only collect a few related with actual alt (series cards)
      related.add(LiveChartAnime(id: rid, title: alt));
      if (related.length >= 8) break;
    }

    String? schedule;
    final sch = RegExp(
      r'class="release-schedule-info"[^>]*>([^<]+)<',
    ).firstMatch(html);
    if (sch != null) schedule = decode(sch.group(1)!.trim());

    return LiveChartDetail(
      id: id,
      title: title,
      englishTitle: english != null && english != title ? decode(english) : null,
      posterUrl: poster,
      synopsis: synopsis?.isNotEmpty == true ? synopsis : null,
      genres: genres,
      studios: studios,
      format: meta('Format'),
      source: meta('Source'),
      episodes: meta('Episodes'),
      runtime: meta('Run time') ?? meta('Runtime'),
      premiereLabel: meta('Premiere'),
      premiereUnix: premiereUnix,
      scheduleLabel: schedule,
      websiteUrl: website,
      twitterUrl: twitter,
      malUrl: findLink(['myanimelist.net']),
      anilistUrl: findLink(['anilist.co']),
      anidbUrl: findLink(['anidb.net']),
      annUrl: findLink(['animenewsnetwork.com']),
      related: related,
    );
  }
}


// ---------------------------------------------------------------------------
// Bookmark upcoming (LiveChart) + notifikasi rilis
// ---------------------------------------------------------------------------

class LiveChartBookmark {
  const LiveChartBookmark({
    required this.id,
    required this.title,
    this.posterUrl,
    this.premiereUnix,
    this.englishTitle,
    this.notified = false,
  });

  final int id;
  final String title;
  final String? posterUrl;
  final int? premiereUnix;
  final String? englishTitle;
  final bool notified;

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'posterUrl': posterUrl,
        'premiereUnix': premiereUnix,
        'englishTitle': englishTitle,
        'notified': notified,
      };

  factory LiveChartBookmark.fromJson(Map<String, dynamic> j) => LiveChartBookmark(
        id: int.tryParse('${j['id'] ?? 0}') ?? 0,
        title: '${j['title'] ?? ''}',
        posterUrl: j['posterUrl']?.toString(),
        premiereUnix: int.tryParse('${j['premiereUnix'] ?? ''}'),
        englishTitle: j['englishTitle']?.toString(),
        notified: j['notified'] == true,
      );

  LiveChartBookmark copyWith({
    String? title,
    String? posterUrl,
    int? premiereUnix,
    String? englishTitle,
    bool? notified,
  }) =>
      LiveChartBookmark(
        id: id,
        title: title ?? this.title,
        posterUrl: posterUrl ?? this.posterUrl,
        premiereUnix: premiereUnix ?? this.premiereUnix,
        englishTitle: englishTitle ?? this.englishTitle,
        notified: notified ?? this.notified,
      );

  DateTime? get premiereAt {
    final u = premiereUnix;
    if (u == null || u <= 0) return null;
    return DateTime.fromMillisecondsSinceEpoch(u * 1000, isUtc: true).toLocal();
  }

  bool get isReleased {
    final t = premiereAt;
    if (t == null) return false;
    return !t.isAfter(DateTime.now());
  }
}

class LiveChartBookmarkStore {
  static const key = 'livechart_bookmarks_v1';

  static Future<List<LiveChartBookmark>> list() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(key);
    if (raw == null || raw.isEmpty) return [];
    try {
      final decoded = jsonDecode(raw);
      if (decoded is! List) return [];
      return decoded
          .whereType<Map>()
          .map((e) => LiveChartBookmark.fromJson(Map<String, dynamic>.from(e)))
          .where((e) => e.id > 0)
          .toList();
    } catch (_) {
      return [];
    }
  }

  static Future<void> _save(List<LiveChartBookmark> items) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(key, jsonEncode(items.map((e) => e.toJson()).toList()));
  }

  static Future<bool> isBookmarked(int id) async {
    final all = await list();
    return all.any((e) => e.id == id);
  }

  static Future<void> add(LiveChartBookmark item) async {
    final all = await list();
    final prev = all.where((e) => e.id == item.id).toList();
    final keepNotified = prev.isNotEmpty && prev.first.notified;
    all.removeWhere((e) => e.id == item.id);
    all.insert(
      0,
      item.copyWith(notified: item.notified || keepNotified),
    );
    if (all.length > 200) all.removeRange(200, all.length);
    await _save(all);
  }

  static Future<void> remove(int id) async {
    final all = await list();
    all.removeWhere((e) => e.id == id);
    await _save(all);
  }

  static Future<void> markNotified(int id) async {
    final all = await list();
    final i = all.indexWhere((e) => e.id == id);
    if (i < 0) return;
    all[i] = all[i].copyWith(notified: true);
    await _save(all);
  }

  /// Cek bookmark yang sudah lewat jadwal premiere → notifikasi sekali.
  static Future<List<LiveChartBookmark>> checkReleases() async {
    final all = await list();
    if (all.isEmpty) return [];
    final released = <LiveChartBookmark>[];
    final next = <LiveChartBookmark>[];
    for (final b in all) {
      if (b.isReleased && !b.notified) {
        released.add(b);
        next.add(b.copyWith(notified: true));
      } else {
        next.add(b);
      }
    }
    if (released.isEmpty) return [];
    await _save(next);
    for (final b in released) {
      await LiveChartReleaseNotifier.show(
        title: 'Anime rilis!',
        body: b.title,
        id: b.id,
      );
    }
    // Sync ke cloud
    try {
      // ignore: unawaited_futures
      ApiSync.pushLiveChartBookmarks();
    } catch (_) {}
    return released;
  }
}

class LiveChartReleaseNotifier {
  static Future<void> show({
    required String title,
    required String body,
    required int id,
  }) =>
      AppNotifications.showLiveChart(title: title, body: body, id: id);
}


// ---------------------------------------------------------------------------
// UI
// ---------------------------------------------------------------------------

class UpcomingAnimePage extends StatefulWidget {
  const UpcomingAnimePage({super.key, this.initialSlug});

  final String? initialSlug;

  @override
  State<UpcomingAnimePage> createState() => _UpcomingAnimePageState();
}

class _UpcomingAnimePageState extends State<UpcomingAnimePage>
    with SingleTickerProviderStateMixin {
  final _api = LiveChartApi();
  late TabController _tabs;
  late String _slug;
  LiveChartSeason? _season;
  final Map<String, List<LiveChartAnime>> _cache = {};
  final Map<String, String?> _errors = {};
  final Set<String> _loading = {};
  bool _metaLoading = true;

  static const _kinds = ['tv', 'movies', 'ovas'];
  static const _labels = ['TV', 'Movies', 'OVAs'];

  @override
  void initState() {
    super.initState();
    _slug = widget.initialSlug ?? LiveChartApi.upcomingSlug();
    _tabs = TabController(length: _kinds.length, vsync: this);
    // ignore: unawaited_futures
    LiveChartBookmarkStore.checkReleases();
    _tabs.addListener(() {
      if (!_tabs.indexIsChanging) _ensureKind(_kinds[_tabs.index]);
    });
    _bootstrap();
  }

  Future<void> _bootstrap() async {
    setState(() => _metaLoading = true);
    try {
      final meta = await _api.fetchSeasonMeta(_slug);
      if (!mounted) return;
      setState(() {
        _season = meta;
        _slug = meta.slug;
        _metaLoading = false;
      });
    } catch (_) {
      if (mounted) setState(() => _metaLoading = false);
    }
    await _ensureKind(_kinds[_tabs.index]);
  }

  Future<void> _ensureKind(String kind) async {
    final key = '$_slug|$kind';
    if (_cache.containsKey(key) || _loading.contains(key)) return;
    setState(() {
      _loading.add(key);
      _errors.remove(key);
    });
    try {
      final online = await NetStatus.hasConnection();
      if (!online) throw Exception('Tidak ada koneksi internet');
      final list = await _api.fetchSeasonList(_slug, kind: kind);
      if (!mounted) return;
      setState(() {
        _cache[key] = list;
        _loading.remove(key);
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _errors[key] = e.toString().replaceFirst('Exception: ', '');
        _loading.remove(key);
      });
    }
  }

  Future<void> _goSlug(String? slug) async {
    if (slug == null || slug.isEmpty || slug == _slug) return;
    setState(() {
      _slug = slug;
      _season = null;
      _cache.clear();
      _errors.clear();
      _loading.clear();
    });
    await _bootstrap();
  }

  @override
  void dispose() {
    _tabs.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final title = _season?.title ?? 'Anime Akan Datang';
    final sub = _season?.subtitle ?? '';

    return Scaffold(
      backgroundColor: const Color(0xFF17121F),
      appBar: AppBar(
        backgroundColor: Colors.black54,
        foregroundColor: Colors.white,
        elevation: 0,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18),
            ),
            if (sub.isNotEmpty)
              Text(
                sub,
                style: const TextStyle(color: Colors.white54, fontSize: 12),
              ),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Season sebelumnya',
            onPressed: _season?.prevSlug == null
                ? null
                : () => _goSlug(_season!.prevSlug),
            icon: const Icon(Icons.chevron_left_rounded),
          ),
          IconButton(
            tooltip: 'Season berikutnya',
            onPressed: _season?.nextSlug == null
                ? null
                : () => _goSlug(_season!.nextSlug),
            icon: const Icon(Icons.chevron_right_rounded),
          ),
          IconButton(
            tooltip: 'Muat ulang',
            onPressed: () {
              _cache.clear();
              _errors.clear();
              _bootstrap();
            },
            icon: const Icon(Icons.refresh_rounded),
          ),
        ],
        bottom: TabBar(
          controller: _tabs,
          indicatorColor: const Color(0xFFFFD88A),
          labelColor: const Color(0xFFFFD88A),
          unselectedLabelColor: Colors.white54,
          tabs: [for (final l in _labels) Tab(text: l)],
        ),
      ),
      body: _metaLoading && _season == null
          ? const Center(
              child: CircularProgressIndicator(color: Color(0xFFFFD88A)),
            )
          : TabBarView(
              controller: _tabs,
              children: [
                for (final kind in _kinds) _buildGrid(kind),
              ],
            ),
    );
  }

  Widget _buildGrid(String kind) {
    final key = '$_slug|$kind';
    final loading = _loading.contains(key);
    final err = _errors[key];
    final items = _cache[key];

    if (loading && items == null) {
      return const Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircularProgressIndicator(color: Color(0xFFFFD88A)),
            SizedBox(height: 12),
            Text('Memuat dari LiveChart…', style: TextStyle(color: Colors.white54)),
          ],
        ),
      );
    }
    if (err != null && items == null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.cloud_off_rounded, color: Colors.white38, size: 48),
              const SizedBox(height: 12),
              Text(err, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70)),
              const SizedBox(height: 16),
              OutlinedButton(
                onPressed: () {
                  _cache.remove(key);
                  _errors.remove(key);
                  _ensureKind(kind);
                },
                style: OutlinedButton.styleFrom(foregroundColor: const Color(0xFFFFD88A)),
                child: const Text('Coba lagi'),
              ),
            ],
          ),
        ),
      );
    }
    if (items == null || items.isEmpty) {
      return const Center(
        child: Text('Tidak ada anime di kategori ini', style: TextStyle(color: Colors.white54)),
      );
    }

    return RefreshIndicator(
      color: const Color(0xFFFFD88A),
      backgroundColor: const Color(0xFF2A2235),
      onRefresh: () async {
        _cache.remove(key);
        _errors.remove(key);
        await _ensureKind(kind);
      },
      child: GridView.builder(
        padding: const EdgeInsets.fromLTRB(12, 12, 12, 24),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          childAspectRatio: 0.62,
        ),
        itemCount: items.length,
        itemBuilder: (_, i) => _AnimeTile(item: items[i]),
      ),
    );
  }
}

class _AnimeTile extends StatelessWidget {
  const _AnimeTile({required this.item});
  final LiveChartAnime item;

  @override
  Widget build(BuildContext context) {
    final poster = item.posterLarge;
    final cd = item.countdownText;
    final sched = item.scheduleLabel ?? '';

    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () {
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (_) => LiveChartDetailPage(
                animeId: item.id,
                titleHint: item.title,
                posterHint: item.posterLarge,
                premiereUnix: item.premiereUnix,
                scheduleHint: item.scheduleLabel,
              ),
            ),
          );
        },
        child: Container(
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.06),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Expanded(
            child: Stack(
              fit: StackFit.expand,
              children: [
                if (poster.isNotEmpty)
                  Image.network(
                    poster,
                    fit: BoxFit.cover,
                    headers: const {
                      'User-Agent': 'Mozilla/5.0',
                      'Referer': 'https://www.livechart.me/',
                    },
                    errorBuilder: (_, __, ___) => Container(
                      color: Colors.white10,
                      child: const Icon(Icons.movie_outlined, color: Colors.white24),
                    ),
                  )
                else
                  Container(
                    color: Colors.white10,
                    child: const Icon(Icons.movie_outlined, color: Colors.white24),
                  ),
                if (cd.isNotEmpty)
                  Positioned(
                    left: 0,
                    right: 0,
                    bottom: 0,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                      color: Colors.black.withOpacity(0.55),
                      child: Text(
                        cd,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Color(0xFFFFD88A),
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 8, 10, 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  item.title,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                    fontSize: 13,
                    height: 1.25,
                  ),
                ),
                if (sched.isNotEmpty) ...[
                  const SizedBox(height: 4),
                  Text(
                    sched,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: Colors.white54, fontSize: 11),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Detail page
// ---------------------------------------------------------------------------

class LiveChartDetailPage extends StatefulWidget {
  const LiveChartDetailPage({
    super.key,
    required this.animeId,
    this.titleHint,
    this.posterHint,
    this.premiereUnix,
    this.scheduleHint,
  });

  final int animeId;
  final String? titleHint;
  final String? posterHint;
  final int? premiereUnix;
  final String? scheduleHint;

  @override
  State<LiveChartDetailPage> createState() => _LiveChartDetailPageState();
}

class _LiveChartDetailPageState extends State<LiveChartDetailPage>
    with SingleTickerProviderStateMixin {
  final _api = LiveChartApi();
  late final TabController _tabs;

  LiveChartDetail? _detail;
  String? _infoError;
  bool _infoLoading = true;

  List<LcVideo>? _videos;
  List<LcStream>? _streams;
  List<LcSchedule>? _schedules;
  List<String>? _visuals;
  List<LcHeadline>? _headlines;
  final Map<int, String> _tabErrors = {};
  final Set<int> _tabLoading = {};
  Timer? _tick;
  bool _isBookmarked = false;

  late final DateTime? _fallbackPremiere;

  static const _tabLabels = [
    'Info',
    'Videos',
    'Streams',
    'Schedules',
    'Visuals',
    'Headlines',
  ];

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: _tabLabels.length, vsync: this);
    _tabs.addListener(() {
      if (!_tabs.indexIsChanging) _ensureTab(_tabs.index);
    });
    final u = widget.premiereUnix;
    _fallbackPremiere = (u != null && u > 0)
        ? DateTime.fromMillisecondsSinceEpoch(u * 1000, isUtc: true).toLocal()
        : null;
    _loadInfo();
    _refreshBookmark();
    // ignore: unawaited_futures
    LiveChartBookmarkStore.checkReleases();
    _tick = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      // Update countdown di Info + Schedules tanpa fetch ulang
      setState(() {});
    });
  }

  @override
  void dispose() {
    _tick?.cancel();
    _tabs.dispose();
    super.dispose();
  }

  Future<void> _refreshBookmark() async {
    final on = await LiveChartBookmarkStore.isBookmarked(widget.animeId);
    if (mounted) setState(() => _isBookmarked = on);
  }

  Future<void> _toggleBookmark() async {
    final d = _detail;
    final title = d?.title ?? widget.titleHint ?? 'Anime';
    final poster = d?.posterUrl ?? widget.posterHint;
    final premiere = d?.premiereUnix ?? widget.premiereUnix;
    final english = d?.englishTitle;

    if (_isBookmarked) {
      await LiveChartBookmarkStore.remove(widget.animeId);
      if (!mounted) return;
      setState(() => _isBookmarked = false);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Dihapus dari bookmark')),
      );
    } else {
      await LiveChartBookmarkStore.add(LiveChartBookmark(
        id: widget.animeId,
        title: title,
        posterUrl: poster,
        premiereUnix: premiere,
        englishTitle: english,
      ));
      if (!mounted) return;
      setState(() => _isBookmarked = true);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Disimpan. Akan notifikasi saat rilis.'),
        ),
      );
    }
    try {
      // ignore: unawaited_futures
      ApiSync.pushLiveChartBookmarks();
    } catch (_) {}
  }

  Future<void> _loadInfo() async {
    setState(() {
      _infoLoading = true;
      _infoError = null;
    });
    try {
      final d = await _api.fetchDetail(widget.animeId);
      if (!mounted) return;
      setState(() {
        _detail = d;
        _infoLoading = false;
      });
      await _refreshBookmark();
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _infoError = e.toString().replaceFirst('Exception: ', '');
        _infoLoading = false;
      });
    }
  }

  Future<void> _ensureTab(int index) async {
    if (index == 0) return;
    if (_tabLoading.contains(index)) return;
    final already = index == 1
        ? _videos != null
        : index == 2
            ? _streams != null
            : index == 3
                ? _schedules != null
                : index == 4
                    ? _visuals != null
                    : index == 5
                        ? _headlines != null
                        : true;
    if (already) return;

    setState(() {
      _tabLoading.add(index);
      _tabErrors.remove(index);
    });
    try {
      if (index == 1) {
        final v = await _api.fetchVideos(widget.animeId);
        if (mounted) setState(() => _videos = v);
      } else if (index == 2) {
        final s = await _api.fetchStreams(widget.animeId);
        if (mounted) setState(() => _streams = s);
      } else if (index == 3) {
        final s = await _api.fetchSchedules(widget.animeId);
        if (mounted) setState(() => _schedules = s);
      } else if (index == 4) {
        final v = await _api.fetchVisuals(widget.animeId);
        if (mounted) setState(() => _visuals = v);
      } else if (index == 5) {
        final h = await _api.fetchHeadlines(widget.animeId);
        if (mounted) setState(() => _headlines = h);
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _tabErrors[index] = e.toString().replaceFirst('Exception: ', '');
        });
      }
    } finally {
      if (mounted) setState(() => _tabLoading.remove(index));
    }
  }

  Future<void> _open(String? url) async {
    if (url == null || url.isEmpty) return;
    final uri = Uri.tryParse(url);
    if (uri == null) return;
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  String _fmtCountdown(DateTime? t) {
    if (t == null) return '';
    final d = t.difference(DateTime.now());
    if (d.isNegative) return 'Sudah tayang';
    return '${d.inDays}d ${d.inHours % 24}h ${d.inMinutes % 60}m ${d.inSeconds % 60}s';
  }

  @override
  Widget build(BuildContext context) {
    final d = _detail;
    final title = d?.title ?? widget.titleHint ?? 'Detail';

    return Scaffold(
      backgroundColor: const Color(0xFF17121F),
      appBar: AppBar(
        backgroundColor: Colors.black54,
        foregroundColor: Colors.white,
        title: Text(
          title,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16),
        ),
        actions: [
          IconButton(
            tooltip: _isBookmarked ? 'Hapus bookmark' : 'Bookmark — notif saat rilis',
            onPressed: _toggleBookmark,
            icon: Icon(
              _isBookmarked ? Icons.bookmark_rounded : Icons.bookmark_border_rounded,
              color: _isBookmarked ? const Color(0xFFFFD88A) : Colors.white,
            ),
          ),
        ],
        bottom: TabBar(
          controller: _tabs,
          isScrollable: true,
          indicatorColor: const Color(0xFFFFD88A),
          labelColor: const Color(0xFFFFD88A),
          unselectedLabelColor: Colors.white54,
          tabs: [for (final l in _tabLabels) Tab(text: l)],
        ),
      ),
      body: TabBarView(
        controller: _tabs,
        children: [
          _buildInfoTab(),
          _buildVideosTab(),
          _buildStreamsTab(),
          _buildSchedulesTab(),
          _buildVisualsTab(),
          _buildHeadlinesTab(),
        ],
      ),
    );
  }

  Widget _tabLoadingView() => const Center(
        child: CircularProgressIndicator(color: Color(0xFFFFD88A)),
      );

  Widget _tabErrorView(int index, VoidCallback retry) {
    final err = _tabErrors[index] ?? 'Gagal memuat';
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(err,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white70)),
            const SizedBox(height: 12),
            OutlinedButton(
              onPressed: retry,
              style: OutlinedButton.styleFrom(
                  foregroundColor: const Color(0xFFFFD88A)),
              child: const Text('Coba lagi'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _empty(String msg) =>
      Center(child: Text(msg, style: const TextStyle(color: Colors.white54)));

  Widget _buildInfoTab() {
    final d = _detail;
    final poster = d?.posterUrl ?? widget.posterHint ?? '';
    final premiere = d?.premiereAt ?? _fallbackPremiere;
    final schedule = d?.scheduleLabel ?? widget.scheduleHint ?? 'EP1';
    final title = d?.title ?? widget.titleHint ?? 'Detail';

    if (_infoLoading && d == null) return _tabLoadingView();
    if (_infoError != null && d == null) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(_infoError!, style: const TextStyle(color: Colors.white70)),
            TextButton(onPressed: _loadInfo, child: const Text('Coba lagi')),
          ],
        ),
      );
    }

    return RefreshIndicator(
      color: const Color(0xFFFFD88A),
      backgroundColor: const Color(0xFF2A2235),
      onRefresh: _loadInfo,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: SizedBox(
                  width: 110,
                  height: 160,
                  child: poster.isNotEmpty
                      ? Image.network(
                          poster,
                          fit: BoxFit.cover,
                          headers: const {
                            'User-Agent': 'Mozilla/5.0',
                            'Referer': 'https://www.livechart.me/',
                          },
                          errorBuilder: (_, __, ___) =>
                              Container(color: Colors.white10),
                        )
                      : Container(color: Colors.white10),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (d?.premiereLabel != null)
                      Text(d!.premiereLabel!,
                          style: const TextStyle(
                              color: Color(0xFFFFD88A),
                              fontSize: 12,
                              fontWeight: FontWeight.w600)),
                    const SizedBox(height: 4),
                    Text(title,
                        style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w800,
                            fontSize: 17,
                            height: 1.25)),
                    if ((d?.englishTitle ?? '').isNotEmpty) ...[
                      const SizedBox(height: 4),
                      Text(d!.englishTitle!,
                          style: const TextStyle(
                              color: Colors.white60, fontSize: 13)),
                    ],
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.symmetric(vertical: 12),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.05),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Row(children: [
              _metaCell('Format', d?.format ?? '—'),
              _metaCell('Source', d?.source ?? '—'),
              _metaCell('Episodes', d?.episodes ?? '—'),
              _metaCell('Runtime', d?.runtime ?? '—'),
            ]),
          ),
          if (premiere != null) ...[
            const SizedBox(height: 14),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.06),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                    color: const Color(0xFFFFD88A).withOpacity(0.25)),
              ),
              child: Column(children: [
                Text(schedule,
                    style: const TextStyle(
                        color: Colors.white70,
                        fontWeight: FontWeight.w700,
                        fontSize: 12)),
                const SizedBox(height: 6),
                Text(_fmtCountdown(premiere),
                    style: const TextStyle(
                        color: Color(0xFFFFD88A),
                        fontWeight: FontWeight.w800,
                        fontSize: 18)),
              ]),
            ),
          ],
          if ((d?.synopsis ?? '').isNotEmpty) ...[
            const SizedBox(height: 18),
            Text(d!.synopsis!,
                style: const TextStyle(
                    color: Colors.white70, height: 1.45, fontSize: 13.5)),
          ],
          if (d != null && d.studios.isNotEmpty) ...[
            const SizedBox(height: 18),
            const Text('Studios',
                style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                    fontSize: 14)),
            const SizedBox(height: 8),
            Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [for (final s in d.studios) _chip(s, filled: false)]),
          ],
          if (d != null && d.genres.isNotEmpty) ...[
            const SizedBox(height: 18),
            const Text('Tags',
                style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                    fontSize: 14)),
            const SizedBox(height: 8),
            Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [for (final g in d.genres) _chip(g)]),
          ],
          if (d != null) ...[
            const SizedBox(height: 16),
            Row(children: [
              if ((d.websiteUrl ?? '').isNotEmpty)
                Expanded(
                    child: OutlinedButton(
                        onPressed: () => _open(d.websiteUrl),
                        style: OutlinedButton.styleFrom(
                            foregroundColor: Colors.white70,
                            side: const BorderSide(color: Colors.white24)),
                        child: const Text('Website'))),
              if ((d.websiteUrl ?? '').isNotEmpty &&
                  (d.twitterUrl ?? '').isNotEmpty)
                const SizedBox(width: 10),
              if ((d.twitterUrl ?? '').isNotEmpty)
                Expanded(
                    child: OutlinedButton(
                        onPressed: () => _open(d.twitterUrl),
                        style: OutlinedButton.styleFrom(
                            foregroundColor: Colors.white70,
                            side: const BorderSide(color: Colors.white24)),
                        child: const Text('Official X'))),
            ]),
            const SizedBox(height: 20),
            const Text('External resources',
                style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                    fontSize: 14)),
            const SizedBox(height: 10),
            Wrap(spacing: 8, runSpacing: 8, children: [
              if ((d.malUrl ?? '').isNotEmpty)
                _extBtn('MyAnimeList', const Color(0xFF2E51A2),
                    () => _open(d.malUrl)),
              if ((d.anilistUrl ?? '').isNotEmpty)
                _extBtn('AniList', const Color(0xFF02A9FF),
                    () => _open(d.anilistUrl)),
              if ((d.anidbUrl ?? '').isNotEmpty)
                _extBtn(
                    'AniDB', const Color(0xFF7A2E2E), () => _open(d.anidbUrl)),
              _extBtn(
                  'LiveChart',
                  const Color(0xFFFFD88A),
                  () => _open(
                      'https://www.livechart.me/anime/${widget.animeId}'),
                  darkText: true),
            ]),
          ],
        ],
      ),
    );
  }

  Widget _buildVideosTab() {
    if (_videos == null && !_tabLoading.contains(1) && _tabErrors[1] == null) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _ensureTab(1));
    }
    if (_tabLoading.contains(1) && _videos == null) return _tabLoadingView();
    if (_tabErrors[1] != null && _videos == null) {
      return _tabErrorView(1, () {
        setState(() => _videos = null);
        _ensureTab(1);
      });
    }
    final list = _videos ?? [];
    if (list.isEmpty) return _empty('Belum ada video / PV');
    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: list.length,
      separatorBuilder: (_, __) => const SizedBox(height: 12),
      itemBuilder: (_, i) {
        final v = list[i];
        return Material(
          color: Colors.white.withOpacity(0.06),
          borderRadius: BorderRadius.circular(14),
          child: InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: () => _open(v.watchUrl),
            child: Row(children: [
              ClipRRect(
                borderRadius:
                    const BorderRadius.horizontal(left: Radius.circular(14)),
                child: SizedBox(
                  width: 140,
                  height: 80,
                  child: (v.thumbUrl ?? '').isNotEmpty
                      ? Image.network(v.thumbUrl!,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => Container(
                              color: Colors.white10,
                              child: const Icon(Icons.play_circle_outline,
                                  color: Colors.white38)))
                      : Container(color: Colors.white10),
                ),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(v.title,
                            style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w700)),
                        if ((v.uploadedAt ?? '').length >= 10)
                          Text(v.uploadedAt!.substring(0, 10),
                              style: const TextStyle(
                                  color: Colors.white54, fontSize: 12)),
                      ]),
                ),
              ),
              const Padding(
                  padding: EdgeInsets.only(right: 12),
                  child: Icon(Icons.open_in_new,
                      color: Colors.white38, size: 18)),
            ]),
          ),
        );
      },
    );
  }

  Widget _buildStreamsTab() {
    if (_streams == null && !_tabLoading.contains(2) && _tabErrors[2] == null) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _ensureTab(2));
    }
    if (_tabLoading.contains(2) && _streams == null) return _tabLoadingView();
    if (_tabErrors[2] != null && _streams == null) {
      return _tabErrorView(2, () {
        setState(() => _streams = null);
        _ensureTab(2);
      });
    }
    final list = _streams ?? [];
    if (list.isEmpty) return _empty('Belum ada info streaming');
    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: list.length,
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (_, i) {
        final s = list[i];
        return Material(
          color: Colors.white.withOpacity(0.06),
          borderRadius: BorderRadius.circular(14),
          child: ListTile(
            onTap: () => _open(s.url),
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14)),
            leading: (s.logoUrl ?? '').isNotEmpty
                ? Image.network(s.logoUrl!,
                    width: 40,
                    height: 40,
                    errorBuilder: (_, __, ___) => const Icon(Icons.tv_rounded,
                        color: Color(0xFFFFD88A)))
                : const Icon(Icons.tv_rounded, color: Color(0xFFFFD88A)),
            title: Text(s.name,
                style: const TextStyle(
                    color: Colors.white, fontWeight: FontWeight.w700)),
            trailing: const Icon(Icons.open_in_new,
                color: Colors.white38, size: 18),
          ),
        );
      },
    );
  }

  Widget _buildSchedulesTab() {
    if (_schedules == null &&
        !_tabLoading.contains(3) &&
        _tabErrors[3] == null) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _ensureTab(3));
    }
    if (_tabLoading.contains(3) && _schedules == null) return _tabLoadingView();
    if (_tabErrors[3] != null && _schedules == null) {
      return _tabErrorView(3, () {
        setState(() => _schedules = null);
        _ensureTab(3);
      });
    }
    final list = _schedules ?? [];
    if (list.isEmpty) return _empty('Belum ada jadwal rilis');

    final now = DateTime.now();
    return GridView.builder(
      padding: const EdgeInsets.all(12),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: 10,
        crossAxisSpacing: 10,
        childAspectRatio: 1.05,
      ),
      itemCount: list.length,
      itemBuilder: (_, i) {
        final s = list[i];
        final cd = s.countdownNow(now);
        final hasLive = s.premiereUnix != null && s.premiereUnix! > 0;
        return Material(
          color: const Color(0xFF2A2235),
          borderRadius: BorderRadius.circular(14),
          child: InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: s.platformUrl != null ? () => _open(s.platformUrl) : null,
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Header countdown
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.06),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Column(
                      children: [
                        Text(
                          hasLive ? '${s.label}: $cd' : '${s.label}: $cd',
                          textAlign: TextAlign.center,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: hasLive
                                ? const Color(0xFFFFD88A)
                                : Colors.white70,
                            fontWeight: FontWeight.w800,
                            fontSize: 12,
                            height: 1.25,
                          ),
                        ),
                        if (s.isDefault)
                          const Padding(
                            padding: EdgeInsets.only(top: 4),
                            child: Text(
                              'This schedule might not apply to your region.',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  color: Color(0xFFE85D5D), fontSize: 9),
                            ),
                          ),
                      ],
                    ),
                  ),
                  if ((s.badge ?? '').isNotEmpty)
                    Align(
                      alignment: Alignment.centerRight,
                      child: Container(
                        margin: const EdgeInsets.only(top: 4),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: s.isDefault
                              ? const Color(0xFFFFD88A).withOpacity(0.15)
                              : Colors.white.withOpacity(0.08),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          s.badge!,
                          style: TextStyle(
                            color: s.isDefault
                                ? const Color(0xFFFFD88A)
                                : Colors.white70,
                            fontSize: 9,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ),
                  const Spacer(),
                  if ((s.kind ?? '').isNotEmpty)
                    Text(
                      s.kind!,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w800,
                        fontSize: 13,
                        height: 1.2,
                      ),
                    ),
                  const SizedBox(height: 4),
                  if ((s.platformName ?? '').isNotEmpty ||
                      s.languages.isNotEmpty)
                    Text(
                      [
                        if ((s.platformName ?? '').isNotEmpty) s.platformName!,
                        if (s.languages.isNotEmpty) s.languages.join(' · '),
                      ].join(' · '),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: (s.platformName ?? '').toLowerCase().contains('crunchy')
                            ? const Color(0xFFFF5E00)
                            : Colors.white54,
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildVisualsTab() {
    if (_visuals == null && !_tabLoading.contains(4) && _tabErrors[4] == null) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _ensureTab(4));
    }
    if (_tabLoading.contains(4) && _visuals == null) return _tabLoadingView();
    if (_tabErrors[4] != null && _visuals == null) {
      return _tabErrorView(4, () {
        setState(() => _visuals = null);
        _ensureTab(4);
      });
    }
    final list = _visuals ?? [];
    if (list.isEmpty) return _empty('Belum ada visual');
    return GridView.builder(
      padding: const EdgeInsets.all(12),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: 10,
        crossAxisSpacing: 10,
        childAspectRatio: 0.7,
      ),
      itemCount: list.length,
      itemBuilder: (_, i) => ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: Image.network(
          list[i],
          fit: BoxFit.cover,
          headers: const {
            'User-Agent': 'Mozilla/5.0',
            'Referer': 'https://www.livechart.me/',
          },
          errorBuilder: (_, __, ___) =>
              Container(color: Colors.white10),
        ),
      ),
    );
  }

  Widget _buildHeadlinesTab() {
    if (_headlines == null &&
        !_tabLoading.contains(5) &&
        _tabErrors[5] == null) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _ensureTab(5));
    }
    if (_tabLoading.contains(5) && _headlines == null) return _tabLoadingView();
    if (_tabErrors[5] != null && _headlines == null) {
      return _tabErrorView(5, () {
        setState(() => _headlines = null);
        _ensureTab(5);
      });
    }
    final list = _headlines ?? [];
    if (list.isEmpty) return _empty('Belum ada headlines');
    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: list.length,
      separatorBuilder: (_, __) => const Divider(color: Colors.white10),
      itemBuilder: (_, i) {
        final h = list[i];
        return ListTile(
          contentPadding: EdgeInsets.zero,
          onTap: () => _open(h.url),
          title: Text(h.title,
              style: const TextStyle(
                  color: Colors.white, fontWeight: FontWeight.w600, height: 1.3)),
          subtitle: Text(Uri.tryParse(h.url)?.host ?? '',
              style: const TextStyle(color: Colors.white38, fontSize: 12)),
          trailing:
              const Icon(Icons.open_in_new, color: Colors.white38, size: 16),
        );
      },
    );
  }

  Widget _metaCell(String label, String value) {
    return Expanded(
      child: Column(children: [
        Text(label, style: const TextStyle(color: Colors.white38, fontSize: 11)),
        const SizedBox(height: 4),
        Text(value,
            textAlign: TextAlign.center,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
                color: Colors.white, fontWeight: FontWeight.w700, fontSize: 12)),
      ]),
    );
  }

  Widget _chip(String text, {bool filled = true}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
      decoration: BoxDecoration(
        color: filled ? Colors.white.withOpacity(0.08) : Colors.transparent,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white24),
      ),
      child: Text(text,
          style: const TextStyle(
              color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600)),
    );
  }

  Widget _extBtn(String label, Color color, VoidCallback onTap,
      {bool darkText = false}) {
    return Material(
      color: color,
      borderRadius: BorderRadius.circular(10),
      child: InkWell(
        borderRadius: BorderRadius.circular(10),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          child: Text(label,
              style: TextStyle(
                  color: darkText ? const Color(0xFF17121F) : Colors.white,
                  fontWeight: FontWeight.w800,
                  fontSize: 12)),
        ),
      ),
    );
  }
}
