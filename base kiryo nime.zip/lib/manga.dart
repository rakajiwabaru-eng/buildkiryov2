import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'api_config.dart';
import 'api_sync.dart';
import 'app_notifications.dart';
import 'app_errors.dart';
import 'local_library.dart';
import 'smart_image.dart';

import 'session.dart';


/// URL media komentar (avatar & stiker) yang datang dari server API masih
/// relatif (mis. `/api/media/comment/xxx.png`) → ubah jadi URL absolut supaya
/// bisa dirender oleh semua user, bukan cuma pengirimnya.
String mangaMediaUrl(String url) {
  final u = url.trim();
  if (u.isEmpty) return u;
  if (u.startsWith('http://') || u.startsWith('https://') || u.startsWith('assets/')) {
    return u;
  }
  if (u.startsWith('/api/')) return '$apiBaseUrl$u';
  return u;
}

Widget _mangaCover(String url, {double? width, double? height, double radius = 12}) {
  return SizedBox(
    width: width,
    height: height,
    child: SmartCover(url: url, width: width, height: height, borderRadius: radius),
  );
}


/// Facade untuk image_picker — semua pemanggilan ada di sini supaya kalau
/// nanti package diganti, hanya file ini yang perlu diubah.
class _ImagePickerFacade {
  static Future<String?> pickAndSave(String username) async {
    try {
      final picker = ImagePicker();
      final picked = await picker.pickImage(source: ImageSource.gallery, maxWidth: 720);
      if (picked == null) return null;
      final srcPath = picked.path;
      final dir = await getApplicationDocumentsDirectory();
      final folder = Directory('${dir.path}/custom_stickers/$username');
      if (!folder.existsSync()) folder.createSync(recursive: true);
      final stamp = DateTime.now().millisecondsSinceEpoch;
      final ext = srcPath.contains('.') ? srcPath.substring(srcPath.lastIndexOf('.')) : '.png';
      final dest = '${folder.path}/$stamp$ext';
      await File(srcPath).copy(dest);
      await CustomStickerStore.addPath(username, dest);
      return dest;
    } catch (_) {
      rethrow;
    }
  }
}

class _StickerPlaceholder extends StatelessWidget {
  const _StickerPlaceholder();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.add_photo_alternate_outlined, color: Colors.white24, size: 36),
          const SizedBox(height: 6),
          Text('Tekan "Tambah" untuk membuat stiker',
              style: const TextStyle(color: Colors.white54, fontSize: 11)),
        ],
      ),
    );
  }
}

/// Sumber: Komiku (Bahasa Indonesia)
/// Primary: https://api-komiku.vercel.app
/// Search fallback: https://weeb-scraper.onrender.com/api/komiku
const String _komikuBase = 'https://api-komiku.vercel.app';
const String _weebBase = 'https://weeb-scraper.onrender.com/api/komiku';

// ---------------------------------------------------------------------------
// Models
// ---------------------------------------------------------------------------

class MangaItem {
  const MangaItem({
    required this.slug,
    required this.title,
    required this.coverUrl,
    this.description,
    this.type,
    this.latestChapter,
    this.genre,
  });

  final String slug;
  final String title;
  final String coverUrl;
  final String? description;
  final String? type; // Manga / Manhwa / Manhua
  final String? latestChapter;
  final String? genre;

  String get typeLabel {
    final t = (type ?? '').toLowerCase();
    if (t.contains('manhwa')) return 'Manhwa';
    if (t.contains('manhua')) return 'Manhua';
    if (t.contains('manga')) return 'Manga';
    return type?.isNotEmpty == true ? type! : 'Komik';
  }

  MangaItem copyWith({
    String? slug,
    String? title,
    String? coverUrl,
    String? description,
    String? type,
    String? latestChapter,
    String? genre,
  }) {
    return MangaItem(
      slug: slug ?? this.slug,
      title: title ?? this.title,
      coverUrl: coverUrl ?? this.coverUrl,
      description: description ?? this.description,
      type: type ?? this.type,
      latestChapter: latestChapter ?? this.latestChapter,
      genre: genre ?? this.genre,
    );
  }
}

class MangaChapter {
  const MangaChapter({
    required this.label,
    required this.chapterNumber,
    this.date,
    this.apiPath,
  });

  final String label;
  final String chapterNumber;
  final String? date;
  /// path relatif API: /baca-chapter/{slug}/{num}
  final String? apiPath;
}

class MangaDetail {
  const MangaDetail({
    required this.slug,
    required this.title,
    required this.coverUrl,
    this.synopsis,
    this.type,
    this.status,
    this.genres = const [],
    this.chapters = const [],
  });

  final String slug;
  final String title;
  final String coverUrl;
  final String? synopsis;
  final String? type;
  final String? status;
  final List<String> genres;
  final List<MangaChapter> chapters;

  String get typeLabel {
    final t = (type ?? '').toLowerCase();
    if (t.contains('manhwa')) return 'Manhwa';
    if (t.contains('manhua')) return 'Manhua';
    if (t.contains('manga')) return 'Manga';
    return type?.isNotEmpty == true ? type! : 'Komik';
  }
}

enum MangaTypeFilter { all, manga, manhwa, manhua }

class MangaGenre {
  const MangaGenre({required this.name, required this.slug});
  final String name;
  final String slug;
}

class MangaComment {
  const MangaComment({
    required this.chapter,
    required this.username,
    required this.avatarAsset,
    required this.text,
    required this.createdAt,
    this.id,
    this.parentId,
    this.stickerId,
    this.localStickerPath,
    this.stickerUrl,
    this.stickerText,
  });
  final String chapter;
  final String username;
  final String avatarAsset;
  final String text;
  final String createdAt;

  /// ID unik untuk komentar (dipakai sebagai parentId untuk balasan/thread).
  final String? id;

  /// Jika bukan null, komentar ini adalah balasan dari komentar dengan id ini.
  final String? parentId;

  /// ID stiker bawaan (mis. "sticker_01_yuk_tidur") yang dikirim sebagai
  /// komentar — kalau ada, UI akan render gambar tanpa caption.
  final String? stickerId;

  /// Path lokal stiker buatan pengguna (Custom Sticker). Dipakai saat user
  /// meng-upload gambar mereka sendiri — disimpan ke disk dan dirender.
  final String? localStickerPath;

  /// Stiker custom hasil kiriman ke server: gambar (URL) dikirim sebagai file
  /// ke API agar user lain & setelah install ulang tetap bisa melihatnya.
  final String? stickerUrl;

  /// Stiker custom berbasis teks (tanpa gambar) yang dikirim ke server.
  final String? stickerText;

  bool get isStickerOnly =>
      (stickerId != null && stickerId!.isNotEmpty) ||
      (localStickerPath != null && localStickerPath!.isNotEmpty) ||
      (stickerUrl != null && stickerUrl!.isNotEmpty) ||
      (stickerText != null && stickerText!.isNotEmpty);

  Map<String, dynamic> toJson() => {
        'id': id,
        'parentId': parentId,
        'chapter': chapter,
        'username': username,
        'avatarAsset': avatarAsset,
        'text': text,
        'createdAt': createdAt,
        'stickerId': stickerId,
        'localStickerPath': localStickerPath,
        'stickerUrl': stickerUrl,
        'stickerText': stickerText,
      };

  factory MangaComment.fromJson(Map<String, dynamic> json) => MangaComment(
        id: json['id']?.toString(),
        parentId: json['parentId']?.toString(),
        chapter: '${json['chapter'] ?? ''}',
        username: '${json['username'] ?? 'Pengguna'}',
        avatarAsset: '${json['avatarAsset'] ?? 'assets/images/default_avatar.jpg'}',
        text: '${json['text'] ?? ''}',
        createdAt: '${json['createdAt'] ?? ''}',
        stickerId: json['stickerId']?.toString(),
        localStickerPath: json['localStickerPath']?.toString(),
        stickerUrl: json['stickerUrl']?.toString(),
        stickerText: json['stickerText']?.toString(),
      );

  MangaComment copyWith({
    String? id,
    String? parentId,
    String? chapter,
    String? username,
    String? avatarAsset,
    String? text,
    String? createdAt,
    String? stickerId,
    String? localStickerPath,
    String? stickerUrl,
    String? stickerText,
  }) {
    return MangaComment(
      id: id ?? this.id,
      parentId: parentId ?? this.parentId,
      chapter: chapter ?? this.chapter,
      username: username ?? this.username,
      avatarAsset: avatarAsset ?? this.avatarAsset,
      text: text ?? this.text,
      createdAt: createdAt ?? this.createdAt,
      stickerId: stickerId ?? this.stickerId,
      localStickerPath: localStickerPath ?? this.localStickerPath,
      stickerUrl: stickerUrl ?? this.stickerUrl,
      stickerText: stickerText ?? this.stickerText,
    );
  }

  /// Render pesan untuk tampilan bubble (fallback kalau cuma stiker).
  String get displayText {
    if (text.trim().isNotEmpty) return text;
    if (isStickerOnly) return 'Mengirim stiker';
    return '';
  }
}

class MangaCommentStore {
  static String _key(String slug) => 'manga_comments_$slug';
  static const int _maxComments = 5001;

  static Future<List<MangaComment>> list(String slug) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key(slug));
    if (raw == null || raw.isEmpty) return [];
    try {
      final decoded = jsonDecode(raw);
      if (decoded is! List) return [];
      final all = decoded
          .whereType<Map>()
          .map((item) => MangaComment.fromJson(Map<String, dynamic>.from(item)))
          .where((comment) =>
              comment.text.trim().isNotEmpty || comment.isStickerOnly)
          .toList()
          .reversed
          .toList();
      return all.take(_maxComments).toList();
    } catch (_) {
      return [];
    }
  }

  static Future<List<MangaComment>> _full(String slug) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key(slug));
    if (raw == null || raw.isEmpty) return [];
    try {
      final decoded = jsonDecode(raw);
      if (decoded is! List) return [];
      return decoded
          .whereType<Map>()
          .map((item) => MangaComment.fromJson(Map<String, dynamic>.from(item)))
          .toList();
    } catch (_) {
      return [];
    }
  }

  /// Update avatar di semua komentar user (setelah ganti PP).
  static Future<void> migrateAvatar(String username, String avatarPath) async {
    final u = username.trim().toLowerCase();
    if (u.isEmpty || avatarPath.isEmpty) return;
    final prefs = await SharedPreferences.getInstance();
    for (final key in prefs.getKeys()) {
      if (!key.startsWith('manga_comments_')) continue;
      final raw = prefs.getString(key);
      if (raw == null || raw.isEmpty) continue;
      try {
        final decoded = jsonDecode(raw);
        if (decoded is! List) continue;
        var changed = false;
        final items = <Map<String, dynamic>>[];
        for (final e in decoded) {
          if (e is! Map) continue;
          final m = Map<String, dynamic>.from(e);
          final name = '${m['username'] ?? ''}'.trim().toLowerCase();
          if (name == u) {
            if (m['avatarAsset'] != avatarPath) {
              m['avatarAsset'] = avatarPath;
              changed = true;
            }
          }
          items.add(m);
        }
        if (changed) {
          await prefs.setString(key, jsonEncode(items));
        }
      } catch (_) {}
    }
  }

  static Future<void> add(
    String slug,
    MangaComment comment, {
    String? stickerDataUrl,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    final existing = await _full(slug);
    final items = [comment, ...existing].take(_maxComments).toList();
    await prefs.setString(_key(slug), jsonEncode(items.map((item) => item.toJson()).toList()));
    // Kirim juga ke server → komentar global, tidak hilang saat install ulang.
    await MangaCommentApi.post(slug, comment, stickerDataUrl: stickerDataUrl);
  }

  static Future<void> removeLocal(String slug, String id) async {
    final prefs = await SharedPreferences.getInstance();
    final items = (await _full(slug))
        .where((c) => c.id != id && c.parentId != id)
        .toList();
    await prefs.setString(_key(slug), jsonEncode(items.map((e) => e.toJson()).toList()));
  }

  /// Slug yang komentar lokalnya sudah pernah diunggah ke server — dipakai
  /// saat login supaya kiriman offline ikut terkirim tanpa duplikat.
  static const _syncedKey = 'manga_comments_synced_v1';

  static Future<Set<String>> syncedSlugs() async {
    final prefs = await SharedPreferences.getInstance();
    return (prefs.getStringList(_syncedKey) ?? <String>[]).toSet();
  }

  static Future<void> markSynced(String slug) async {
    final prefs = await SharedPreferences.getInstance();
    final list = await syncedSlugs();
    if (list.add(slug)) {
      await prefs.setStringList(_syncedKey, list.toList());
    }
  }

  /// Sinkron dua arah: kirim komentar lokal yang belum pernah terkirim → tarik
  /// daftar global dari server → simpan sebagai cache lokal.
  static Future<List<MangaComment>> refresh(String slug) async {
    try {
      final synced = await syncedSlugs();
      if (!synced.contains(slug)) {
        final local = await _full(slug);
        for (final c in local) {
          await MangaCommentApi.post(slug, c);
        }
        await markSynced(slug);
      }
      final remote = await MangaCommentApi.fetch(slug);
      if (remote != null) {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString(
          _key(slug),
          jsonEncode(remote.map((e) => e.toJson()).toList()),
        );
        final me = (await SessionStore.getUsername() ?? '').trim().toLowerCase();
        final avatar = await SessionStore.getAvatar();
        final refreshed = [
          for (final c in remote)
            if (me.isNotEmpty && c.username.trim().toLowerCase() == me)
              c.copyWith(avatarAsset: avatar)
            else
              c
        ];
        return refreshed
            .where((c) => c.text.trim().isNotEmpty || c.isStickerOnly)
            .toList();
      }
    } catch (_) {}
    return list(slug);
  }

  static Future<int> countForUser(String slug, String username) async {
    final all = await _full(slug);
    return all.where((c) => c.username == username).length;
  }
}

/// Jembatan HTTP ke endpoint komentar global di API base.
///
/// Komentar TIDAK disimpan hanya di HP lagi: setiap kiriman/hapusan langsung
/// dikirim ke server sehingga (a) tidak hilang saat APK di-uninstall, dan
/// (b) bisa dilihat serta dibalas oleh user lain.
class MangaCommentApi {
  static const _timeout = Duration(seconds: 15);

  static Future<Map<String, String>> _headers() async {
    final token = await SessionStore.getToken();
    return {
      'Content-Type': 'application/json',
      if (token != null && token.isNotEmpty) 'Authorization': 'Bearer $token',
    };
  }

  /// Ambil komentar global satu komik. `null` = gagal (offline / belum login).
  static Future<List<MangaComment>?> fetch(String slug) async {
    try {
      final h = await _headers();
      if (!h.containsKey('Authorization')) return null;
      final res = await http
          .get(Uri.parse('$apiBaseUrl/api/comments/$slug'), headers: h)
          .timeout(_timeout);
      final body = jsonDecode(res.body);
      if (body is Map && body['ok'] == true && body['data'] is List) {
        return (body['data'] as List)
            .whereType<Map>()
            .map((e) => _fromServer(Map<String, dynamic>.from(e)))
            .toList();
      }
    } catch (_) {}
    return null;
  }

  /// Kirim komentar baru. Tidak melempar error agar UI tetap jalan offline —
  /// komentar sudah tersimpan lokal dan akan dikirim saat login berikutnya.
  static Future<bool> post(
    String slug,
    MangaComment comment, {
    String? stickerDataUrl,
  }) async {
    try {
      final h = await _headers();
      if (!h.containsKey('Authorization')) return false;
      final res = await http
          .post(
            Uri.parse('$apiBaseUrl/api/comments/$slug'),
            headers: h,
            body: jsonEncode({
              'comment': {
                'id': comment.id,
                'parentId': comment.parentId,
                'chapter': comment.chapter,
                'text': comment.text,
                'createdAt': comment.createdAt,
                'stickerId': comment.stickerId,
                'stickerText': comment.stickerText,
                if (stickerDataUrl != null) 'stickerDataUrl': stickerDataUrl,
              },
            }),
          )
          .timeout(_timeout);
      final body = jsonDecode(res.body);
      return body is Map && body['ok'] == true;
    } catch (_) {}
    return false;
  }

  /// Hapus komentar sendiri di server. Ini yang membuat komentar benar-benar
  /// hilang untuk semua user — bukan cuma di HP pengirim.
  static Future<bool> delete(String slug, String id) async {
    try {
      final h = await _headers();
      if (!h.containsKey('Authorization')) return false;
      final res = await http
          .delete(Uri.parse('$apiBaseUrl/api/comments/$slug/$id'), headers: h)
          .timeout(_timeout);
      final body = jsonDecode(res.body);
      return body is Map && body['ok'] == true;
    } catch (_) {}
    return false;
  }

  /// Bentuk data dari server (avatar & stiker custom berbentuk URL absolut).
  static MangaComment _fromServer(Map<String, dynamic> json) {
    final avatar = mangaMediaUrl('${json['avatarUrl'] ?? ''}');
    return MangaComment(
      id: json['id']?.toString(),
      parentId: json['parentId']?.toString(),
      chapter: '${json['chapter'] ?? ''}',
      username: '${json['username'] ?? 'Pengguna'}',
      avatarAsset:
          avatar.isEmpty ? 'assets/images/default_avatar.jpg' : avatar,
      text: '${json['text'] ?? ''}',
      createdAt: '${json['createdAt'] ?? ''}',
      stickerId: json['stickerId']?.toString(),
      stickerUrl: mangaMediaUrl('${json['stickerUrl'] ?? ''}'),
      stickerText: json['stickerText']?.toString(),
    );
  }
}

/// Penyimpanan stiker bawaan (built-in) hasil dari `assets/stickers/`.
class BuiltInStickers {
  static const List<({String id, String label, String asset})> items = [
    (id: 'sticker_01_yuk_tidur',     label: 'yuk tidur',     asset: 'assets/stickers/sticker_01_yuk_tidur.png'),
    (id: 'sticker_02_aku_jg_mw',      label: 'aku jg mw',     asset: 'assets/stickers/sticker_02_aku_jg_mw.png'),
    (id: 'sticker_03_kebal_sange',    label: 'kebal sange',   asset: 'assets/stickers/sticker_03_kebal_sange.png'),
    (id: 'sticker_04_halah',          label: 'halah',         asset: 'assets/stickers/sticker_04_halah.png'),
    (id: 'sticker_05_pengenn',        label: 'pengenn..',     asset: 'assets/stickers/sticker_05_pengenn.png'),
    (id: 'sticker_06_aku_aku_mau',    label: 'aku aku mau',   asset: 'assets/stickers/sticker_06_aku_aku_mau.png'),
    (id: 'sticker_07_dahlah_anj',     label: 'dahlah anj',    asset: 'assets/stickers/sticker_07_dahlah_anj.png'),
    (id: 'sticker_08_tersenyum',      label: 'tersenyum',     asset: 'assets/stickers/sticker_08_tersenyum.png'),
    (id: 'sticker_09_aku_muakk',      label: 'aku muakk',     asset: 'assets/stickers/sticker_09_aku_muakk.png'),
    (id: 'sticker_10_capek_gw',       label: 'capek gw',      asset: 'assets/stickers/sticker_10_capek_gw.png'),
    (id: 'sticker_11_sudah_kuduga',   label: 'sudah kuduga',  asset: 'assets/stickers/sticker_11_sudah_kuduga.png'),
    (id: 'sticker_12_gw_udah_nggak',  label: 'gw udah nggak', asset: 'assets/stickers/sticker_12_gw_udah_nggak.png'),
    (id: 'sticker_13_gk_lucu_bngst',  label: 'gk lucu bngst', asset: 'assets/stickers/sticker_13_gk_lucu_bngst.png'),
    (id: 'sticker_14_halah_jembod',   label: 'halah jembod',  asset: 'assets/stickers/sticker_14_halah_jembod.png'),
    (id: 'sticker_15_halah_nyocot',   label: 'halah nyocot',  asset: 'assets/stickers/sticker_15_halah_nyocot.png'),
    (id: 'sticker_16_sepemikiran',    label: 'sepemikiran',   asset: 'assets/stickers/sticker_16_sepemikiran.png'),
    (id: 'sticker_17_aku_mikir_aja_gk', label: 'aku mikir aja gk', asset: 'assets/stickers/sticker_17_aku_mikir_aja_gk.png'),
    (id: 'sticker_18_kapan_kapan',    label: 'kapan kapan',   asset: 'assets/stickers/sticker_18_kapan_kapan.png'),
    (id: 'sticker_19_kapan_yah_gw',   label: 'kapan yah gw',  asset: 'assets/stickers/sticker_19_kapan_yah_gw.png'),
    (id: 'sticker_20_penyakit_my_nya',label: 'penyakit MY nya', asset: 'assets/stickers/sticker_20_penyakit_my_nya.png'),
    (id: 'sticker_21_semuanya_aja_lu_klaim', label: 'semuanya aja lu klaim', asset: 'assets/stickers/sticker_21_semuanya_aja_lu_klaim.png'),
    (id: 'sticker_22_my_istri_bini_gw',label: 'my istri bini gw', asset: 'assets/stickers/sticker_22_my_istri_bini_gw.png'),
    (id: 'sticker_23_menambahkan_ke_my_bini', label: 'my bini', asset: 'assets/stickers/sticker_23_menambahkan_ke_my_bini.png'),
    (id: 'sticker_24_ha_ha_ha',       label: 'ha ha ha',      asset: 'assets/stickers/sticker_24_ha_ha_ha.png'),
    (id: 'sticker_25_mwehehe',        label: 'mwehehe :3',    asset: 'assets/stickers/sticker_25_mwehehe.png'),
    (id: 'sticker_26_kok_kesel_ya',   label: 'kok kesel ya',  asset: 'assets/stickers/sticker_26_kok_kesel_ya.png'),
  ];

  static ({String id, String label, String asset})? byId(String id) {
    for (final s in items) {
      if (s.id == id) return s;
    }
    return null;
  }
}

/// Penyimpanan stiker custom (uploaded) per user, disimpan ke disk
/// via path_provider + SharedPreferences untuk path-nya saja.
class CustomStickerStore {
  static const _keyPrefix = 'custom_stickers_';

  static Future<SharedPreferences> _prefs() => SharedPreferences.getInstance();

  static String _userKey(String username) => '$_keyPrefix${username.trim().toLowerCase()}';

  static Future<List<String>> listPaths(String username) async {
    final prefs = await _prefs();
    final key = _userKey(username);
    final raw = prefs.getStringList(key) ?? <String>[];
    return raw;
  }

  static Future<void> _save(String username, List<String> paths) async {
    final prefs = await _prefs();
    await prefs.setStringList(_userKey(username), paths);
  }

  static Future<String> addPath(String username, String path) async {
    final paths = await listPaths(username);
    if (!paths.contains(path)) {
      paths.insert(0, path);
      if (paths.length > 30) paths.removeRange(30, paths.length);
      await _save(username, paths);
    }
    return path;
  }

  static Future<void> removePath(String username, String path) async {
    final paths = await listPaths(username);
    paths.remove(path);
    await _save(username, paths);
  }
}

/// Genre umum yang dipakai lintas katalog manga, manhwa, dan manhua.
/// Tetap dipakai sebagai fallback agar UI tidak hanya berisi genre yang
/// kebetulan dikembalikan endpoint pada saat itu.
const List<MangaGenre> _commonMangaGenres = [
  MangaGenre(name: 'Action', slug: 'action'),
  MangaGenre(name: 'Adventure', slug: 'adventure'),
  MangaGenre(name: 'Comedy', slug: 'comedy'),
  MangaGenre(name: 'Drama', slug: 'drama'),
  MangaGenre(name: 'Fantasy', slug: 'fantasy'),
  MangaGenre(name: 'Romance', slug: 'romance'),
  MangaGenre(name: 'Ecchi', slug: 'ecchi'),
  MangaGenre(name: 'Harem', slug: 'harem'),
  MangaGenre(name: 'Reverse Harem', slug: 'reverse-harem'),
  MangaGenre(name: 'Isekai', slug: 'isekai'),
  MangaGenre(name: 'Reincarnation', slug: 'reincarnation'),
  MangaGenre(name: 'School Life', slug: 'school-life'),
  MangaGenre(name: 'Slice of Life', slug: 'slice-of-life'),
  MangaGenre(name: 'Shoujo', slug: 'shoujo'),
  MangaGenre(name: 'Shounen', slug: 'shounen'),
  MangaGenre(name: 'Josei', slug: 'josei'),
  MangaGenre(name: 'Seinen', slug: 'seinen'),
  MangaGenre(name: 'Shoujo Ai', slug: 'shoujo-ai'),
  MangaGenre(name: 'Shounen Ai', slug: 'shounen-ai'),
  MangaGenre(name: 'Yuri', slug: 'yuri'),
  MangaGenre(name: 'Yaoi', slug: 'yaoi'),
  MangaGenre(name: 'Boys Love', slug: 'boys-love'),
  MangaGenre(name: 'Girls Love', slug: 'girls-love'),
  MangaGenre(name: 'Adult', slug: 'adult'),
  MangaGenre(name: 'Mature', slug: 'mature'),
  MangaGenre(name: 'Action Martial Arts', slug: 'martial-arts'),
  MangaGenre(name: 'Martial Arts', slug: 'martial-arts'),
  MangaGenre(name: 'Wuxia', slug: 'wuxia'),
  MangaGenre(name: 'Xianxia', slug: 'xianxia'),
  MangaGenre(name: 'Cultivation', slug: 'cultivation'),
  MangaGenre(name: 'Historical', slug: 'historical'),
  MangaGenre(name: 'Military', slug: 'military'),
  MangaGenre(name: 'Mecha', slug: 'mecha'),
  MangaGenre(name: 'Sci-Fi', slug: 'sci-fi'),
  MangaGenre(name: 'Supernatural', slug: 'supernatural'),
  MangaGenre(name: 'Horror', slug: 'horror'),
  MangaGenre(name: 'Mystery', slug: 'mystery'),
  MangaGenre(name: 'Psychological', slug: 'psychological'),
  MangaGenre(name: 'Thriller', slug: 'thriller'),
  MangaGenre(name: 'Sports', slug: 'sports'),
  MangaGenre(name: 'Music', slug: 'music'),
  MangaGenre(name: 'Cooking', slug: 'cooking'),
  MangaGenre(name: 'Medical', slug: 'medical'),
  MangaGenre(name: 'Workplace', slug: 'workplace'),
  MangaGenre(name: 'Tragedy', slug: 'tragedy'),
  MangaGenre(name: 'Mature', slug: 'mature'),
  MangaGenre(name: 'Webtoon', slug: 'webtoon'),
  MangaGenre(name: 'Manhua', slug: 'manhua'),
  MangaGenre(name: 'Manhwa', slug: 'manhwa'),
];

class MangaPageResult {
  const MangaPageResult({
    required this.items,
    required this.page,
    required this.hasNext,
  });
  final List<MangaItem> items;
  final int page;
  final bool hasNext;
}

// ---------------------------------------------------------------------------
// Favorit + cek update chapter
// ---------------------------------------------------------------------------

class MangaFavorite {
  const MangaFavorite({
    required this.slug,
    required this.title,
    required this.coverUrl,
    this.type,
    this.latestChapter,
  });

  final String slug;
  final String title;
  final String coverUrl;
  final String? type;
  final String? latestChapter;

  Map<String, dynamic> toJson() => {
        'slug': slug,
        'title': title,
        'coverUrl': coverUrl,
        'type': type,
        'latestChapter': latestChapter,
      };

  factory MangaFavorite.fromJson(Map<String, dynamic> j) => MangaFavorite(
        slug: (j['slug'] ?? '').toString(),
        title: (j['title'] ?? '').toString(),
        coverUrl: (j['coverUrl'] ?? '').toString(),
        type: j['type']?.toString(),
        latestChapter: j['latestChapter']?.toString(),
      );

  MangaFavorite copyWith({String? latestChapter, String? type, String? coverUrl, String? title}) {
    return MangaFavorite(
      slug: slug,
      title: title ?? this.title,
      coverUrl: coverUrl ?? this.coverUrl,
      type: type ?? this.type,
      latestChapter: latestChapter ?? this.latestChapter,
    );
  }
}

class MangaFavoriteStore {
  static const _key = 'manga_favorites_v1';

  static Future<List<MangaFavorite>> list() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw == null || raw.isEmpty) return [];
    try {
      final decoded = jsonDecode(raw);
      if (decoded is! List) return [];
      return decoded
          .whereType<Map>()
          .map((e) => MangaFavorite.fromJson(Map<String, dynamic>.from(e)))
          .where((e) => e.slug.isNotEmpty)
          .toList();
    } catch (_) {
      return [];
    }
  }

  static Future<void> _save(List<MangaFavorite> items) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _key,
      jsonEncode(items.map((e) => e.toJson()).toList()),
    );
  }

  static Future<bool> isFavorite(String slug) async {
    final all = await list();
    return all.any((e) => e.slug == slug);
  }

  static Future<void> add(MangaFavorite item) async {
    final all = await list();
    all.removeWhere((e) => e.slug == item.slug);
    all.insert(0, item);
    await _save(all);
  }

  static Future<void> remove(String slug) async {
    final all = await list();
    all.removeWhere((e) => e.slug == slug);
    await _save(all);
  }

  static Future<void> updateLatest(String slug, String? latest, {String? type, String? coverUrl, String? title}) async {
    final all = await list();
    final i = all.indexWhere((e) => e.slug == slug);
    if (i < 0) return;
    all[i] = all[i].copyWith(
      latestChapter: latest,
      type: type,
      coverUrl: coverUrl,
      title: title,
    );
    await _save(all);
  }

  /// Cek favorit yang chapter-nya bertambah. Update storage + kembalikan daftar update.
  static Future<List<MangaFavorite>> checkUpdates(MangaApiClient api) async {
    final all = await list();
    if (all.isEmpty) return [];
    final updates = <MangaFavorite>[];
    final refreshed = <MangaFavorite>[];

    for (final fav in all) {
      try {
        final d = await api.fetchDetail(fav.slug);
        final newest = d.chapters.isNotEmpty
            ? (d.chapters.first.chapterNumber.isNotEmpty
                ? d.chapters.first.chapterNumber
                : d.chapters.first.label)
            : fav.latestChapter;
        final prev = (fav.latestChapter ?? '').trim();
        final now = (newest ?? '').trim();
        final changed = now.isNotEmpty && prev.isNotEmpty && now != prev;
        final firstTime = now.isNotEmpty && prev.isEmpty;

        final updated = fav.copyWith(
          latestChapter: now.isNotEmpty ? now : fav.latestChapter,
          type: d.type ?? fav.type,
          coverUrl: d.coverUrl.isNotEmpty ? d.coverUrl : fav.coverUrl,
          title: d.title.isNotEmpty ? d.title : fav.title,
        );
        refreshed.add(updated);

        // Notifikasi hanya jika memang ada chapter baru (bukan pertama kali simpan)
        if (changed) {
          updates.add(updated);
        } else if (firstTime) {
          // simpan baseline tanpa notifikasi
        }
      } catch (_) {
        refreshed.add(fav);
      }
    }

    await _save(refreshed);
    return updates;
  }
}

// ---------------------------------------------------------------------------
// Progress baca: chapter terbaca + halaman terakhir
// ---------------------------------------------------------------------------

class MangaReadStore {
  static const _key = 'manga_read_progress_v1';

  static Future<Map<String, dynamic>> _all() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw == null || raw.isEmpty) return {};
    try {
      final d = jsonDecode(raw);
      if (d is Map) return Map<String, dynamic>.from(d);
    } catch (_) {}
    return {};
  }

  static Future<void> _write(Map<String, dynamic> data) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, jsonEncode(data));
  }

  /// Seluruh progress (per slug) — dikirim ke API agar tidak hilang saat APK
  /// di-uninstall.
  static Future<Map<String, dynamic>> all() => _all();

  /// Gabungkan progress dari server ke penyimpanan lokal.
  /// Per chapter dipilih data dengan `updatedAt` terbaru.
  static Future<void> mergeFrom(Map<String, dynamic> remote) async {
    if (remote.isEmpty) return;
    final all = await _all();
    for (final entry in remote.entries) {
      final slug = entry.key;
      final incoming = entry.value;
      if (slug.isEmpty || incoming is! Map) continue;

      final local = Map<String, dynamic>.from(
        all[slug] is Map ? Map<String, dynamic>.from(all[slug] as Map) : {},
      );
      final chapters = Map<String, dynamic>.from(
        local['chapters'] is Map
            ? Map<String, dynamic>.from(local['chapters'] as Map)
            : {},
      );

      final remoteChapters = incoming['chapters'];
      if (remoteChapters is Map) {
        for (final c in remoteChapters.entries) {
          final info = c.value;
          if (info is! Map) continue;
          final old = chapters[c.key];
          final oldAt = old is Map ? '${old['updatedAt'] ?? ''}' : '';
          final newAt = '${info['updatedAt'] ?? ''}';
          if (old is! Map || newAt.compareTo(oldAt) >= 0) {
            chapters[c.key] = {
              'page': int.tryParse('${info['page']}') ?? 0,
              'read': info['read'] != false,
              'updatedAt':
                  newAt.isEmpty ? DateTime.now().toIso8601String() : newAt,
            };
          }
        }
      }

      final remoteAt = '${incoming['updatedAt'] ?? ''}';
      final localAt = '${local['updatedAt'] ?? ''}';
      final remoteNewer = remoteAt.compareTo(localAt) >= 0;
      all[slug] = {
        'chapters': chapters,
        'lastChapter': remoteNewer
            ? '${incoming['lastChapter'] ?? local['lastChapter'] ?? ''}'
            : '${local['lastChapter'] ?? incoming['lastChapter'] ?? ''}',
        'lastPage': int.tryParse(
                '${(remoteNewer ? incoming['lastPage'] : local['lastPage']) ?? 0}') ??
            0,
        'updatedAt': DateTime.now().toIso8601String(),
      };
    }
    await _write(all);
  }

  static String _normChapter(String chapter) {
    final m = RegExp(r'[\d.]+').firstMatch(chapter);
    return (m?.group(0) ?? chapter).trim();
  }

  /// Set nomor chapter yang sudah dibuka untuk satu komik
  static Future<Set<String>> readChapters(String slug) async {
    final all = await _all();
    final entry = all[slug];
    if (entry is! Map) return {};
    final ch = entry['chapters'];
    if (ch is! Map) return {};
    return ch.keys.map((e) => e.toString()).toSet();
  }

  /// Halaman (index gambar) terakhir di chapter tsb, 0-based
  static Future<int> lastPage(String slug, String chapter) async {
    final all = await _all();
    final entry = all[slug];
    if (entry is! Map) return 0;
    final ch = entry['chapters'];
    if (ch is! Map) return 0;
    final key = _normChapter(chapter);
    final info = ch[key] ?? ch[chapter];
    if (info is Map) {
      final page = int.tryParse('${info['page']}') ?? 0;
      return page < 0 ? 0 : page;
    }
    return 0;
  }

  /// Tandai chapter dibaca + simpan halaman terakhir
  static Future<void> saveProgress({
    required String slug,
    required String chapter,
    required int page,
  }) async {
    if (slug.isEmpty || chapter.isEmpty) return;
    final all = await _all();
    final entry = Map<String, dynamic>.from(
      all[slug] is Map ? Map<String, dynamic>.from(all[slug] as Map) : {},
    );
    final chapters = Map<String, dynamic>.from(
      entry['chapters'] is Map
          ? Map<String, dynamic>.from(entry['chapters'] as Map)
          : {},
    );
    final key = _normChapter(chapter);
    // Simpan posisi terakhir yang sedang dibaca. Jangan selalu memakai halaman
    // terjauh, karena pengguna bisa kembali ke halaman sebelumnya lalu keluar.
    final pageToSave = page < 0 ? 0 : page;
    chapters[key] = {
      'page': pageToSave,
      'read': true,
      'updatedAt': DateTime.now().toIso8601String(),
    };
    entry['chapters'] = chapters;
    entry['lastChapter'] = key;
    entry['lastPage'] = pageToSave;
    all[slug] = entry;
    await _write(all);
  }
}

// ---------------------------------------------------------------------------
// API
// ---------------------------------------------------------------------------

class MangaApiClient {
  MangaApiClient();

  static const _timeout = Duration(seconds: 12);
  static const _coverTimeout = Duration(seconds: 7);
  static const _ua = {'User-Agent': 'KiryoNimeApp/1.0 (Flutter; personal)'};

  Future<http.Response> _get(String url) {
    return http.get(Uri.parse(url), headers: _ua).timeout(_timeout);
  }

  String _cleanThumb(String? url) {
    if (url == null || url.isEmpty) return '';
    final i = url.indexOf('?');
    return i > 0 ? url.substring(0, i) : url;
  }

  /// Cache cover portrait per slug (hindari request berulang).
  static final Map<String, String> _portraitCoverCache = {};

  /// Buka URL asli dari proxy weeb-scraper.
  String _unwrapThumb(String? url) {
    if (url == null || url.isEmpty) return '';
    var u = url.trim();
    final marker = 'url=';
    final i = u.indexOf(marker);
    if (i >= 0) {
      u = Uri.decodeComponent(u.substring(i + marker.length));
    }
    u = u.replaceAll('thumbnail.komiku.org', 'thumbnail.komiku.to');
    return _cleanThumb(u);
  }

  bool _isLandscapeThumb(String url) {
    final u = url.toLowerCase();
    return u.contains('manga_img_horizontal') ||
        u.contains('resize=450,235') ||
        u.contains('resize=240,150');
  }

  /// Ambil cover portrait asli (9:16) dari detail API — sama seperti halaman detail.
  Future<String> resolvePortraitCover(String slug, {String? fallback}) async {
    final key = slug.trim().toLowerCase();
    if (key.isEmpty) return _unwrapThumb(fallback);
    final cached = _portraitCoverCache[key];
    if (cached != null && cached.isNotEmpty) return cached;

    try {
      // Detail vercel: thumbnail sudah portrait (manga_thumbnail-Head-...)
      final res = await http
          .get(Uri.parse('$_komikuBase/detail-komik/$key'), headers: _ua)
          .timeout(_coverTimeout);
      if (res.statusCode >= 200 && res.statusCode < 300) {
        final decoded = jsonDecode(res.body);
        if (decoded is Map) {
          final t = _cleanThumb(decoded['thumbnail']?.toString());
          if (t.isNotEmpty && !_isLandscapeThumb(t)) {
            _portraitCoverCache[key] = t;
            return t;
          }
        }
      }
    } catch (_) {}

    try {
      // Fallback weeb detail
      final res = await http
          .get(Uri.parse('$_weebBase/$key'), headers: _ua)
          .timeout(_coverTimeout);
      if (res.statusCode >= 200 && res.statusCode < 300) {
        final decoded = jsonDecode(res.body);
        if (decoded is Map) {
          final data = decoded['data'];
          final raw = data is Map ? data['thumbnail']?.toString() : null;
          final t = _unwrapThumb(raw);
          if (t.isNotEmpty && !_isLandscapeThumb(t)) {
            _portraitCoverCache[key] = t;
            return t;
          }
          if (t.isNotEmpty) {
            _portraitCoverCache[key] = t;
            return t;
          }
        }
      }
    } catch (_) {}

    final fb = _unwrapThumb(fallback);
    if (fb.isNotEmpty) _portraitCoverCache[key] = fb;
    return fb;
  }

  /// Ganti cover landscape → portrait (background, concurrent terbatas).
  Future<List<MangaItem>> enrichPortraitCovers(List<MangaItem> items) async {
    if (items.isEmpty) return items;
    final out = List<MangaItem>.from(items);
    // unwrap cepat tanpa network
    for (var i = 0; i < out.length; i++) {
      final u = _unwrapThumb(out[i].coverUrl);
      if (u.isNotEmpty) out[i] = out[i].copyWith(coverUrl: u);
    }
    const maxConcurrent = 6;
    var next = 0;
    Future<void> worker() async {
      while (true) {
        final i = next++;
        if (i >= out.length) break;
        final it = out[i];
        final current = _unwrapThumb(it.coverUrl);
        if (current.isNotEmpty && !_isLandscapeThumb(current)) {
          out[i] = it.copyWith(coverUrl: current);
          continue;
        }
        // Skip network kalau sudah ada cache
        final key = it.slug.trim().toLowerCase();
        final cached = _portraitCoverCache[key];
        if (cached != null && cached.isNotEmpty) {
          out[i] = it.copyWith(coverUrl: cached);
          continue;
        }
        final portrait = await resolvePortraitCover(it.slug, fallback: current);
        if (portrait.isNotEmpty) {
          out[i] = it.copyWith(coverUrl: portrait);
        } else if (current.isNotEmpty) {
          out[i] = it.copyWith(coverUrl: current);
        }
      }
    }
    await Future.wait(List.generate(maxConcurrent, (_) => worker()));
    return out;
  }

  MangaItem _fromTerbaru(Map<String, dynamic> json) {
    final slug = (json['mangaSlug'] ?? json['slug'] ?? '').toString();
    return MangaItem(
      slug: slug,
      title: (json['title'] ?? '').toString(),
      coverUrl: _cleanThumb(json['thumbnail']?.toString()),
      description: json['genre']?.toString(),
      type: json['type']?.toString(),
      latestChapter: json['latestChapterTitle']?.toString(),
      genre: json['genre']?.toString(),
    );
  }

  MangaItem _fromWeeb(Map<String, dynamic> json) {
    final slug = (json['param'] ?? '').toString();
    final raw = (json['thumbnail'] ?? '').toString();
    return MangaItem(
      slug: slug,
      title: (json['title'] ?? '').toString(),
      coverUrl: _unwrapThumb(raw),
      description: json['description']?.toString(),
      latestChapter: json['latest_chapter']?.toString(),
    );
  }

  bool _matchType(MangaItem item, MangaTypeFilter filter) {
    if (filter == MangaTypeFilter.all) return true;
    final t = item.typeLabel.toLowerCase();
    switch (filter) {
      case MangaTypeFilter.manga:
        return t == 'manga';
      case MangaTypeFilter.manhwa:
        return t == 'manhwa';
      case MangaTypeFilter.manhua:
        return t == 'manhua';
      case MangaTypeFilter.all:
        return true;
    }
  }

  /// Katalog cepat: page 1 prioritaskan Vercel (biasanya ~1s), fallback Weeb.
  /// Page > 1 tetap Weeb (pagination).
  Future<MangaPageResult> fetchCatalog({int page = 1}) async {
    if (page > 1) {
      return _fetchCatalogWeeb(page);
    }
    // Race: result sukses pertama yang menang (bukan error pertama)
    final completer = Completer<MangaPageResult>();
    var left = 2;
    Object? lastErr;
    void run(Future<MangaPageResult> fut) {
      fut.then((r) {
        if (!completer.isCompleted) completer.complete(r);
      }).catchError((Object e) {
        lastErr = e;
        left--;
        if (left <= 0 && !completer.isCompleted) {
          completer.completeError(
            Exception(
              'Gagal memuat katalog. ${e.toString().replaceFirst("Exception: ", "")}',
            ),
          );
        }
      });
    }
    run(_fetchCatalogVercel());
    run(_fetchCatalogWeeb(1));
    return completer.future.timeout(
      const Duration(seconds: 10),
      onTimeout: () => throw Exception(
        'Katalog terlalu lama. ${(lastErr ?? "timeout").toString().replaceFirst("Exception: ", "")}',
      ),
    );
  }

  Future<MangaPageResult> _fetchCatalogVercel() async {
    final res = await http
        .get(Uri.parse('$_komikuBase/terbaru'), headers: _ua)
        .timeout(const Duration(seconds: 6));
    if (res.statusCode < 200 || res.statusCode >= 300) {
      throw Exception('Vercel katalog gagal');
    }
    final decoded = jsonDecode(res.body);
    if (decoded is! List) throw Exception('Data katalog tidak valid');
    final items = decoded
        .whereType<Map<String, dynamic>>()
        .map(_fromTerbaru)
        .where((e) => e.slug.isNotEmpty && e.title.isNotEmpty)
        .map((e) => e.copyWith(coverUrl: _unwrapThumb(e.coverUrl)))
        .toList();
    if (items.isEmpty) throw Exception('Katalog kosong');
    // Vercel terbaru = feed page 1; next pakai weeb pagination
    return MangaPageResult(items: items, page: 1, hasNext: true);
  }

  Future<MangaPageResult> _fetchCatalogWeeb(int page) async {
    final url = page <= 1 ? _weebBase : '$_weebBase?page=$page';
    final res = await http
        .get(Uri.parse(url), headers: _ua)
        .timeout(const Duration(seconds: 10));
    if (res.statusCode < 200 || res.statusCode >= 300) {
      throw Exception('Gagal memuat katalog komik');
    }
    final decoded = jsonDecode(res.body);
    if (decoded is! Map || decoded['data'] is! List) {
      throw Exception('Data katalog tidak valid');
    }
    final items = (decoded['data'] as List)
        .whereType<Map<String, dynamic>>()
        .map(_fromWeeb)
        .where((e) => e.slug.isNotEmpty && e.title.isNotEmpty)
        .map((e) => e.copyWith(coverUrl: _unwrapThumb(e.coverUrl)))
        .toList();
    final hasNext = decoded['next_page'] != null && items.isNotEmpty;
    return MangaPageResult(items: items, page: page, hasNext: hasNext);
  }

  /// Filter tipe Manga/Manhwa/Manhua (dari feed terbaru yang punya field type)
  Future<List<MangaItem>> fetchByType(MangaTypeFilter type) async {
    final res = await _get('$_komikuBase/terbaru');
    if (res.statusCode < 200 || res.statusCode >= 300) {
      throw Exception('Gagal memuat daftar komik');
    }
    final decoded = jsonDecode(res.body);
    if (decoded is! List) throw Exception('Data tidak valid');
    return decoded
        .whereType<Map<String, dynamic>>()
        .map(_fromTerbaru)
        .where((e) => e.slug.isNotEmpty && e.title.isNotEmpty)
        .where((e) => _matchType(e, type))
        .toList();
  }

  /// Daftar genre (Komiku)
  Future<List<MangaGenre>> fetchGenres() async {
    final merged = <String, MangaGenre>{
      for (final genre in _commonMangaGenres) genre.slug: genre,
    };
    try {
      final res = await _get('$_komikuBase/genre-all');
      if (res.statusCode >= 200 && res.statusCode < 300) {
        final decoded = jsonDecode(res.body);
        if (decoded is List) {
          final list = <MangaGenre>[];
          for (final e in decoded) {
            if (e is! Map) continue;
            final slug = (e['slug'] ?? '').toString();
            var name = (e['title'] ?? e['titleAttr'] ?? slug).toString();
            // "Action (4.110)" → "Action"
            name = name.replaceAll(RegExp(r'\s*\([\d.]+\)\s*'), '').trim();
            if (slug.isEmpty || name.isEmpty) continue;
            list.add(MangaGenre(name: name, slug: slug));
          }
          for (final genre in list) {
            merged[genre.slug.toLowerCase()] = genre;
          }
        }
      }
    } catch (_) {}
    final result = merged.values.toList()
      ..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
    return result;
  }

  /// Komik per genre dari api.komiku.org (HTML partial).
  /// Berisi campuran Manga / Manhwa / Manhua, mendukung pagination.
  Future<MangaPageResult> fetchByGenre(String genreSlug, {int page = 1}) async {
    final slug = genreSlug.trim().toLowerCase();
    if (slug.isEmpty) {
      return MangaPageResult(items: const [], page: page, hasNext: false);
    }
    final p = page < 1 ? 1 : page;
    // Format pagination resmi Komiku: /genre/{slug}/page/{n} (bukan ?page=)
    final url = p <= 1
        ? 'https://api.komiku.org/genre/$slug/'
        : 'https://api.komiku.org/genre/$slug/page/$p';

    final res = await http
        .get(
          Uri.parse(url),
          headers: {
            'User-Agent':
                'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml',
            'Referer': 'https://komiku.org/',
          },
        )
        .timeout(_timeout);

    // Halaman di luar jangkauan biasanya 404 kosong — anggap akhir daftar.
    if (res.statusCode == 404) {
      return MangaPageResult(items: const [], page: p, hasNext: false);
    }
    if (res.statusCode < 200 || res.statusCode >= 300) {
      throw Exception('Gagal memuat genre');
    }

    final html = res.body;
    final items = _parseGenreHtml(html)
        .map((e) => e.copyWith(coverUrl: _unwrapThumb(e.coverUrl)))
        .toList();
    // API biasanya 10 item/halaman. <10 = halaman terakhir.
    final hasNext = items.length >= 10;
    return MangaPageResult(items: items, page: p, hasNext: hasNext);
  }

  /// Ambil beberapa halaman genre sekaligus (paralel biar cepat).
  Future<MangaPageResult> fetchByGenreRange(
    String genreSlug, {
    required int fromPage,
    int pages = 10,
  }) async {
    final all = <MangaItem>[];
    final seen = <String>{};
    var lastPage = fromPage;
    var hasNext = false;

    // Fetch paralel per batch (lebih cepat dari serial)
    final futures = <Future<MangaPageResult>>[];
    for (var i = 0; i < pages; i++) {
      futures.add(fetchByGenre(genreSlug, page: fromPage + i));
    }
    final results = await Future.wait(futures);

    for (var i = 0; i < results.length; i++) {
      final result = results[i];
      final p = fromPage + i;
      lastPage = p;
      if (result.items.isEmpty) {
        hasNext = false;
        // Halaman kosong → halaman berikutnya juga kosong
        break;
      }
      for (final item in result.items) {
        if (seen.add(item.slug)) all.add(item);
      }
      hasNext = result.hasNext;
      if (!result.hasNext) break;
    }

    return MangaPageResult(items: all, page: lastPage, hasNext: hasNext);
  }

  String _decodeHtml(String s) {
    var out = s
        .replaceAll('&amp;', '&')
        .replaceAll('&quot;', '"')
        .replaceAll('&#039;', "'")
        .replaceAll('&#39;', "'")
        .replaceAll('&apos;', "'")
        .replaceAll('&lt;', '<')
        .replaceAll('&gt;', '>')
        .replaceAll('&nbsp;', ' ');
    out = out.replaceAllMapped(RegExp(r'&#(\d+);'), (m) {
      final code = int.tryParse(m.group(1) ?? '');
      if (code == null) return m.group(0) ?? '';
      return String.fromCharCode(code);
    });
    return out;
  }

  /// Parse partial HTML dari api.komiku.org/genre/{slug}/
  List<MangaItem> _parseGenreHtml(String html) {
    final items = <MangaItem>[];
    final seen = <String>{};

    // Setiap kartu: <div class="bge"> ... </div> (nested)
    final cardRe = RegExp(r'<div class="bge">(.*?)<div class="kan">(.*?)</div>\s*</div>',
        caseSensitive: false, dotAll: true);

    for (final m in cardRe.allMatches(html)) {
      final head = m.group(1) ?? '';
      final body = m.group(2) ?? '';

      final slugM = RegExp(r'href="https?://komiku\.org/manga/([^"/]+)/?"',
              caseSensitive: false)
          .firstMatch(head);
      final slug = (slugM?.group(1) ?? '').trim();
      if (slug.isEmpty || seen.contains(slug)) continue;
      seen.add(slug);

      final titleM = RegExp(r'<h3>\s*(.*?)\s*</h3>', caseSensitive: false, dotAll: true)
          .firstMatch(body);
      var title = (titleM?.group(1) ?? '').replaceAll(RegExp(r'<[^>]+>'), '').trim();
      title = _decodeHtml(title);
      if (title.isEmpty) continue;

      final imgM = RegExp(r'<img[^>]+src="([^"]+)"', caseSensitive: false).firstMatch(head);
      var cover = (imgM?.group(1) ?? '').trim();
      // buang query resize
      final qi = cover.indexOf('?');
      if (qi > 0) cover = cover.substring(0, qi);

      final typeM = RegExp(r'<b>\s*(Manga|Manhwa|Manhua)\s*</b>', caseSensitive: false)
          .firstMatch(head);
      final type = typeM?.group(1);

      final descM = RegExp(r'<p>\s*(.*?)\s*</p>', caseSensitive: false, dotAll: true)
          .firstMatch(body);
      var desc = (descM?.group(1) ?? '').replaceAll(RegExp(r'<[^>]+>'), '').trim();
      desc = _decodeHtml(desc);

      final latestM = RegExp(
              r'Terbaru:\s*</span>\s*<span>\s*(.*?)\s*</span>',
              caseSensitive: false,
              dotAll: true)
          .firstMatch(body);
      final latest = (latestM?.group(1) ?? '').replaceAll(RegExp(r'<[^>]+>'), '').trim();

      items.add(MangaItem(
        slug: slug,
        title: title,
        coverUrl: cover,
        description: desc.isEmpty ? null : desc,
        type: type,
        latestChapter: latest.isEmpty ? null : latest,
      ));
    }

    // Fallback lebih longgar jika struktur berubah sedikit
    if (items.isEmpty) {
      final slugTitle = RegExp(
        r'href="https?://komiku\.org/manga/([^"/]+)/?"[^>]*>\s*<h3>\s*(.*?)\s*</h3>',
        caseSensitive: false,
        dotAll: true,
      );
      for (final m in slugTitle.allMatches(html)) {
        final slug = (m.group(1) ?? '').trim();
        var title = (m.group(2) ?? '').replaceAll(RegExp(r'<[^>]+>'), '').trim();
        if (slug.isEmpty || title.isEmpty || seen.contains(slug)) continue;
        seen.add(slug);
        items.add(MangaItem(slug: slug, title: title, coverUrl: ''));
      }
    }

    return items;
  }

  /// Pencarian judul
  Future<MangaPageResult> search(String query, {int page = 1}) async {
    final q = query.trim();
    if (q.isEmpty) return fetchCatalog(page: page);
    if (page > 1) {
      return MangaPageResult(items: const [], page: page, hasNext: false);
    }
    final url = '$_weebBase?s=${Uri.encodeQueryComponent(q)}';
    final res = await _get(url);
    if (res.statusCode < 200 || res.statusCode >= 300) {
      throw Exception('Gagal mencari komik');
    }
    final decoded = jsonDecode(res.body);
    if (decoded is! Map || decoded['data'] is! List) {
      throw Exception('Hasil pencarian tidak valid');
    }
    final items = (decoded['data'] as List)
        .whereType<Map<String, dynamic>>()
        .map(_fromWeeb)
        .where((e) => e.slug.isNotEmpty && e.title.isNotEmpty)
        .map((e) => e.copyWith(coverUrl: _unwrapThumb(e.coverUrl)))
        .toList();
    // Pagination search page>1 tidak stabil di API
    return MangaPageResult(items: items, page: 1, hasNext: false);
  }

  Future<MangaDetail> fetchDetail(String slug) async {
    final res = await _get('$_komikuBase/detail-komik/$slug');
    if (res.statusCode < 200 || res.statusCode >= 300) {
      throw Exception('Gagal memuat detail komik');
    }
    final decoded = jsonDecode(res.body);
    if (decoded is! Map) throw Exception('Detail tidak valid');

    final info = decoded['info'];
    String? type;
    String? status;
    if (info is Map) {
      type = info['Tipe']?.toString() ?? info['Type']?.toString();
      status = info['Status']?.toString();
    }

    final genres = <String>[];
    final g = decoded['genres'];
    if (g is List) {
      for (final e in g) {
        final s = e.toString().trim();
        if (s.isNotEmpty) genres.add(s);
      }
    }

    final chapters = <MangaChapter>[];
    final ch = decoded['chapters'];
    if (ch is List) {
      for (final e in ch) {
        if (e is! Map) continue;
        final num = (e['chapterNumber'] ?? '').toString();
        final title = (e['title'] ?? 'Chapter $num').toString();
        final apiLink = e['apiLink']?.toString();
        chapters.add(MangaChapter(
          label: title,
          chapterNumber: num.isNotEmpty ? num : title,
          date: e['date']?.toString(),
          apiPath: apiLink,
        ));
      }
    }

    return MangaDetail(
      slug: (decoded['slug'] ?? slug).toString(),
      title: (decoded['title'] ?? slug).toString(),
      coverUrl: _cleanThumb(decoded['thumbnail']?.toString()),
      synopsis: (decoded['sinopsis'] ?? decoded['description'])?.toString(),
      type: type,
      status: status,
      genres: genres,
      chapters: chapters,
    );
  }

  /// true jika URL iklan/promo, bukan halaman baca
  bool _isPromoImage(String url) {
    final u = url.toLowerCase();
    return u.contains('promosi') ||
        u.contains('promo') ||
        u.contains('iklan') ||
        u.contains('ads.') ||
        u.endsWith('.webp') && u.contains('komiku-promosi');
  }

  Future<List<String>> fetchChapterImages(String slug, String chapterNumber) async {
    final path = '$_komikuBase/baca-chapter/$slug/$chapterNumber';
    try {
      final res = await _get(path);
      if (res.statusCode >= 200 && res.statusCode < 300) {
        final decoded = jsonDecode(res.body);
        if (decoded is Map) {
          final images = decoded['images'];
          if (images is List && images.isNotEmpty) {
            final urls = <String>[];
            for (final img in images) {
              String src = '';
              String fallback = '';
              if (img is Map) {
                src = (img['src'] ?? '').toString();
                fallback = (img['fallbackSrc'] ?? '').toString();
              } else {
                src = img.toString();
              }
              // utamakan src, simpan fallback sebagai alternatif di query khusus
              final pick = src.startsWith('http')
                  ? src
                  : (fallback.startsWith('http') ? fallback : '');
              if (pick.isEmpty || _isPromoImage(pick)) continue;
              // jika fallback beda host, tandai lewat fragment agar widget bisa retry
              if (fallback.startsWith('http') &&
                  fallback != pick &&
                  !_isPromoImage(fallback)) {
                urls.add('$pick#fb=${Uri.encodeComponent(fallback)}');
              } else {
                urls.add(pick);
              }
            }
            if (urls.isNotEmpty) return urls;
          }
        }
      }
    } catch (_) {}

    // fallback weeb-scraper
    final weebParam = '$slug-chapter-$chapterNumber';
    final res2 = await _get('$_weebBase/chapter/$weebParam');
    if (res2.statusCode < 200 || res2.statusCode >= 300) {
      throw Exception('Gagal memuat halaman chapter');
    }
    final decoded2 = jsonDecode(res2.body);
    if (decoded2 is! Map || decoded2['data'] is! List) {
      throw Exception('Gambar chapter tidak ditemukan');
    }
    return (decoded2['data'] as List)
        .map((e) => e.toString())
        .where((e) => e.startsWith('http') && !_isPromoImage(e))
        .toList();
  }
}

// ---------------------------------------------------------------------------
// Transition
// ---------------------------------------------------------------------------

Route<T> _mangaSlideFadeRoute<T extends Object?>(Widget page) {
  return PageRouteBuilder<T>(
    pageBuilder: (context, animation, secondaryAnimation) => page,
    transitionDuration: const Duration(milliseconds: 320),
    reverseTransitionDuration: const Duration(milliseconds: 280),
    transitionsBuilder: (context, animation, secondaryAnimation, child) {
      final curved = CurvedAnimation(
        parent: animation,
        curve: Curves.easeOutCubic,
        reverseCurve: Curves.easeInCubic,
      );
      return FadeTransition(
        opacity: curved,
        child: SlideTransition(
          position: Tween<Offset>(
            begin: const Offset(0.08, 0),
            end: Offset.zero,
          ).animate(curved),
          child: child,
        ),
      );
    },
  );
}


// ---------------------------------------------------------------------------
// Card grid komik
// ---------------------------------------------------------------------------

class _MangaCard extends StatelessWidget {
  const _MangaCard({required this.item, required this.onTap});

  final MangaItem item;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white.withOpacity(0.06),
      borderRadius: BorderRadius.circular(14),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        // Cover proporsional: jangan terlalu zoom/crop (banyak thumb Komiku landscape)
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Rasio mendekati cover katalog (~2:3), image di-fit tanpa kebesaran
            AspectRatio(
              aspectRatio: 2 / 3,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  ColoredBox(
                    color: const Color(0xFF0E0A14),
                    child: SmartCover(
                      url: item.coverUrl,
                      borderRadius: 0,
                    ),
                  ),
                  if ((item.type ?? '').isNotEmpty)
                    Positioned(
                      left: 8,
                      top: 8,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.65),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          item.typeLabel,
                          style: const TextStyle(
                            color: Color(0xFFFFD88A),
                            fontSize: 10,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(10, 8, 10, 10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      item.title,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w700,
                        fontSize: 12.5,
                        height: 1.25,
                      ),
                    ),
                    if ((item.latestChapter ?? '').isNotEmpty) ...[
                      const SizedBox(height: 4),
                      Text(
                        item.latestChapter!,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Colors.white54,
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Home
// ---------------------------------------------------------------------------
// Home — katalog saja + tombol pencarian
// ---------------------------------------------------------------------------

class MangaHomePage extends StatefulWidget {
  const MangaHomePage({super.key});

  @override
  State<MangaHomePage> createState() => _MangaHomePageState();
}

class _MangaHomePageState extends State<MangaHomePage> {
  final _api = MangaApiClient();

  List<MangaItem> _items = [];
  bool _loading = true;
  String? _error;
  int _page = 1;
  bool _hasNext = false;
  bool _hasPrev = false;
  int _reqId = 0;

  @override
  void initState() {
    super.initState();
    _loadCatalog(page: 1);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _checkFavoriteUpdates();
    });
  }

  Future<void> _checkFavoriteUpdates() async {
    try {
      final updates = await MangaFavoriteStore.checkUpdates(_api);
      if (updates.isEmpty) return;
      // Notifikasi SISTEM (status bar) — bukan dialog di dalam app
      for (final u in updates) {
        final ch = (u.latestChapter ?? '').trim();
        await AppNotifications.showManga(
          title: 'Chapter baru',
          body: ch.isNotEmpty ? '${u.title}\nChapter $ch' : u.title,
          id: u.slug.hashCode,
        );
      }
    } catch (_) {}
  }

  Future<void> _loadCatalog({int page = 1}) async {
    final id = ++_reqId;
    setState(() {
      _loading = true;
      _error = null;
      _page = page;
    });
    try {
      // Tampilkan cache dulu (jika ada) biar terasa instan
      if (page == 1) {
        final cached = await CatalogCache.get('manga_catalog_p1');
        if (cached is List && mounted && id == _reqId) {
          final items = <MangaItem>[];
          for (final e in cached) {
            if (e is! Map) continue;
            final m = Map<String, dynamic>.from(e);
            final slug = '${m['slug'] ?? ''}';
            if (slug.isEmpty) continue;
            items.add(MangaItem(
              slug: slug,
              title: '${m['title'] ?? ''}',
              coverUrl: '${m['coverUrl'] ?? ''}',
              type: m['type']?.toString(),
              latestChapter: m['latestChapter']?.toString(),
              genre: m['genre']?.toString(),
            ));
          }
          if (items.isNotEmpty) {
            setState(() {
              _items = items;
              _loading = false;
              _hasPrev = false;
            });
          }
        }
      }
      final result = await _api.fetchCatalog(page: page);
      if (!mounted || id != _reqId) return;
      setState(() {
        _items = result.items;
        _page = result.page;
        _hasNext = result.hasNext;
        _hasPrev = page > 1;
        _loading = false;
      });
      if (page == 1) {
        await CatalogCache.put(
          'manga_catalog_p1',
          result.items
              .map((e) => {
                    'slug': e.slug,
                    'title': e.title,
                    'coverUrl': e.coverUrl,
                    'type': e.type,
                    'latestChapter': e.latestChapter,
                    'genre': e.genre,
                  })
              .toList(),
        );
      }
      // Cover portrait di background — grid sudah tampil
      _enrichCoversBg(result.items, id);
    } catch (e) {
      if (!mounted || id != _reqId) return;
      setState(() {
        _loading = false;
        // Jangan kosongkan grid jika sudah ada cache / data lama
        if (_items.isEmpty) {
          _error = AppErrors.describe(e);
        } else {
          _error = null;
        }
      });
    }
  }

  Future<void> _enrichCoversBg(List<MangaItem> items, int reqId) async {
    try {
      final enriched = await _api.enrichPortraitCovers(items);
      if (!mounted || reqId != _reqId) return;
      final map = {for (final e in enriched) e.slug: e};
      setState(() {
        _items = _items.map((e) => map[e.slug] ?? e).toList();
      });
    } catch (_) {}
  }

  void _openFavorites() {
    Navigator.of(context).push(
      _mangaSlideFadeRoute(const MangaFavoritesPage()),
    );
  }

  void _openSearch() {
    Navigator.of(context).push(
      _mangaSlideFadeRoute(const MangaSearchPage()),
    );
  }

  void _openDetail(MangaItem item) {
    Navigator.of(context).push(
      _mangaSlideFadeRoute(
        MangaDetailPage(slug: item.slug, titleHint: item.title),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF17121F),
      appBar: AppBar(
        backgroundColor: Colors.black54,
        foregroundColor: Colors.white,
        title: const Text('Baca Komik', style: TextStyle(fontWeight: FontWeight.w800)),
        elevation: 0,
        actions: [
          IconButton(
            tooltip: 'Bookmark',
            onPressed: _openFavorites,
            icon: const Icon(Icons.bookmarks_rounded, color: Color(0xFFFFD88A)),
          ),
          IconButton(
            tooltip: 'Cari komik',
            onPressed: _openSearch,
            icon: const Icon(Icons.search_rounded),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 6),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'Katalog Komiku · Halaman $_page',
                style: const TextStyle(color: Colors.white54, fontSize: 12),
              ),
            ),
          ),
          Expanded(
            child: _loading
                ? const Center(child: _TungguYaLoading())
                : _error != null
                    ? Center(
                        child: Padding(
                          padding: const EdgeInsets.all(24),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(_error!,
                                  style: const TextStyle(color: Colors.white70),
                                  textAlign: TextAlign.center),
                              const SizedBox(height: 16),
                              TextButton(
                                onPressed: () => _loadCatalog(page: _page),
                                style: TextButton.styleFrom(
                                    foregroundColor: const Color(0xFFFFD88A)),
                                child: const Text('Coba lagi'),
                              ),
                            ],
                          ),
                        ),
                      )
                    : _items.isEmpty
                        ? const Center(
                            child: Text('Tidak ada komik',
                                style: TextStyle(color: Colors.white54)),
                          )
                        : RefreshIndicator(
                            color: const Color(0xFFFFD88A),
                            onRefresh: () => _loadCatalog(page: _page),
                            child: GridView.builder(
                              padding:
                                  const EdgeInsets.fromLTRB(16, 4, 16, 16),
                              gridDelegate:
                                  const SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: 2,
                                mainAxisSpacing: 14,
                                crossAxisSpacing: 12,
                                // Cover 2:3 + area judul
                                childAspectRatio: 0.55,
                              ),
                              itemCount: _items.length,
                              itemBuilder: (context, i) => _MangaCard(
                                item: _items[i],
                                onTap: () => _openDetail(_items[i]),
                              ),
                            ),
                          ),
          ),
          if (!_loading)
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  IconButton(
                    onPressed: _hasPrev ? () => _loadCatalog(page: _page - 1) : null,
                    icon: const Icon(Icons.chevron_left_rounded),
                    color: const Color(0xFFFFD88A),
                    disabledColor: Colors.white24,
                  ),
                  Text(
                    'Halaman $_page',
                    style: const TextStyle(
                        color: Colors.white70, fontWeight: FontWeight.w700),
                  ),
                  IconButton(
                    onPressed: _hasNext ? () => _loadCatalog(page: _page + 1) : null,
                    icon: const Icon(Icons.chevron_right_rounded),
                    color: const Color(0xFFFFD88A),
                    disabledColor: Colors.white24,
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Pencarian — tipe + genre (mirip anime)
// ---------------------------------------------------------------------------

class MangaSearchPage extends StatefulWidget {
  const MangaSearchPage({super.key});

  @override
  State<MangaSearchPage> createState() => _MangaSearchPageState();
}

class _MangaSearchPageState extends State<MangaSearchPage> {
  final _api = MangaApiClient();
  final _controller = TextEditingController();
  final _scrollController = ScrollController();

  List<MangaItem> _items = [];
  List<MangaGenre> _genres = [];
  bool _loading = false;
  bool _loadingMore = false; // load more genre — jangan ganti grid (jaga scroll)
  bool _loadingGenres = true;
  String? _error;
  MangaTypeFilter _type = MangaTypeFilter.all;
  MangaGenre? _selectedGenre;
  int _page = 1;
  bool _hasNext = false;
  bool _hasPrev = false;
  bool _didSearch = false;
  int _reqId = 0;

  @override
  void initState() {
    super.initState();
    _loadGenres();
  }

  @override
  void dispose() {
    _controller.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> _loadGenres() async {
    setState(() => _loadingGenres = true);
    try {
      final list = await _api.fetchGenres();
      if (!mounted) return;
      setState(() {
        _genres = list;
        _loadingGenres = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() => _loadingGenres = false);
    }
  }

  Future<void> _run({int page = 1, bool append = false}) async {
    final q = _controller.text.trim();
    final id = ++_reqId;
    setState(() {
      // append: hanya loadingMore — grid tetap tampil, scroll tidak reset
      if (append) {
        _loadingMore = true;
      } else {
        _loading = true;
      }
      _error = null;
      if (!append) _page = page;
      _didSearch = true;
    });
    try {
      MangaPageResult result;

      if (q.isNotEmpty) {
        await SearchSuggest.pushManga(q);
        result = await _api.search(q, page: page);
      } else if (_selectedGenre != null) {
        // Genre: ambil 10 halaman/batch (≈100 judul). append = lanjut batch berikutnya.
        final from = append ? (_page + 1) : 1;
        result = await _api.fetchByGenreRange(
          _selectedGenre!.slug,
          fromPage: from,
          pages: 10,
        );
      } else if (_type != MangaTypeFilter.all) {
        final list = await _api.fetchByType(_type);
        if (!mounted || id != _reqId) return;
        setState(() {
          _items = list;
          _page = 1;
          _hasNext = false;
          _hasPrev = false;
          _loading = false;
        });
        _enrichCoversBg(list, id);
        return;
      } else {
        result = await _api.fetchCatalog(page: page);
      }

      if (!mounted || id != _reqId) return;

      var items = result.items;

      // Filter tipe client-side (genre API sudah punya type).
      if (_type != MangaTypeFilter.all && items.isNotEmpty) {
        final before = items;
        items = items.where((e) => _apiMatchType(e, _type)).toList();
        if (items.isEmpty && q.isNotEmpty && _selectedGenre == null) {
          items = await _filterByType(before, _type);
          if (!mounted || id != _reqId) return;
        }
      }

      if (!mounted || id != _reqId) return;
      setState(() {
        if (append && _selectedGenre != null) {
          // Gabungkan tanpa duplikat slug
          final seen = _items.map((e) => e.slug).toSet();
          final merged = [..._items];
          for (final it in items) {
            if (seen.add(it.slug)) merged.add(it);
          }
          _items = merged;
        } else {
          _items = items;
        }
        _page = result.page;
        final canPage = _selectedGenre != null || q.isEmpty;
        _hasNext = result.hasNext && canPage;
        _hasPrev = !append && page > 1 && canPage && _selectedGenre == null;
        _loading = false;
        _loadingMore = false;
        if (_items.isEmpty) {
          if (_type != MangaTypeFilter.all && _selectedGenre != null) {
            _error =
                'Tidak ada ${_type.name} untuk genre ${_selectedGenre!.name}. Coba filter Semua.';
          } else if (result.items.isEmpty) {
            _error = 'Tidak ada hasil';
          }
        }
      });
      // Cover di background
      _enrichCoversBg(items, id);
    } catch (e) {
      if (!mounted || id != _reqId) return;
      setState(() {
        _error = AppErrors.describe(e);
        _loading = false;
        _loadingMore = false;
        if (_items.isEmpty) _items = [];
      });
    }
  }

  Future<void> _enrichCoversBg(List<MangaItem> items, int reqId) async {
    try {
      final enriched = await _api.enrichPortraitCovers(items);
      if (!mounted || reqId != _reqId) return;
      final map = {for (final e in enriched) e.slug: e};
      setState(() {
        _items = _items.map((e) => map[e.slug] ?? e).toList();
      });
    } catch (_) {}
  }

  Future<void> _loadMoreGenre() async {
    if (_loading || _loadingMore || !_hasNext || _selectedGenre == null) return;
    // Simpan posisi scroll; grid tidak di-dispose saat append
    final keepOffset = _scrollController.hasClients ? _scrollController.offset : null;
    await _run(append: true);
    if (!mounted) return;
    if (keepOffset != null && _scrollController.hasClients) {
      // Tetap di posisi lama; user scroll manual ke item baru
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!_scrollController.hasClients) return;
        final max = _scrollController.position.maxScrollExtent;
        _scrollController.jumpTo(keepOffset.clamp(0.0, max));
      });
    }
  }

  bool _apiMatchType(MangaItem item, MangaTypeFilter type) {
    if (type == MangaTypeFilter.all) return true;
    final t = item.typeLabel.toLowerCase();
    switch (type) {
      case MangaTypeFilter.manga:
        return t == 'manga';
      case MangaTypeFilter.manhwa:
        return t == 'manhwa';
      case MangaTypeFilter.manhua:
        return t == 'manhua';
      case MangaTypeFilter.all:
        return true;
    }
  }

  /// Fallback: ambil tipe dari detail (maks 12) — hanya untuk hasil search judul
  Future<List<MangaItem>> _filterByType(
      List<MangaItem> items, MangaTypeFilter type) async {
    final out = <MangaItem>[];
    final take = items.take(12).toList();
    await Future.wait(take.map((item) async {
      try {
        final d = await _api.fetchDetail(item.slug);
        final t = (d.type ?? '').toLowerCase();
        final match = switch (type) {
          MangaTypeFilter.manga => t.contains('manga'),
          MangaTypeFilter.manhwa => t.contains('manhwa'),
          MangaTypeFilter.manhua => t.contains('manhua'),
          MangaTypeFilter.all => true,
        };
        if (match) {
          out.add(MangaItem(
            slug: item.slug,
            title: item.title,
            coverUrl: item.coverUrl.isNotEmpty ? item.coverUrl : d.coverUrl,
            type: d.type,
            description: item.description,
            latestChapter: item.latestChapter,
            genre: item.genre,
          ));
        }
      } catch (_) {
        // skip jika detail gagal
      }
    }));
    return out;
  }

  void _setType(MangaTypeFilter t) {
    setState(() => _type = t);
    _run(page: 1);
  }

  void _selectGenre(MangaGenre g) {
    setState(() {
      _selectedGenre = _selectedGenre?.slug == g.slug ? null : g;
      _controller.clear();
    });
    _run(page: 1);
  }

  Future<void> _openAllGenres() async {
    final selected = await showModalBottomSheet<MangaGenre>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF241B2D),
      builder: (sheetContext) {
        var query = '';
        return StatefulBuilder(
          builder: (context, setSheetState) {
            final filtered = _genres.where((g) {
              final q = query.trim().toLowerCase();
              return q.isEmpty || g.name.toLowerCase().contains(q) || g.slug.toLowerCase().contains(q);
            }).toList();
            return SafeArea(
              child: Padding(
                padding: EdgeInsets.only(
                  left: 16,
                  right: 16,
                  top: 16,
                  bottom: MediaQuery.of(context).viewInsets.bottom + 16,
                ),
                child: SizedBox(
                  height: MediaQuery.of(context).size.height * 0.78,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const Expanded(
                            child: Text('Semua Genre', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w800)),
                          ),
                          Text('${filtered.length} genre', style: const TextStyle(color: Colors.white54, fontSize: 12)),
                        ],
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        autofocus: false,
                        style: const TextStyle(color: Colors.white),
                        cursorColor: const Color(0xFFFFD88A),
                        onChanged: (value) => setSheetState(() => query = value),
                        decoration: InputDecoration(
                          hintText: 'Cari genre, misalnya ecchi...',
                          hintStyle: const TextStyle(color: Colors.white54),
                          prefixIcon: const Icon(Icons.search_rounded, color: Color(0xFFFFD88A)),
                          filled: true,
                          fillColor: Colors.white.withOpacity(0.1),
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
                        ),
                      ),
                      const SizedBox(height: 12),
                      Expanded(
                        child: filtered.isEmpty
                            ? const Center(child: Text('Genre tidak ditemukan', style: TextStyle(color: Colors.white54)))
                            : GridView.builder(
                                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                                  crossAxisCount: 2,
                                  mainAxisSpacing: 8,
                                  crossAxisSpacing: 8,
                                  childAspectRatio: 3.4,
                                ),
                                itemCount: filtered.length,
                                itemBuilder: (_, index) {
                                  final genre = filtered[index];
                                  final isSelected = _selectedGenre?.slug == genre.slug;
                                  return Material(
                                    color: isSelected ? const Color(0xFFFFD88A) : Colors.white.withOpacity(0.09),
                                    borderRadius: BorderRadius.circular(12),
                                    child: InkWell(
                                      borderRadius: BorderRadius.circular(12),
                                      onTap: () => Navigator.of(sheetContext).pop(genre),
                                      child: Center(
                                        child: Padding(
                                          padding: const EdgeInsets.symmetric(horizontal: 8),
                                          child: Text(
                                            genre.name,
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.center,
                                            style: TextStyle(color: isSelected ? const Color(0xFF17121F) : Colors.white, fontSize: 12, fontWeight: FontWeight.w700),
                                          ),
                                        ),
                                      ),
                                    ),
                                  );
                                },
                              ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );
    if (!mounted || selected == null) return;
    _selectGenre(selected);
  }

  void _goPage(int page) {
    if (page < 1) return;
    // Genre pakai mode append (bukan ganti halaman), lihat _loadMoreGenre
    if (_selectedGenre != null) {
      _loadMoreGenre();
      return;
    }
    _run(page: page);
  }

  void _openDetail(MangaItem item) {
    Navigator.of(context).push(
      _mangaSlideFadeRoute(
        MangaDetailPage(slug: item.slug, titleHint: item.title),
      ),
    );
  }

  String get _modeLabel {
    final parts = <String>[];
    if (_type != MangaTypeFilter.all) {
      parts.add(_type.name[0].toUpperCase() + _type.name.substring(1));
    }
    if (_selectedGenre != null) parts.add(_selectedGenre!.name);
    final q = _controller.text.trim();
    if (q.isNotEmpty) parts.add('"$q"');
    if (parts.isEmpty) return 'Pilih tipe / genre, atau ketik judul';
    return '${parts.join(' · ')} · Halaman $_page';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF17121F),
      appBar: AppBar(
        backgroundColor: Colors.black54,
        foregroundColor: Colors.white,
        title: const Text('Cari Komik', style: TextStyle(fontWeight: FontWeight.w800)),
        elevation: 0,
      ),
      body: Column(
        children: [
          // Search bar
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    style: const TextStyle(color: Colors.white),
                    cursorColor: const Color(0xFFFFD88A),
                    textInputAction: TextInputAction.search,
                    onSubmitted: (_) => _run(page: 1),
                    decoration: InputDecoration(
                      hintText: 'Cari judul komik...',
                      hintStyle: const TextStyle(color: Colors.white54),
                      filled: true,
                      fillColor: Colors.white.withOpacity(0.1),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(16),
                        borderSide: BorderSide.none,
                      ),
                      contentPadding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 14),
                      prefixIcon:
                          const Icon(Icons.search, color: Color(0xFFFFD88A)),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Material(
                  color: const Color(0xFFFFD88A),
                  borderRadius: BorderRadius.circular(14),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(14),
                    onTap: _loading ? null : () => _run(page: 1),
                    child: const Padding(
                      padding:
                          EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                      child:
                          Icon(Icons.search_rounded, color: Color(0xFF17121F)),
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Type
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 6),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  _typeChip('Semua', MangaTypeFilter.all),
                  const SizedBox(width: 8),
                  _typeChip('Manga', MangaTypeFilter.manga),
                  const SizedBox(width: 8),
                  _typeChip('Manhwa', MangaTypeFilter.manhwa),
                  const SizedBox(width: 8),
                  _typeChip('Manhua', MangaTypeFilter.manhua),
                ],
              ),
            ),
          ),

          // Genre
          if (_loadingGenres)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 6),
              child: SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(
                    strokeWidth: 2, color: Color(0xFFFFD88A)),
              ),
            )
          else if (_genres.isNotEmpty)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 6),
              child: Row(
                children: [
                  Expanded(
                    child: SizedBox(
                      height: 40,
                      child: ListView.separated(
                        scrollDirection: Axis.horizontal,
                        itemCount: _genres.length,
                        separatorBuilder: (_, __) => const SizedBox(width: 8),
                        itemBuilder: (context, i) {
                          final g = _genres[i];
                          final selected = _selectedGenre?.slug == g.slug;
                          return Material(
                            color: selected ? const Color(0xFFFFD88A) : Colors.white.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(20),
                            child: InkWell(
                              borderRadius: BorderRadius.circular(20),
                              onTap: _loading ? null : () => _selectGenre(g),
                              child: Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
                                child: Text(g.name, style: TextStyle(color: selected ? const Color(0xFF17121F) : Colors.white, fontWeight: FontWeight.w700, fontSize: 12)),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Material(
                    color: const Color(0xFFFFD88A),
                    borderRadius: BorderRadius.circular(20),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(20),
                      onTap: _loading ? null : _openAllGenres,
                      child: const Padding(
                        padding: EdgeInsets.symmetric(horizontal: 12, vertical: 9),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.tune_rounded, size: 15, color: Color(0xFF17121F)),
                            SizedBox(width: 4),
                            Text('Semua', style: TextStyle(color: Color(0xFF17121F), fontWeight: FontWeight.w800, fontSize: 12)),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),

          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 6),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text(_modeLabel,
                  style: const TextStyle(color: Colors.white54, fontSize: 12)),
            ),
          ),

          Expanded(
            child: !_didSearch && !_loading
                ? const Center(
                    child: Padding(
                      padding: EdgeInsets.all(24),
                      child: Text(
                        'Pilih tipe dan/atau genre,\natau ketik judul lalu cari',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.white54, height: 1.4),
                      ),
                    ),
                  )
                // Loading awal saja yang full-screen; load-more tetap tampilkan grid
                : (_loading && _items.isEmpty)
                    ? const Center(child: _TungguYaLoading())
                    : _error != null && _items.isEmpty
                        ? Center(
                            child: Padding(
                              padding: const EdgeInsets.all(24),
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(_error!,
                                      style: const TextStyle(
                                          color: Colors.white70),
                                      textAlign: TextAlign.center),
                                  const SizedBox(height: 16),
                                  TextButton(
                                    onPressed: () => _run(page: _page),
                                    style: TextButton.styleFrom(
                                        foregroundColor:
                                            const Color(0xFFFFD88A)),
                                    child: const Text('Coba lagi'),
                                  ),
                                ],
                              ),
                            ),
                          )
                        : _items.isEmpty
                            ? const Center(
                                child: Text('Tidak ada hasil',
                                    style: TextStyle(color: Colors.white54)),
                              )
                            : GridView.builder(
                                controller: _scrollController,
                                padding:
                                    const EdgeInsets.fromLTRB(16, 4, 16, 16),
                                gridDelegate:
                                    const SliverGridDelegateWithFixedCrossAxisCount(
                                  crossAxisCount: 2,
                                  mainAxisSpacing: 14,
                                  crossAxisSpacing: 12,
                                  // Cover 2:3 + area judul
                                  childAspectRatio: 0.55,
                                ),
                                itemCount: _items.length,
                                itemBuilder: (context, i) => _MangaCard(
                                  item: _items[i],
                                  onTap: () => _openDetail(_items[i]),
                                ),
                              ),
          ),

          // Genre: tombol "Muat lebih banyak" (append). Katalog/search: pagination biasa.
          if (_didSearch && !_loading && _selectedGenre != null && (_hasNext || _loadingMore))
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
              child: Column(
                children: [
                  Text(
                    _loadingMore
                        ? 'Memuat judul berikutnya...'
                        : '${_items.length} judul dimuat · ketuk untuk lanjut',
                    style: const TextStyle(color: Colors.white54, fontSize: 12),
                  ),
                  const SizedBox(height: 8),
                  SizedBox(
                    width: double.infinity,
                    height: 46,
                    child: ElevatedButton.icon(
                      onPressed: _loadingMore ? null : _loadMoreGenre,
                      icon: _loadingMore
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Color(0xFF17121F),
                              ),
                            )
                          : const Icon(Icons.expand_more_rounded),
                      label: Text(
                        _loadingMore ? 'Memuat...' : 'Muat lebih banyak',
                        style: const TextStyle(fontWeight: FontWeight.w800),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFFFD88A),
                        foregroundColor: const Color(0xFF17121F),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                      ),
                    ),
                  ),
                ],
              ),
            )
          else if (_didSearch && !_loading && _selectedGenre == null && (_hasPrev || _hasNext))
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  IconButton(
                    onPressed: _hasPrev ? () => _goPage(_page - 1) : null,
                    icon: const Icon(Icons.chevron_left_rounded),
                    color: const Color(0xFFFFD88A),
                    disabledColor: Colors.white24,
                  ),
                  Text(
                    'Halaman $_page',
                    style: const TextStyle(
                        color: Colors.white70, fontWeight: FontWeight.w700),
                  ),
                  IconButton(
                    onPressed: _hasNext ? () => _goPage(_page + 1) : null,
                    icon: const Icon(Icons.chevron_right_rounded),
                    color: const Color(0xFFFFD88A),
                    disabledColor: Colors.white24,
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget _typeChip(String label, MangaTypeFilter value) {
    final selected = _type == value;
    return Material(
      color: selected ? const Color(0xFFFFD88A) : Colors.white.withOpacity(0.1),
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: _loading ? null : () => _setType(value),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
          child: Text(
            label,
            style: TextStyle(
              color: selected ? const Color(0xFF17121F) : Colors.white,
              fontWeight: FontWeight.w700,
              fontSize: 13,
            ),
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Detail
// ---------------------------------------------------------------------------


// ---------------------------------------------------------------------------
// Daftar favorit
// ---------------------------------------------------------------------------

class MangaFavoritesPage extends StatefulWidget {
  const MangaFavoritesPage({super.key});

  @override
  State<MangaFavoritesPage> createState() => _MangaFavoritesPageState();
}

class _MangaFavoritesPageState extends State<MangaFavoritesPage> {
  List<MangaFavorite> _items = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final list = await MangaFavoriteStore.list();
    if (!mounted) return;
    setState(() {
      _items = list;
      _loading = false;
    });
  }

  Future<void> _remove(MangaFavorite f) async {
    await MangaFavoriteStore.remove(f.slug);
    // Hapus juga dari tab Favorit (Unduhan Saya) + sinkronkan ke cloud
    await BookmarkStore.remove(f.slug, kind: 'manga');
    ApiSync.pushBookmarks(await BookmarkStore.list());
    await _load();
  }

  void _open(MangaFavorite f) {
    Navigator.of(context).push(
      _mangaSlideFadeRoute(
        MangaDetailPage(slug: f.slug, titleHint: f.title),
      ),
    ).then((_) => _load());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF17121F),
      appBar: AppBar(
        backgroundColor: Colors.black54,
        foregroundColor: Colors.white,
        title: const Text('Bookmark', style: TextStyle(fontWeight: FontWeight.w800)),
        elevation: 0,
      ),
      body: _loading
          ? const Center(
              child: CircularProgressIndicator(color: Color(0xFFFFD88A)))
          : _items.isEmpty
              ? const Center(
                  child: Text(
                    'Belum ada bookmark.\nBuka detail komik lalu tekan ikon bookmark',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white54, height: 1.4),
                  ),
                )
              : ListView.separated(
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
                  itemCount: _items.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 10),
                  itemBuilder: (context, i) {
                    final f = _items[i];
                    return Material(
                      color: Colors.white.withOpacity(0.06),
                      borderRadius: BorderRadius.circular(14),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(14),
                        onTap: () => _open(f),
                        child: Padding(
                          padding: const EdgeInsets.all(10),
                          child: Row(
                            children: [
                              ClipRRect(
                                borderRadius: BorderRadius.circular(10),
                                child: SizedBox(
                                  width: 52,
                                  height: 70,
                                  child: SmartCover(url: f.coverUrl, borderRadius: 8),
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    if ((f.type ?? '').isNotEmpty)
                                      Text(
                                        f.type!,
                                        style: const TextStyle(
                                          color: Color(0xFFFFD88A),
                                          fontSize: 11,
                                          fontWeight: FontWeight.w700,
                                        ),
                                      ),
                                    Text(
                                      f.title,
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.w700,
                                        fontSize: 14,
                                      ),
                                    ),
                                    if ((f.latestChapter ?? '').isNotEmpty)
                                      Text(
                                        'Ch. ${f.latestChapter}',
                                        style: const TextStyle(
                                          color: Colors.white54,
                                          fontSize: 12,
                                        ),
                                      ),
                                  ],
                                ),
                              ),
                              IconButton(
                                tooltip: 'Hapus bookmark',
                                onPressed: () => _remove(f),
                                icon: const Icon(Icons.bookmark_rounded,
                                    color: Color(0xFFFFD88A)),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}

class MangaDetailPage extends StatefulWidget {
  const MangaDetailPage({super.key, required this.slug, this.titleHint});

  final String slug;
  final String? titleHint;

  @override
  State<MangaDetailPage> createState() => _MangaDetailPageState();
}

class _MangaDetailPageState extends State<MangaDetailPage> {
  final _api = MangaApiClient();
  MangaDetail? _detail;
  bool _loading = true;
  String? _error;
  bool _isFav = false;
  Set<String> _readChapters = {};

  @override
  void initState() {
    super.initState();
    _loadFav();
    _loadRead();
    _load();
  }

  Future<void> _loadRead() async {
    final set = await MangaReadStore.readChapters(widget.slug);
    if (!mounted) return;
    setState(() => _readChapters = set);
  }

  bool _isChapterRead(MangaChapter ch) {
    final n = RegExp(r'[\d.]+').firstMatch(ch.chapterNumber)?.group(0) ??
        ch.chapterNumber;
    return _readChapters.contains(n) ||
        _readChapters.contains(ch.chapterNumber) ||
        _readChapters.contains(ch.label);
  }

  Future<void> _loadFav() async {
    final f = await MangaFavoriteStore.isFavorite(widget.slug);
    final b = await BookmarkStore.isBookmarked(widget.slug, kind: 'manga');
    // Reparasi sisi yang hilang agar tab Favorit & halaman Bookmark selalu sinkron
    if (f && !b) {
      try {
        final favs = await MangaFavoriteStore.list();
        for (final it in favs) {
          if (it.slug == widget.slug) {
            await BookmarkStore.add(LibraryEntry(
              id: it.slug,
              title: it.title,
              coverUrl: it.coverUrl,
              kind: 'manga',
              subtitle: it.type,
              progress: it.latestChapter,
            ));
          }
        }
      } catch (_) {}
    } else if (b && !f) {
      try {
        final bms = await BookmarkStore.list(kind: 'manga');
        for (final e in bms) {
          if (e.id == widget.slug) {
            await MangaFavoriteStore.add(MangaFavorite(
              slug: e.id,
              title: e.title,
              coverUrl: e.coverUrl,
              type: e.subtitle,
              latestChapter: e.progress,
            ));
          }
        }
      } catch (_) {}
    }
    if (!mounted) return;
    setState(() => _isFav = f || b);
  }

  Future<void> _toggleFav() async {
    final d = _detail;
    if (d == null) return;
    if (_isFav) {
      await MangaFavoriteStore.remove(d.slug);
      await BookmarkStore.remove(d.slug, kind: 'manga');
      if (!mounted) return;
      setState(() => _isFav = false);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Dihapus dari bookmark')),
      );
    } else {
      final latest = d.chapters.isNotEmpty
          ? (d.chapters.first.chapterNumber.isNotEmpty
              ? d.chapters.first.chapterNumber
              : d.chapters.first.label)
          : null;
      await MangaFavoriteStore.add(MangaFavorite(
        slug: d.slug,
        title: d.title,
        coverUrl: d.coverUrl,
        type: d.typeLabel,
        latestChapter: latest,
      ));
      await BookmarkStore.add(LibraryEntry(
        id: d.slug,
        title: d.title,
        coverUrl: d.coverUrl,
        kind: 'manga',
        subtitle: d.typeLabel,
        progress: latest,
      ));
      if (!mounted) return;
      setState(() => _isFav = true);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Disimpan ke bookmark')),
      );
    }
    // Push ke cloud setiap toggle (simpan/hapus) agar bisa dipulihkan setelah install ulang
    ApiSync.pushBookmarks(await BookmarkStore.list());
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final d = await _api.fetchDetail(widget.slug);
      if (!mounted) return;
      setState(() {
        _detail = d;
        _loading = false;
      });
      // Riwayat baca
      await HistoryStore.add(LibraryEntry(
        id: d.slug,
        title: d.title,
        coverUrl: d.coverUrl,
        kind: 'manga',
        subtitle: d.typeLabel,
        progress: d.chapters.isNotEmpty ? d.chapters.first.label : null,
      ));
      ApiSync.pushHistory(await HistoryStore.list());
      ApiSync.pushBookmarks(await BookmarkStore.list());
      // sinkronkan latest chapter jika sudah favorit
      if (_isFav) {
        final latest = d.chapters.isNotEmpty
            ? (d.chapters.first.chapterNumber.isNotEmpty
                ? d.chapters.first.chapterNumber
                : d.chapters.first.label)
            : null;
        await MangaFavoriteStore.updateLatest(
          d.slug,
          latest,
          type: d.typeLabel,
          coverUrl: d.coverUrl,
          title: d.title,
        );
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = AppErrors.describe(e);
        _loading = false;
      });
    }
  }

  void _openChapter(MangaChapter ch) {
    final chapters = _detail?.chapters ?? const <MangaChapter>[];
    Navigator.of(context)
        .push(
      _mangaSlideFadeRoute(
        MangaReaderPage(
          slug: _detail?.slug ?? widget.slug,
          chapterNumber: ch.chapterNumber,
          chapterTitle: ch.label,
          mangaTitle: _detail?.title ?? widget.titleHint ?? '',
          chapters: chapters,
        ),
      ),
    )
        .then((_) {
      if (mounted) _loadRead();
    });
  }

  @override
  Widget build(BuildContext context) {
    final title = _detail?.title ?? widget.titleHint ?? 'Detail Komik';
    return Scaffold(
      backgroundColor: const Color(0xFF17121F),
      appBar: AppBar(
        backgroundColor: Colors.black54,
        foregroundColor: Colors.white,
        title: Text(title,
            style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
        elevation: 0,
        actions: [
          if (_detail != null)
            IconButton(
              tooltip: _isFav ? 'Hapus bookmark' : 'Simpan bookmark',
              onPressed: _toggleFav,
              icon: Icon(
                _isFav ? Icons.bookmark_rounded : Icons.bookmark_border_rounded,
                color: _isFav ? const Color(0xFFFFD88A) : Colors.white,
              ),
            ),
        ],
      ),
      body: _loading
          ? const Center(
              child: CircularProgressIndicator(color: Color(0xFFFFD88A)))
          : _error != null
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(_error!,
                            style: const TextStyle(color: Colors.white70),
                            textAlign: TextAlign.center),
                        const SizedBox(height: 16),
                        TextButton(
                          onPressed: _load,
                          style: TextButton.styleFrom(
                              foregroundColor: const Color(0xFFFFD88A)),
                          child: const Text('Coba lagi'),
                        ),
                      ],
                    ),
                  ),
                )
              : _buildBody(),
    );
  }

  Widget _buildBody() {
    final d = _detail!;
    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: SizedBox(
                    width: 110,
                    height: 155,
                    child: SmartCover(url: d.coverUrl, borderRadius: 12),
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        d.title,
                        style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w800,
                            fontSize: 17),
                      ),
                      const SizedBox(height: 8),
                      Wrap(
                        spacing: 6,
                        runSpacing: 6,
                        children: [
                          _chip(d.typeLabel),
                          if (d.status != null) _chip(d.status!),
                        ],
                      ),
                      if (d.genres.isNotEmpty) ...[
                        const SizedBox(height: 8),
                        Wrap(
                          spacing: 6,
                          runSpacing: 6,
                          children: d.genres
                              .take(10)
                              .map((g) => _chip(g, muted: true))
                              .toList(),
                        ),
                      ],
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        if (d.synopsis != null && d.synopsis!.trim().isNotEmpty)
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
              child: Text(
                d.synopsis!,
                maxLines: 8,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                    color: Colors.white70, fontSize: 13, height: 1.45),
              ),
            ),
          ),
        const SliverToBoxAdapter(
          child: Padding(
            padding: EdgeInsets.fromLTRB(16, 18, 16, 8),
            child: Text('Daftar Chapter',
                style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                    fontSize: 17)),
          ),
        ),
        if (d.chapters.isEmpty)
          const SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.all(24),
              child: Text(
                'Belum ada chapter',
                style: TextStyle(color: Colors.white54),
                textAlign: TextAlign.center,
              ),
            ),
          )
        else
          SliverList(
            delegate: SliverChildBuilderDelegate(
              (context, i) {
                final ch = d.chapters[i];
                return Material(
                  color: Colors.transparent,
                  child: InkWell(
                    onTap: () => _openChapter(ch),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 12),
                      child: Row(
                        children: [
                          if (_isChapterRead(ch))
                            const Padding(
                              padding: EdgeInsets.only(right: 8),
                              child: Icon(Icons.check_circle_rounded,
                                  color: Color(0xFF6BCB77), size: 18),
                            ),
                          Expanded(
                            child: Text(
                              ch.label,
                              style: TextStyle(
                                  color: _isChapterRead(ch)
                                      ? Colors.white54
                                      : Colors.white,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 14),
                            ),
                          ),
                          if (ch.date != null)
                            Text(ch.date!,
                                style: const TextStyle(
                                    color: Colors.white38, fontSize: 11)),
                          const SizedBox(width: 8),
                          const Icon(Icons.chevron_right_rounded,
                              color: Color(0xFFFFD88A), size: 20),
                        ],
                      ),
                    ),
                  ),
                );
              },
              childCount: d.chapters.length,
            ),
          ),
        const SliverToBoxAdapter(child: SizedBox(height: 24)),
      ],
    );
  }

  Widget _chip(String text, {bool muted = false}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: muted
            ? Colors.white.withOpacity(0.08)
            : const Color(0xFFFFD88A).withOpacity(0.2),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        text,
        style: TextStyle(
          color: muted ? Colors.white70 : const Color(0xFFFFD88A),
          fontSize: 11,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Reader
// ---------------------------------------------------------------------------

class MangaReaderPage extends StatefulWidget {
  const MangaReaderPage({
    super.key,
    required this.slug,
    required this.chapterNumber,
    required this.chapterTitle,
    this.mangaTitle = '',
    this.chapters = const [],
  });

  final String slug;
  final String chapterNumber;
  final String chapterTitle;
  final String mangaTitle;
  /// Daftar chapter (urutan dari API, biasanya terbaru dulu)
  final List<MangaChapter> chapters;

  @override
  State<MangaReaderPage> createState() => _MangaReaderPageState();
}

class _MangaReaderPageState extends State<MangaReaderPage> {
  final _api = MangaApiClient();
  final _scrollController = ScrollController();
  final _commentController = TextEditingController();
  final _commentFocus = FocusNode();
  final GlobalKey _commentsKey = GlobalKey();
  final Map<int, GlobalKey> _pageKeys = {};
  List<String> _images = [];
  bool _loading = true;
  String? _error;

  /// Index di list yang diurutkan ascending (ch 1 → ch terakhir)
  int _index = -1;
  List<MangaChapter> _ordered = const [];

  /// Load berurutan: index <= _loadUntil boleh download
  int _loadUntil = 2;
  final Set<int> _done = {};

  /// Halaman terakhir yang dibaca (index gambar)
  int _resumeIndex = 0;
  int _maxViewed = 0;
  int _lastVisiblePage = -1;
  bool _didResume = false;
  bool _controlsVisible = false;
  bool _nearBottom = false;
  List<MangaComment> _comments = [];
  bool _commentsLoading = true;
  bool _commentSending = false;
  final GlobalKey _resumeKey = GlobalKey();

  // ===================== Komentar — stiker & reply =====================
  String _currentUsername = 'Pengguna';
  String _currentAvatar = 'assets/images/default_avatar.jpg';
  bool _stickerTrayOpen = false;
  int _stickerTab = 0; // 0 = bawaan, 1 = stiker saya
  List<String> _customStickerPaths = const [];
  final Map<String, List<MangaComment>> _childMap = {};

  // target reply: parentId jika root, atau parentId dari parent jika reply-to-reply.
  String? _replyingToId;
  // caption opsional saat kirim stiker (boleh kosong, stiker jadi pesan utama).
  String? _pendingStickerId;
  // Asset stiker yang dipilih di tray (ID built-in).
  ({String id, String label, String asset})? _pickedSticker;

  static const _headers = {
    'User-Agent':
        'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36',
    'Referer': 'https://komiku.org/',
    'Accept': 'image/webp,image/apng,image/*,*/*;q=0.8',
  };

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(_onScrollPositionChanged);
    _prepareNav();
    _bootstrapUser();
    _loadComments();
    _load();
  }

  Future<void> _bootstrapUser() async {
    final username = await SessionStore.getUsername() ?? 'Pengguna';
    final avatar = await SessionStore.getAvatar();
    final paths = await CustomStickerStore.listPaths(username);
    // Sinkronkan PP terbaru ke semua komentar user ini di storage lokal
    await MangaCommentStore.migrateAvatar(username, avatar);
    if (!mounted) return;
    setState(() {
      _currentUsername = username;
      _currentAvatar = avatar;
      _customStickerPaths = paths;
    });
  }

  /// Avatar terbaru untuk komentar milik user sendiri (supaya ganti PP langsung
  /// terlihat di semua komentar lama, bukan hanya komentar baru).
  String _avatarForComment(MangaComment c) {
    if (c.username.trim().toLowerCase() == _currentUsername.trim().toLowerCase() &&
        _currentAvatar.isNotEmpty) {
      return _currentAvatar;
    }
    return c.avatarAsset;
  }

  @override
  void dispose() {
    _scrollController.removeListener(_onScrollPositionChanged);
    _commentController.dispose();
    _commentFocus.dispose();
    _persistProgress();
    _scrollController.dispose();
    super.dispose();
  }

  void _onScrollPositionChanged() {
    if (!mounted || _images.isEmpty) return;
    var atBottom = false;
    if (_scrollController.hasClients) {
      final pos = _scrollController.position;
      atBottom = pos.pixels >= (pos.maxScrollExtent - 220);
    }
    if (atBottom != _nearBottom) {
      setState(() => _nearBottom = atBottom);
    }
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _saveVisiblePage();
    });
  }

  void _scrollToComments() {
    if (!_scrollController.hasClients) return;
    final target = _scrollController.position.maxScrollExtent;
    _scrollController.animateTo(
      target,
      duration: const Duration(milliseconds: 450),
      curve: Curves.easeOutCubic,
    );
  }

  void _scrollToTop() {
    if (!_scrollController.hasClients) return;
    _scrollController.animateTo(
      0,
      duration: const Duration(milliseconds: 450),
      curve: Curves.easeOutCubic,
    );
  }

  /// Tombol pojok kanan: panah bawah → ke komentar, panah atas → ke atas chapter.
  Widget _scrollJumpButton() {
    final goDown = !_nearBottom;
    return Material(
      color: const Color(0xFF2A2235).withOpacity(0.92),
      elevation: 4,
      shape: const CircleBorder(),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: goDown ? _scrollToComments : _scrollToTop,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Icon(
            goDown
                ? Icons.keyboard_arrow_down_rounded
                : Icons.keyboard_arrow_up_rounded,
            color: const Color(0xFFFFD88A),
            size: 28,
          ),
        ),
      ),
    );
  }

  void _saveVisiblePage() {
    final viewport = MediaQuery.sizeOf(context).height;
    var bestPage = -1;
    var bestVisible = 0.0;
    for (final entry in _pageKeys.entries) {
      final renderObject = entry.value.currentContext?.findRenderObject();
      if (renderObject is! RenderBox || !renderObject.hasSize) continue;
      final top = renderObject.localToGlobal(Offset.zero).dy;
      final bottom = top + renderObject.size.height;
      final visible = (bottom.clamp(0.0, viewport) - top.clamp(0.0, viewport))
          .clamp(0.0, renderObject.size.height)
          .toDouble();
      if (visible > bestVisible) {
        bestVisible = visible;
        bestPage = entry.key;
      }
    }
    if (bestPage < 0 || bestPage == _lastVisiblePage) return;
    _lastVisiblePage = bestPage;
    _maxViewed = bestPage;
    // Simpan segera saat pengguna berpindah halaman, sehingga tombol back,
    // swipe back, atau menutup reader tetap mempertahankan posisi terbaru.
    _persistProgress();
  }

  Future<void> _persistProgress() async {
    await MangaReadStore.saveProgress(
      slug: widget.slug,
      chapter: widget.chapterNumber,
      page: _maxViewed,
    );
    // Kirim ke server: chapter yang pernah dibuka & posisi terakhir tetap ada
    // setelah APK di-uninstall lalu dipasang lagi.
    await ApiSync.pushReading();
  }

  /// Ambil komentar GLOBAL dari server (semua user bisa lihat & balas).
  /// Kalau offline / belum login, jatuh ke cache lokal.
  Future<void> _loadComments() async {
    final comments = await MangaCommentStore.refresh(widget.slug);
    if (!mounted) return;
    final me = _currentUsername.trim().toLowerCase();
    final refreshed = [
      for (final c in comments)
        if (me.isNotEmpty && c.username.trim().toLowerCase() == me)
          c.copyWith(avatarAsset: _currentAvatar)
        else
          c
    ];
    setState(() {
      _comments = refreshed;
      _commentsLoading = false;
    });
  }

  /// Batas ukuran gambar stiker yang diunggah ke server (~600 KB).
  static const _maxStickerBytes = 600 * 1024;

  /// Stiker bawaan (asset) → data URL PNG supaya bisa dikirim ke server dan
  /// dilihat user lain, bukan hanya pengirimnya.
  Future<String?> _assetDataUrl(String asset) async {
    try {
      final data = await rootBundle.load(asset);
      if (data.lengthInBytes > _maxStickerBytes) return null;
      return 'data:image/png;base64,${base64Encode(data.buffer.asUint8List())}';
    } catch (_) {
      return null;
    }
  }

  /// Stiker custom dari galeri HP → data URL PNG.
  Future<String?> _fileDataUrl(String path) async {
    try {
      final f = File(path);
      if (!await f.exists()) return null;
      if (await f.length() > _maxStickerBytes) return null;
      return 'data:image/png;base64,${base64Encode(await f.readAsBytes())}';
    } catch (_) {
      return null;
    }
  }

  Future<void> _sendComment() async {
    final text = _commentController.text.trim();
    final stickerId = _pendingStickerId;
    if ((text.isEmpty && stickerId == null) || _commentSending) return;
    setState(() => _commentSending = true);
    final username = await SessionStore.getUsername() ?? 'Pengguna';
    final avatarAsset = await SessionStore.getAvatar();
    final now = DateTime.now();
    final pid = now.microsecondsSinceEpoch.toString();
    final comment = MangaComment(
      id: pid,
      parentId: _replyingToId,
      chapter: widget.chapterNumber,
      username: username,
      avatarAsset: avatarAsset,
      text: text,
      createdAt: now.toIso8601String(),
      stickerId: stickerId,
    );
    String? stickerDataUrl;
    if (stickerId != null) {
      final s = BuiltInStickers.byId(stickerId);
      if (s != null) stickerDataUrl = await _assetDataUrl(s.asset);
    }
    // Simpan lokal + kirim ke server (komentar global).
    await MangaCommentStore.add(widget.slug, comment, stickerDataUrl: stickerDataUrl);
    if (!mounted) return;
    _commentController.clear();
    _replyingToId = null;
    _pendingStickerId = null;
    setState(() {
      _comments = [comment, ..._comments];
      _commentSending = false;
      _stickerTrayOpen = false;
    });
  }

  /// Hapus komentar — lokal DAN di server, jadi benar-benar hilang untuk semua
  /// orang (bukan cuma di HP sendiri).
  Future<void> _deleteComment(MangaComment c) async {
    final id = c.id;
    if (id == null || id.isEmpty) return;
    setState(() {
      _comments =
          _comments.where((x) => x.id != id && x.parentId != id).toList();
      if (_replyingToId == id) _replyingToId = null;
    });
    await MangaCommentStore.removeLocal(widget.slug, id);
    await MangaCommentApi.delete(widget.slug, id);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Komentar dihapus')),
    );
  }

  /// Menu aksi komentar (balas / hapus milik sendiri).
  void _commentMenu(MangaComment c) {
    final mine = c.username.trim().toLowerCase() ==
        _currentUsername.trim().toLowerCase();
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1F1929),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
      ),
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading:
                  const Icon(Icons.reply_rounded, color: Color(0xFFFFD88A)),
              title: const Text('Balas komentar',
                  style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.pop(ctx);
                _toggleReply(c);
              },
            ),
            if (mine)
              ListTile(
                leading: const Icon(Icons.delete_outline_rounded,
                    color: Colors.redAccent),
                title: const Text('Hapus komentar',
                    style: TextStyle(color: Colors.redAccent)),
                onTap: () async {
                  Navigator.pop(ctx);
                  await _deleteComment(c);
                },
              ),
          ],
        ),
      ),
    );
  }

  void _toggleReply(MangaComment parent) {
    final enable = _replyingToId != parent.id;
    setState(() {
      _replyingToId = enable ? parent.id : null;
      _commentController.clear();
      _pendingStickerId = null;
    });
    if (enable) {
      // Buka keyboard + pastikan area komentar terlihat
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) return;
        _commentFocus.requestFocus();
        if (_scrollController.hasClients) {
          final pos = _scrollController.position;
          // Geser sedikit ke bawah agar composer & baner reply tidak tertutup
          final target = (pos.maxScrollExtent - 80).clamp(0.0, pos.maxScrollExtent);
          if (pos.pixels < target - 40) {
            _scrollController.animateTo(
              target,
              duration: const Duration(milliseconds: 350),
              curve: Curves.easeOut,
            );
          }
        }
      });
    } else {
      _commentFocus.unfocus();
    }
  }

  void _cancelReply() {
    setState(() {
      _replyingToId = null;
      _pendingStickerId = null;
    });
    _commentFocus.unfocus();
  }

  void _toggleStickerTray() {
    setState(() {
      _stickerTrayOpen = !_stickerTrayOpen;
      if (!_stickerTrayOpen) _pendingStickerId = null;
    });
  }

  void _selectBuiltInSticker(({String id, String label, String asset}) s) {
    setState(() {
      _pendingStickerId = _pendingStickerId == s.id ? null : s.id;
      if (_pendingStickerId != null) _stickerTrayOpen = false;
    });
  }

  Future<void> _addCustomStickerFromAsset(String path) async {
    final username = _currentUsername;
    await CustomStickerStore.addPath(username, path);
    final list = await CustomStickerStore.listPaths(username);
    if (!mounted) return;
    setState(() {
      _customStickerPaths = list;
      _stickerTab = 1;
    });
  }

  Future<void> _sendCustomSticker(String path) async {
    if (_commentSending) return;
    setState(() => _commentSending = true);
    final username = await SessionStore.getUsername() ?? 'Pengguna';
    final avatarAsset = await SessionStore.getAvatar();
    final now = DateTime.now();
    final pid = now.microsecondsSinceEpoch.toString();
    final text = _commentController.text.trim();
    final comment = MangaComment(
      id: pid,
      parentId: _replyingToId,
      chapter: widget.chapterNumber,
      username: username,
      avatarAsset: avatarAsset,
      text: text,
      createdAt: now.toIso8601String(),
      localStickerPath: path,
      stickerText: path.startsWith('sticker:text:')
          ? path.substring('sticker:text:'.length)
          : null,
    );
    // Gambar diunggah ke server sebagai file agar bisa dilihat user lain
    // (stiker teks ikut sebagai teks, tanpa gambar).
    final stickerDataUrl = path.startsWith('sticker:text:')
        ? null
        : await _fileDataUrl(path);
    await MangaCommentStore.add(widget.slug, comment,
        stickerDataUrl: stickerDataUrl);
    if (!mounted) return;
    _commentController.clear();
    _replyingToId = null;
    _pendingStickerId = null;
    setState(() {
      _comments = [comment, ..._comments];
      _commentSending = false;
      _stickerTrayOpen = false;
    });
  }

  Map<String, List<MangaComment>> _buildChildMap() {
    final map = <String, List<MangaComment>>{};
    for (final c in _comments) {
      final p = c.parentId;
      if (p == null || p.isEmpty) continue;
      map.putIfAbsent(p, () => []).add(c);
    }
    for (final list in map.values) {
      list.sort((a, b) => a.createdAt.compareTo(b.createdAt));
    }
    return map;
  }

  String _chapterTagFor(MangaComment c) {
    final cur = widget.chapterNumber;
    if (c.chapter == cur) return 'Chapter ini';
    return 'Chapter ${c.chapter}';
  }

  String _ago(String iso) {
    if (iso.isEmpty) return '';
    final t = DateTime.tryParse(iso);
    if (t == null) return '';
    final d = DateTime.now().difference(t);
    if (d.inSeconds < 60) return 'baru saja';
    if (d.inMinutes < 60) return '${d.inMinutes}m';
    if (d.inHours < 24) return '${d.inHours}j';
    if (d.inDays < 7) return '${d.inDays}h';
    return '${(d.inDays / 7).floor()}mgu';
  }

  void _onPageReady(int index) {
    if (!mounted) return;
    _done.add(index);

    var next = _loadUntil;
    while (_done.contains(next) && next < _images.length) {
      next++;
    }
    final target = (next + 2).clamp(0, _images.length <= 0 ? 0 : _images.length - 1);
    if (target > _loadUntil) {
      setState(() => _loadUntil = target);
    }

    // Resume ke halaman terakhir setelah target siap
    if (!_didResume && index >= _resumeIndex && _resumeIndex > 0) {
      _didResume = true;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        final ctx = _resumeKey.currentContext;
        if (ctx != null) {
          Scrollable.ensureVisible(
            ctx,
            alignment: 0.05,
            duration: const Duration(milliseconds: 350),
            curve: Curves.easeOutCubic,
          );
        }
      });
    }
  }

  void _prepareNav() {
    _ordered = List<MangaChapter>.from(widget.chapters);
    // Urutkan naik berdasarkan nomor chapter
    _ordered.sort((a, b) {
      final na = double.tryParse(
              RegExp(r'[\d.]+').firstMatch(a.chapterNumber)?.group(0) ?? '') ??
          0;
      final nb = double.tryParse(
              RegExp(r'[\d.]+').firstMatch(b.chapterNumber)?.group(0) ?? '') ??
          0;
      return na.compareTo(nb);
    });
    final cur = RegExp(r'[\d.]+')
            .firstMatch(widget.chapterNumber)
            ?.group(0) ??
        widget.chapterNumber;
    _index = _ordered.indexWhere((c) {
      final n =
          RegExp(r'[\d.]+').firstMatch(c.chapterNumber)?.group(0) ?? c.chapterNumber;
      return n == cur || c.chapterNumber == widget.chapterNumber || c.label == widget.chapterTitle;
    });
  }

  MangaChapter? get _prev =>
      (_index > 0 && _ordered.isNotEmpty) ? _ordered[_index - 1] : null;

  MangaChapter? get _next =>
      (_index >= 0 && _index < _ordered.length - 1) ? _ordered[_index + 1] : null;

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      var num = widget.chapterNumber;
      final m = RegExp(r'[\d.]+').firstMatch(num);
      if (m != null) num = m.group(0)!;
      final imgs = await _api.fetchChapterImages(widget.slug, num);
      if (!mounted) return;
      // Ambil halaman terakhir yang pernah dibaca
      final saved = await MangaReadStore.lastPage(widget.slug, widget.chapterNumber);
      final resume = saved.clamp(0, imgs.isEmpty ? 0 : imgs.length - 1);
      final initialUntil = imgs.isEmpty
          ? 0
          : (resume + 2).clamp(0, imgs.length - 1);
      // minimal buka 3 halaman di awal jika resume di 0
      final loadUntil = resume > 0
          ? initialUntil
          : (imgs.length < 3 ? imgs.length - 1 : 2);

      // tandai chapter sudah dibuka (halaman 0 dulu)
      await MangaReadStore.saveProgress(
        slug: widget.slug,
        chapter: widget.chapterNumber,
        page: resume,
      );

      if (!mounted) return;
      setState(() {
        _images = imgs;
        _loading = false;
        _resumeIndex = resume;
        _maxViewed = resume;
        _loadUntil = loadUntil;
        _done.clear();
        _pageKeys.clear();
        _lastVisiblePage = -1;
        _didResume = resume <= 0;
      });
      _precacheRange(0, _loadUntil);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = AppErrors.describe(e);
        _loading = false;
      });
    }
  }

  Future<void> _precacheRange(int from, int to) async {
    for (int i = from; i <= to && i < _images.length; i++) {
      if (!mounted) return;
      final raw = _images[i];
      final hash = raw.indexOf('#fb=');
      final url = hash > 0 ? raw.substring(0, hash) : raw;
      try {
        await precacheImage(
          NetworkImage(url, headers: _headers),
          context,
        );
      } catch (_) {}
      if (!mounted) return;
      _onPageReady(i);
    }
  }

  void _goChapter(MangaChapter ch) {
    Navigator.of(context).pushReplacement(
      _mangaSlideFadeRoute(
        MangaReaderPage(
          slug: widget.slug,
          chapterNumber: ch.chapterNumber,
          chapterTitle: ch.label,
          mangaTitle: widget.mangaTitle,
          chapters: widget.chapters,
        ),
      ),
    );
  }

  Future<void> _openChapterList() async {
    if (_ordered.isEmpty) return;
    final selected = await showModalBottomSheet<MangaChapter>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF241B2D),
      builder: (sheetContext) {
        // Chapter terbaru di atas agar konsisten dengan daftar di halaman detail.
        final chapters = _ordered.reversed.toList();
        return SafeArea(
          child: SizedBox(
            height: MediaQuery.of(context).size.height * 0.78,
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 16, 18, 12),
                  child: Row(
                    children: [
                      const Expanded(
                        child: Text(
                          'Daftar Chapter',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                      Text(
                        '${chapters.length} chapter',
                        style: const TextStyle(color: Colors.white54, fontSize: 12),
                      ),
                    ],
                  ),
                ),
                const Divider(color: Colors.white12, height: 1),
                Expanded(
                  child: ListView.builder(
                    itemCount: chapters.length,
                    itemBuilder: (context, index) {
                      final chapter = chapters[index];
                      final isCurrent = chapter.chapterNumber == widget.chapterNumber ||
                          chapter.label == widget.chapterTitle;
                      return Material(
                        color: isCurrent
                            ? const Color(0xFFFFD88A).withOpacity(0.16)
                            : Colors.transparent,
                        child: InkWell(
                          onTap: () => Navigator.of(sheetContext).pop(chapter),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 18, vertical: 13),
                            child: Row(
                              children: [
                                if (isCurrent)
                                  const Padding(
                                    padding: EdgeInsets.only(right: 8),
                                    child: Icon(Icons.play_arrow_rounded,
                                        color: Color(0xFFFFD88A), size: 18),
                                  ),
                                Expanded(
                                  child: Text(
                                    chapter.label,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                      color: isCurrent
                                          ? const Color(0xFFFFD88A)
                                          : Colors.white,
                                      fontWeight: isCurrent
                                          ? FontWeight.w800
                                          : FontWeight.w600,
                                      fontSize: 14,
                                    ),
                                  ),
                                ),
                                if (chapter.date != null)
                                  Text(chapter.date!,
                                      style: const TextStyle(
                                          color: Colors.white38, fontSize: 11)),
                                const SizedBox(width: 8),
                                const Icon(Icons.chevron_right_rounded,
                                    color: Colors.white38, size: 19),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
    if (!mounted || selected == null) return;
    if (selected.chapterNumber == widget.chapterNumber &&
        selected.label == widget.chapterTitle) {
      return;
    }
    _goChapter(selected);
  }

  Widget _navButtons() {
    final prev = _prev;
    final next = _next;
    if (prev == null && next == null) {
      return const SizedBox(height: 24);
    }
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 32),
      color: Colors.black,
      child: Column(
        children: [
          const Text(
            '— Akhir chapter —',
            style: TextStyle(color: Colors.white38, fontSize: 12),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              if (prev != null)
                Expanded(
                  child: Material(
                    color: Colors.white.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(14),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(14),
                      onTap: () => _goChapter(prev),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                            vertical: 14, horizontal: 12),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Icon(Icons.chevron_left_rounded,
                                color: Color(0xFFFFD88A), size: 22),
                            const SizedBox(width: 4),
                            Flexible(
                              child: Text(
                                prev.label,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 13,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                )
              else
                const Expanded(child: SizedBox()),
              const SizedBox(width: 8),
              Material(
                color: const Color(0xFF3A2C46),
                borderRadius: BorderRadius.circular(14),
                child: InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: _openChapterList,
                  child: const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 11, vertical: 14),
                    child: Icon(Icons.list_rounded,
                        color: Color(0xFFFFD88A), size: 22),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              if (next != null)
                Expanded(
                  child: Material(
                    color: const Color(0xFFFFD88A),
                    borderRadius: BorderRadius.circular(14),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(14),
                      onTap: () => _goChapter(next),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                            vertical: 14, horizontal: 12),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Flexible(
                              child: Text(
                                next.label,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.right,
                                style: const TextStyle(
                                  color: Color(0xFF17121F),
                                  fontWeight: FontWeight.w800,
                                  fontSize: 13,
                                ),
                              ),
                            ),
                            const SizedBox(width: 4),
                            const Icon(Icons.chevron_right_rounded,
                                color: Color(0xFF17121F), size: 22),
                          ],
                        ),
                      ),
                    ),
                  ),
                )
              else
                const Expanded(child: SizedBox()),
            ],
          ),
        ],
      ),
    );
  }

  Widget _tapNavigationControls() {
    final prev = _prev;
    final next = _next;
    return SafeArea(
      minimum: const EdgeInsets.fromLTRB(12, 0, 12, 12),
      child: Row(
        children: [
          Expanded(
            child: Material(
              color: Colors.black.withOpacity(0.88),
              borderRadius: BorderRadius.circular(14),
              child: InkWell(
                borderRadius: BorderRadius.circular(14),
                onTap: prev == null ? null : () => _goChapter(prev),
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 13),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.chevron_left_rounded,
                          color: prev == null
                              ? Colors.white24
                              : const Color(0xFFFFD88A),
                          size: 23),
                      const SizedBox(width: 3),
                      Text('Mundur',
                          style: TextStyle(
                              color: prev == null ? Colors.white24 : Colors.white,
                              fontWeight: FontWeight.w800)),
                    ],
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),
          Material(
            color: const Color(0xFFFFD88A),
            borderRadius: BorderRadius.circular(14),
            child: InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: _openChapterList,
              child: const Padding(
                padding: EdgeInsets.symmetric(horizontal: 15, vertical: 13),
                child: Icon(Icons.list_rounded, color: Color(0xFF17121F), size: 23),
              ),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Material(
              color: const Color(0xFFFFD88A),
              borderRadius: BorderRadius.circular(14),
              child: InkWell(
                borderRadius: BorderRadius.circular(14),
                onTap: next == null ? null : () => _goChapter(next),
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 13),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text('Maju',
                          style: TextStyle(
                              color: next == null
                                  ? Colors.black26
                                  : const Color(0xFF17121F),
                              fontWeight: FontWeight.w800)),
                      const SizedBox(width: 3),
                      Icon(Icons.chevron_right_rounded,
                          color: next == null
                              ? Colors.black26
                              : const Color(0xFF17121F),
                          size: 23),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _commentsSection() {
    final childMap = _buildChildMap();
    final roots = _comments.where((c) => c.parentId == null || c.parentId!.isEmpty).toList();
    return Container(
      key: _commentsKey,
      width: double.infinity,
      color: const Color(0xFF17121F),
      padding: const EdgeInsets.fromLTRB(16, 18, 16, 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Text('Komentar', style: TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w800)),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(color: Colors.white.withOpacity(0.1), borderRadius: BorderRadius.circular(8)),
                child: Text(_comments.length.toString(),
                    style: const TextStyle(color: Color(0xFFFFD88A), fontSize: 12, fontWeight: FontWeight.w700)),
              ),
            ],
          ),
          const SizedBox(height: 4),
          const Text('Komentar di semua chapter komik ini',
              style: TextStyle(color: Colors.white54, fontSize: 12)),
          const SizedBox(height: 14),
          if (_commentsLoading)
            const Center(child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFFFFD88A)))
          else if (roots.isEmpty)
            const Text('Belum ada komentar. Jadilah yang pertama berkomentar.',
                style: TextStyle(color: Colors.white54, fontSize: 12))
          else
            ...roots.map((c) => _commentCard(c, childMap)),
        ],
      ),
    );
  }

  /// Composer (input + reply banner + sticker) yang selalu di bawah layar,
  /// otomatis naik di atas keyboard tanpa "menempel" aneh dari dalam ListView.
  Widget _commentComposer() {
    return Material(
      color: const Color(0xFF17121F),
      elevation: 12,
      child: SafeArea(
        top: false,
        child: Padding(
          padding: EdgeInsets.fromLTRB(
            12,
            8,
            12,
            8 + MediaQuery.of(context).viewInsets.bottom,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              if (_replyingToId != null) _replyBanner(),
              if (_pendingStickerId != null) _pendingStickerBanner(),
              Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Material(
                    color: Colors.white.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(14),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(14),
                      onTap: _toggleStickerTray,
                      child: Padding(
                        padding: const EdgeInsets.all(13),
                        child: Icon(
                          _stickerTrayOpen
                              ? Icons.emoji_emotions_rounded
                              : Icons.add_reaction_outlined,
                          color: _stickerTrayOpen
                              ? const Color(0xFFFFD88A)
                              : Colors.white70,
                          size: 22,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: TextField(
                      controller: _commentController,
                      focusNode: _commentFocus,
                      minLines: 1,
                      maxLines: 4,
                      textInputAction: TextInputAction.newline,
                      style: const TextStyle(color: Colors.white, fontSize: 13),
                      decoration: InputDecoration(
                        hintText: _replyingToId != null
                            ? 'Tulis balasan (opsional)...'
                            : (_pendingStickerId != null
                                ? 'Tambah caption (opsional)...'
                                : 'Tulis komentar...'),
                        hintStyle: const TextStyle(color: Colors.white54, fontSize: 12),
                        filled: true,
                        fillColor: Colors.white.withOpacity(0.1),
                        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(14),
                            borderSide: BorderSide.none),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Material(
                    color: const Color(0xFFFFD88A),
                    borderRadius: BorderRadius.circular(14),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(14),
                      onTap: _commentSending ? null : _sendComment,
                      child: Padding(
                        padding: const EdgeInsets.all(15),
                        child: _commentSending
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(
                                    strokeWidth: 2, color: Color(0xFF17121F)))
                            : const Icon(Icons.send_rounded,
                                color: Color(0xFF17121F), size: 20),
                      ),
                    ),
                  ),
                ],
              ),
              if (_stickerTrayOpen) _stickerTray(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _replyBanner() {
    final parent = _comments.firstWhere(
      (e) => e.id == _replyingToId,
      orElse: () => const MangaComment(
        chapter: '', username: '', avatarAsset: 'assets/images/default_avatar.jpg', text: '', createdAt: '',
      ),
    );
    final username = parent.username.isEmpty ? '' : ' ke @${parent.username}';
    final preview = parent.displayText.isEmpty ? '(stiker)' : parent.displayText;
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.fromLTRB(10, 8, 6, 8),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.08),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: const Color(0xFFFFD88A).withOpacity(0.35)),
      ),
      child: Row(
        children: [
          const Icon(Icons.reply_rounded, color: Color(0xFFFFD88A), size: 16),
          const SizedBox(width: 6),
          Expanded(
            child: Text('Membalas$username: $preview',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: Colors.white70, fontSize: 12)),
          ),
          IconButton(
            icon: const Icon(Icons.close_rounded, color: Colors.white54, size: 18),
            onPressed: _cancelReply,
            padding: EdgeInsets.zero,
            constraints: const BoxConstraints(minHeight: 28, minWidth: 28),
            visualDensity: VisualDensity.compact,
          ),
        ],
      ),
    );
  }

  Widget _pendingStickerBanner() {
    final s = BuiltInStickers.byId(_pendingStickerId!);
    if (s == null) return const SizedBox.shrink();
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.fromLTRB(8, 6, 6, 6),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.08),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: Image.asset(s.asset, height: 36, width: 36, fit: BoxFit.cover),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text('Stiker: ${s.label}',
                maxLines: 1, overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: Colors.white70, fontSize: 12)),
          ),
          IconButton(
            icon: const Icon(Icons.close_rounded, color: Colors.white54, size: 18),
            onPressed: () => setState(() => _pendingStickerId = null),
            padding: EdgeInsets.zero,
            constraints: const BoxConstraints(minHeight: 28, minWidth: 28),
            visualDensity: VisualDensity.compact,
          ),
        ],
      ),
    );
  }

  Widget _stickerTray() {
    final builtin = BuiltInStickers.items;
    return Container(
      margin: const EdgeInsets.only(top: 10),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.06),
        borderRadius: BorderRadius.circular(14),
      ),
      padding: const EdgeInsets.fromLTRB(8, 8, 8, 6),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              _stickerTabButton(0, 'Bawaan', builtin.length.toString()),
              const SizedBox(width: 6),
              _stickerTabButton(1, 'Stiker Saya', _customStickerPaths.length.toString()),
              const Spacer(),
              _addStickerButton(),
            ],
          ),
          const SizedBox(height: 8),
          SizedBox(
            height: 220,
            child: _stickerTab == 0
                ? GridView.builder(
                    padding: const EdgeInsets.only(bottom: 4),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 4,
                      mainAxisSpacing: 8,
                      crossAxisSpacing: 8,
                      childAspectRatio: 1,
                    ),
                    itemCount: builtin.length,
                    itemBuilder: (_, i) {
                      final s = builtin[i];
                      final selected = _pendingStickerId == s.id;
                      return _stickerTile(
                        asset: s.asset,
                        label: '',
                        selected: selected,
                        onTap: () => _selectBuiltInSticker(s),
                      );
                    },
                  )
                : _customStickerPaths.isEmpty
                    ? const _StickerPlaceholder()
                    : GridView.builder(
                        padding: const EdgeInsets.only(bottom: 4),
                        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 4,
                          mainAxisSpacing: 8,
                          crossAxisSpacing: 8,
                          childAspectRatio: 1,
                        ),
                        itemCount: _customStickerPaths.length,
                        itemBuilder: (_, i) {
                          final path = _customStickerPaths[i];
                          return _stickerTile(
                            asset: path,
                            label: '',
                            selected: false,
                            isNetworkOrFile: true,
                            onTap: () => _sendCustomSticker(path),
                            onLongPress: () async {
                              await CustomStickerStore.removePath(_currentUsername, path);
                              final list = await CustomStickerStore.listPaths(_currentUsername);
                              if (!mounted) return;
                              setState(() => _customStickerPaths = list);
                            },
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }

  Widget _stickerTabButton(int idx, String label, String count) {
    final active = _stickerTab == idx;
    return Material(
      color: active ? const Color(0xFFFFD88A) : Colors.white.withOpacity(0.1),
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: () => setState(() => _stickerTab = idx),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          child: Text(
            '$label · $count',
            style: TextStyle(
              color: active ? const Color(0xFF17121F) : Colors.white70,
              fontSize: 11,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
      ),
    );
  }

  Widget _addStickerButton() {
    return Material(
      color: Colors.white.withOpacity(0.1),
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: () => _showAddCustomStickerSheet(),
        child: const Padding(
          padding: EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.add_rounded, color: Color(0xFFFFD88A), size: 16),
              SizedBox(width: 4),
              Text('Tambah',
                  style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700)),
            ],
          ),
        ),
      ),
    );
  }

  void _showAddCustomStickerSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1F1929),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Tambah stiker sendiri',
                  style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 16)),
              const SizedBox(height: 6),
              const Text(
                'Pilih cara menambahkan stiker. Stiker akan tersimpan untuk akunmu dan dapat dipakai di komentar semua komik.',
                style: TextStyle(color: Colors.white60, fontSize: 12),
              ),
              const SizedBox(height: 14),
              ListTile(
                leading: const Icon(Icons.image_rounded, color: Color(0xFFFFD88A)),
                title: const Text('Pilih dari galeri',
                    style: TextStyle(color: Colors.white)),
                subtitle: const Text('Upload gambar dari HP kamu',
                    style: TextStyle(color: Colors.white54, fontSize: 12)),
                onTap: () async {
                  Navigator.pop(ctx);
                  await _pickAndAddCustomSticker();
                },
              ),
              ListTile(
                leading: const Icon(Icons.text_fields_rounded, color: Color(0xFFFFD88A)),
                title: const Text('Buat stiker teks cepat',
                    style: TextStyle(color: Colors.white)),
                subtitle: const Text('Buat stiker dari teks you sendiri',
                    style: TextStyle(color: Colors.white54, fontSize: 12)),
                onTap: () async {
                  Navigator.pop(ctx);
                  await _createTextSticker();
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Pilih gambar dari galeri lalu simpan ke folder stiker custom user.
  Future<void> _pickAndAddCustomSticker() async {
    try {
      final dest = await _ImagePickerFacade.pickAndSave(_currentUsername);
      if (dest == null) return;
      final paths = await CustomStickerStore.listPaths(_currentUsername);
      if (!mounted) return;
      setState(() => _customStickerPaths = paths);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Gagal menambah stiker: $e'),
          backgroundColor: Colors.redAccent,
          duration: const Duration(seconds: 2),
        ),
      );
    }
  }

  /// Render teks jadi PNG dan simpan sebagai stiker custom.
  /// Kita pakai painter sederhana agar tidak butuh dependency tambahan.
  Future<void> _createTextSticker() async {
    final ctrl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1F1929),
        title: const Text('Teks stiker',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
        content: TextField(
          controller: ctrl,
          maxLength: 40,
          style: const TextStyle(color: Colors.white),
          decoration: const InputDecoration(
            hintText: 'mis. CAPEK BANG',
            hintStyle: TextStyle(color: Colors.white54),
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Batal',
                  style: TextStyle(color: Colors.white70))),
          TextButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Buat',
                  style: TextStyle(color: Color(0xFFFFD88A)))),
        ],
      ),
    );
    if (ok != true || ctrl.text.trim().isEmpty) return;
    final text = ctrl.text.trim();
    await CustomStickerStore.addPath(_currentUsername, 'sticker:text:$text');
    final paths = await CustomStickerStore.listPaths(_currentUsername);
    if (!mounted) return;
    setState(() => _customStickerPaths = paths);
  }

  Widget _stickerTile({
    required String asset,
    required String label,
    required bool selected,
    required VoidCallback onTap,
    bool isNetworkOrFile = false,
    VoidCallback? onLongPress,
  }) {
    final tile = Container(
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.08),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
            color: selected ? const Color(0xFFFFD88A) : Colors.white.withOpacity(0.12),
            width: selected ? 1.5 : 1),
      ),
      padding: const EdgeInsets.all(4),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: _stickerTileImage(asset, isNetworkOrFile),
      ),
    );
    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: onTap,
      onLongPress: onLongPress,
      child: tile,
    );
  }

  Widget _stickerTileImage(String asset, bool isNetworkOrFile) {
    // Custom stiker teks: render teks dengan TextPainter jadi widget.
    if (asset.startsWith('sticker:text:')) {
      final text = asset.substring('sticker:text:'.length);
      return Container(
        color: const Color(0xFFFFD88A),
        alignment: Alignment.center,
        padding: const EdgeInsets.all(4),
        child: Text(
          text,
          textAlign: TextAlign.center,
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(
              color: Color(0xFF17121F),
              fontSize: 12,
              fontWeight: FontWeight.w900,
              height: 1.05),
        ),
      );
    }
    if (isNetworkOrFile) {
      return Image.file(
        File(asset),
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => const Icon(Icons.broken_image_rounded,
            color: Colors.white54, size: 26),
      );
    }
    return Image.asset(
      asset,
      fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => const Icon(Icons.broken_image_rounded,
          color: Colors.white54, size: 26),
    );
  }

  Widget _commentCard(MangaComment c, Map<String, List<MangaComment>> childMap) {
    final replies = childMap[c.id] ?? const [];
    final isReplying = _replyingToId == c.id;
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.07),
        borderRadius: BorderRadius.circular(12),
        border: isReplying
            ? Border.all(color: const Color(0xFFFFD88A).withOpacity(0.6))
            : null,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.fromLTRB(12, 10, 8, 10),
            child: _commentBody(c, isRoot: true),
          ),
          if (replies.isNotEmpty)
            Padding(
              padding: const EdgeInsets.fromLTRB(4, 0, 4, 4),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: replies
                    .map((r) => Container(
                          margin: const EdgeInsets.only(left: 26, top: 4, right: 4, bottom: 4),
                          padding: const EdgeInsets.fromLTRB(10, 8, 8, 8),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.05),
                            borderRadius: BorderRadius.circular(10),
                            border: Border(
                              left: BorderSide(
                                color: const Color(0xFFFFD88A).withOpacity(0.5),
                                width: 2,
                              ),
                            ),
                          ),
                          child: _commentBody(r, isRoot: false),
                        ))
                    .toList(),
              ),
            ),
        ],
      ),
    );
  }

  Widget _commentBody(MangaComment c, {required bool isRoot}) {
    // Pakai avatar terbaru untuk komentar milik sendiri
    final avatarPath = _avatarForComment(c);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            ProfileAvatar(
              key: ValueKey('avatar_${c.id}_$avatarPath'),
              path: avatarPath,
              radius: isRoot ? 15 : 13,
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Text(c.username,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                      color: Color(0xFFFFD88A),
                      fontWeight: FontWeight.w800,
                      fontSize: 13)),
            ),
            Text(
              _chapterTagFor(c),
              style: const TextStyle(color: Colors.white38, fontSize: 10),
            ),
            const SizedBox(width: 8),
            Text(
              _ago(c.createdAt),
              style: const TextStyle(color: Colors.white38, fontSize: 10),
            ),
            IconButton(
              icon: const Icon(Icons.more_vert_rounded,
                  color: Colors.white54, size: 18),
              onPressed: () => _commentMenu(c),
              padding: EdgeInsets.zero,
              constraints: const BoxConstraints(minHeight: 28, minWidth: 28),
              visualDensity: VisualDensity.compact,
              tooltip: 'Opsi komentar',
            ),
          ],
        ),
        const SizedBox(height: 5),
        // Caption teks di ATAS stiker (bold). Kalau tanpa stiker, tetap teks biasa bold.
        if (c.text.trim().isNotEmpty)
          Padding(
            padding: EdgeInsets.only(
              bottom: (c.stickerId != null && c.stickerId!.isNotEmpty) ||
                      (c.localStickerPath != null && c.localStickerPath!.isNotEmpty)
                  ? 6
                  : 0,
            ),
            child: Text(
              c.text,
              style: TextStyle(
                color: Colors.white,
                fontSize: 13,
                height: 1.35,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        _renderCommentMedia(c),
        if (isRoot && (c.parentId == null))
          Padding(
            // Geser sedikit ke kiri agar tidak bertumpuk dengan tombol panah
            // naik/turun di kanan bawah layar.
            padding: const EdgeInsets.only(right: 56),
            child: Row(
              children: [
                if ((childMapOfRoot(c)) > 0)
                  TextButton.icon(
                    style: TextButton.styleFrom(
                      padding: const EdgeInsets.symmetric(horizontal: 6),
                      minimumSize: const Size(0, 28),
                      tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      foregroundColor: const Color(0xFFFFD88A),
                    ),
                    onPressed: () {},
                    icon: const Icon(Icons.forum_rounded, size: 14),
                    label: Text('${childMapOfRoot(c)} balasan',
                        style: const TextStyle(fontSize: 11)),
                  ),
                const Spacer(),
                TextButton.icon(
                  style: TextButton.styleFrom(
                    padding: const EdgeInsets.symmetric(horizontal: 6),
                    minimumSize: const Size(0, 28),
                    tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    foregroundColor: Colors.white70,
                  ),
                  onPressed: () => _toggleReply(c),
                  icon: const Icon(Icons.reply_rounded,
                      size: 14, color: Color(0xFFFFD88A)),
                  label: const Text('Balas', style: TextStyle(fontSize: 11)),
                ),
              ],
            ),
          ),
      ],
    );
  }

  int childMapOfRoot(MangaComment c) {
    return _comments.where((x) => x.parentId == c.id).length;
  }

  Widget _renderCommentMedia(MangaComment c) {
    // Stiker custom dari server (gambar) — dibaca semua user.
    final su = c.stickerUrl;
    if (su != null && su.isNotEmpty) {
      return Padding(
        padding: const EdgeInsets.only(bottom: 6),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxHeight: 160, maxWidth: 180),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: Image.network(su, fit: BoxFit.contain,
                errorBuilder: (_, __, ___) => const Icon(
                    Icons.broken_image_rounded, color: Colors.white54)),
          ),
        ),
      );
    }
    // Stiker teks dari server (tubuh teksnya disimpan sebagai teks).
    final st = c.stickerText;
    if (st != null && st.isNotEmpty && (c.localStickerPath ?? '').isEmpty) {
      return _textStickerBubble(st);
    }
    final builtin = c.stickerId != null ? BuiltInStickers.byId(c.stickerId!) : null;
    if (builtin != null) {
      return Padding(
        padding: const EdgeInsets.only(bottom: 6),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxHeight: 160, maxWidth: 180),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: Image.asset(builtin.asset, fit: BoxFit.contain),
          ),
        ),
      );
    }
    final lp = c.localStickerPath;
    if (lp != null && lp.isNotEmpty) {
      if (lp.startsWith('sticker:text:')) {
        return _textStickerBubble(lp.substring('sticker:text:'.length));
      }
      return Padding(
        padding: const EdgeInsets.only(bottom: 6),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxHeight: 160, maxWidth: 180),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: Image.file(File(lp), fit: BoxFit.contain,
                errorBuilder: (_, __, ___) => const Icon(Icons.broken_image_rounded,
                    color: Colors.white54)),
          ),
        ),
      );
    }
    return const SizedBox.shrink();
  }

  /// Bubble stiker teks (dipakai stiker lokal maupun yang datang dari server).
  Widget _textStickerBubble(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        decoration: BoxDecoration(
          color: const Color(0xFFFFD88A),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Text(text,
            style: const TextStyle(
                color: Color(0xFF17121F),
                fontWeight: FontWeight.w900,
                fontSize: 14,
                height: 1.1)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      // Jangan resize body (gambar manga tidak loncat). Composer yang naik di atas keyboard.
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        backgroundColor: Colors.black87,
        foregroundColor: Colors.white,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (widget.mangaTitle.isNotEmpty)
              Text(
                widget.mangaTitle,
                style: const TextStyle(fontSize: 12, color: Colors.white54),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            Text(widget.chapterTitle,
                style:
                    const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
          ],
        ),
        elevation: 0,
      ),
      body: _loading
          ? const Center(
              child: CircularProgressIndicator(color: Color(0xFFFFD88A)))
          : _error != null
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(_error!,
                            style: const TextStyle(color: Colors.white70),
                            textAlign: TextAlign.center),
                        const SizedBox(height: 16),
                        TextButton(
                          onPressed: _load,
                          style: TextButton.styleFrom(
                              foregroundColor: const Color(0xFFFFD88A)),
                          child: const Text('Coba lagi'),
                        ),
                      ],
                    ),
                  ),
                )
              : _images.isEmpty
                  ? const Center(
                      child: Text('Tidak ada gambar',
                          style: TextStyle(color: Colors.white54)))
                  : Column(
                      children: [
                        Expanded(
                          child: Stack(
                            children: [
                              GestureDetector(
                                behavior: HitTestBehavior.translucent,
                                // GestureDetector hanya memanggil onTap jika gesture
                                // selesai sebagai tap; drag untuk scroll tidak memicu ini.
                                onTap: () => setState(
                                    () => _controlsVisible = !_controlsVisible),
                                child: ListView.builder(
                                  controller: _scrollController,
                                  physics: const ClampingScrollPhysics(
                                    parent: AlwaysScrollableScrollPhysics(),
                                  ),
                                  cacheExtent: 2500,
                                  addRepaintBoundaries: true,
                                  itemCount: _images.length + 1,
                                  itemBuilder: (context, i) {
                                    if (i == _images.length) {
                                      return Column(
                                        children: [
                                          _navButtons(),
                                          _commentsSection(),
                                        ],
                                      );
                                    }
                                    final page = _ReaderPageImage(
                                      key: _pageKeys.putIfAbsent(
                                          i, GlobalKey.new),
                                      url: _images[i],
                                      index: i,
                                      loadEnabled: i <= _loadUntil,
                                      onReady: _onPageReady,
                                    );
                                    if (i == _resumeIndex &&
                                        _resumeIndex > 0) {
                                      return KeyedSubtree(
                                          key: _resumeKey, child: page);
                                    }
                                    return page;
                                  },
                                ),
                              ),
                              // Sembunyikan Mundur/Maju/list jika sudah di bawah
                              // (dekat komentar) supaya tidak dobel & nutup komentar.
                              if (_controlsVisible && !_nearBottom)
                                Positioned(
                                  left: 0,
                                  right: 0,
                                  bottom: 0,
                                  child: _tapNavigationControls(),
                                ),
                              // Tombol loncat: bawah → komentar, atas → awal chapter
                              Positioned(
                                right: 12,
                                bottom: 16,
                                child: _scrollJumpButton(),
                              ),
                            ],
                          ),
                        ),
                        // Input komentar selalu di bawah, naik rapi di atas keyboard.
                        _commentComposer(),
                      ],
                    ),
    );
  }
}

/// Satu halaman gambar — load hanya jika giliran (berurutan)
class _ReaderPageImage extends StatefulWidget {
  const _ReaderPageImage({
    super.key,
    required this.url,
    required this.index,
    required this.loadEnabled,
    required this.onReady,
  });

  final String url;
  final int index;
  final bool loadEnabled;
  final void Function(int index) onReady;

  @override
  State<_ReaderPageImage> createState() => _ReaderPageImageState();
}

class _ReaderPageImageState extends State<_ReaderPageImage> {
  static const _headers = {
    'User-Agent':
        'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36',
    'Referer': 'https://komiku.org/',
    'Accept': 'image/webp,image/apng,image/*,*/*;q=0.8',
  };

  late String _currentUrl;
  String? _fallbackUrl;
  int _retry = 0;
  bool _failed = false;
  bool _reported = false;

  @override
  void initState() {
    super.initState();
    _parseUrl(widget.url);
  }

  @override
  void didUpdateWidget(covariant _ReaderPageImage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.url != widget.url) {
      _retry = 0;
      _failed = false;
      _reported = false;
      _parseUrl(widget.url);
    }
  }

  void _parseUrl(String raw) {
    final hash = raw.indexOf('#fb=');
    if (hash > 0) {
      _currentUrl = raw.substring(0, hash);
      _fallbackUrl = Uri.decodeComponent(raw.substring(hash + 4));
    } else {
      _currentUrl = raw;
      _fallbackUrl = null;
    }
  }

  void _markReady() {
    if (_reported) return;
    _reported = true;
    widget.onReady(widget.index);
  }

  void _onError() {
    if (!mounted) return;
    if (_retry == 0 && _fallbackUrl != null && _fallbackUrl != _currentUrl) {
      setState(() {
        _retry = 1;
        _currentUrl = _fallbackUrl!;
        _failed = false;
      });
      return;
    }
    if (_retry < 3) {
      final next = _swapHost(_currentUrl, _retry);
      if (next != null && next != _currentUrl) {
        setState(() {
          _retry++;
          _currentUrl = next;
          _failed = false;
        });
        return;
      }
    }
    // gagal total — tetap anggap "ready" supaya antrian load tidak macet
    setState(() => _failed = true);
    _markReady();
  }

  String? _swapHost(String url, int attempt) {
    const hosts = [
      'image2.komiku.to',
      'img.komiku.org',
      'cdn.komiku.org',
      'thumbnail.komiku.to',
    ];
    for (final h in hosts) {
      if (url.contains(h)) {
        final idx = (hosts.indexOf(h) + 1 + attempt) % hosts.length;
        final alt = hosts[idx];
        if (alt != h) return url.replaceFirst(h, alt);
      }
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    // Belum giliran — placeholder, jangan download
    if (!widget.loadEnabled) {
      return const SizedBox(
        height: 280,
        width: double.infinity,
        child: Center(
          child: Text(
            'Menunggu giliran…',
            style: TextStyle(color: Colors.white24, fontSize: 12),
          ),
        ),
      );
    }

    if (_failed) {
      return Container(
        height: 120,
        color: Colors.white10,
        alignment: Alignment.center,
        child: TextButton.icon(
          onPressed: () {
            setState(() {
              _failed = false;
              _retry = 0;
              _reported = false;
              _parseUrl(widget.url);
            });
          },
          icon: const Icon(Icons.refresh_rounded, color: Color(0xFFFFD88A)),
          label: const Text('Muat ulang',
              style: TextStyle(color: Color(0xFFFFD88A))),
        ),
      );
    }

    return Image.network(
      _currentUrl,
      fit: BoxFit.fitWidth,
      width: double.infinity,
      gaplessPlayback: true,
      filterQuality: FilterQuality.medium,
      headers: _headers,
      frameBuilder: (context, child, frame, wasSync) {
        if (wasSync || frame != null) {
          WidgetsBinding.instance.addPostFrameCallback((_) => _markReady());
          return child;
        }
        return const SizedBox(
          height: 320,
          width: double.infinity,
          child: Center(
            child: SizedBox(
              width: 28,
              height: 28,
              child: CircularProgressIndicator(
                color: Color(0xFFFFD88A),
                strokeWidth: 2,
              ),
            ),
          ),
        );
      },
      loadingBuilder: (context, child, progress) {
        if (progress == null) return child;
        return SizedBox(
          height: 320,
          width: double.infinity,
          child: Center(
            child: SizedBox(
              width: 28,
              height: 28,
              child: CircularProgressIndicator(
                color: const Color(0xFFFFD88A),
                strokeWidth: 2,
                value: progress.expectedTotalBytes != null
                    ? progress.cumulativeBytesLoaded /
                        progress.expectedTotalBytes!
                    : null,
              ),
            ),
          ),
        );
      },
      errorBuilder: (_, __, ___) {
        WidgetsBinding.instance.addPostFrameCallback((_) => _onError());
        return const SizedBox(
          height: 160,
          width: double.infinity,
          child: Center(
            child: SizedBox(
              width: 24,
              height: 24,
              child: CircularProgressIndicator(
                color: Color(0xFFFFD88A),
                strokeWidth: 2,
              ),
            ),
          ),
        );
      },
    );
  }
}

/// Loading spinner + teks "tunggu ya." dengan titik animasi (. .. ... .... ..... → ulang)
class _TungguYaLoading extends StatefulWidget {
  const _TungguYaLoading();

  @override
  State<_TungguYaLoading> createState() => _TungguYaLoadingState();
}

class _TungguYaLoadingState extends State<_TungguYaLoading> {
  int _dots = 1;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(milliseconds: 420), (_) {
      if (!mounted) return;
      setState(() => _dots = _dots >= 5 ? 1 : _dots + 1);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        const CircularProgressIndicator(color: Color(0xFFFFD88A)),
        const SizedBox(height: 16),
        Text(
          'tunggu ya${'.' * _dots}',
          style: const TextStyle(
            color: Colors.white70,
            fontSize: 14,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }
}
