import 'dart:io';
import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

/// Layar pangkas foto profil: pinch zoom + geser, hasil kotak 1:1.
class AvatarCropPage extends StatefulWidget {
  const AvatarCropPage({super.key, required this.sourcePath});

  final String sourcePath;

  @override
  State<AvatarCropPage> createState() => _AvatarCropPageState();
}

class _AvatarCropPageState extends State<AvatarCropPage> {
  final TransformationController _transform = TransformationController();
  final GlobalKey _viewportKey = GlobalKey();
  ui.Image? _image;
  bool _loading = true;
  bool _saving = false;
  String? _error;
  double _scale = 1.0;

  @override
  void initState() {
    super.initState();
    _loadImage();
  }

  @override
  void dispose() {
    _transform.dispose();
    _image?.dispose();
    super.dispose();
  }

  Future<void> _loadImage() async {
    try {
      final bytes = await File(widget.sourcePath).readAsBytes();
      final codec = await ui.instantiateImageCodec(bytes);
      final frame = await codec.getNextFrame();
      if (!mounted) return;
      setState(() {
        _image = frame.image;
        _loading = false;
      });
      // Fit awal: cover crop box
      WidgetsBinding.instance.addPostFrameCallback((_) => _fitInitial());
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = 'Gagal memuat foto';
      });
    }
  }

  void _fitInitial() {
    final img = _image;
    final box = _viewportKey.currentContext?.findRenderObject() as RenderBox?;
    if (img == null || box == null || !box.hasSize) return;
    final side = math.min(box.size.width, box.size.height);
    if (side <= 0) return;
    final scale = math.max(side / img.width, side / img.height);
    final dx = (box.size.width - img.width * scale) / 2;
    final dy = (box.size.height - img.height * scale) / 2;
    _transform.value = Matrix4.identity()
      ..translate(dx, dy)
      ..scale(scale);
    _scale = scale;
    setState(() {});
  }

  Future<void> _save() async {
    final img = _image;
    final box = _viewportKey.currentContext?.findRenderObject() as RenderBox?;
    if (img == null || box == null || !box.hasSize) return;
    setState(() => _saving = true);
    try {
      final size = box.size;
      // Samakan dengan lingkaran overlay (86% sisi terpendek)
      final side = math.min(size.width, size.height) * 0.86;
      final cropLeft = (size.width - side) / 2;
      final cropTop = (size.height - side) / 2;

      // Matrix: viewport → image pixel
      final inv = Matrix4.inverted(_transform.value);
      Offset mapPoint(double x, double y) {
        final s = inv.storage;
        final rx = s[0] * x + s[4] * y + s[12];
        final ry = s[1] * x + s[5] * y + s[13];
        final rw = s[3] * x + s[7] * y + s[15];
        if (rw == 0) return Offset(rx, ry);
        return Offset(rx / rw, ry / rw);
      }

      final tl = mapPoint(cropLeft, cropTop);
      final br = mapPoint(cropLeft + side, cropTop + side);
      var srcRect = Rect.fromPoints(tl, br);
      // Clamp ke batas gambar
      srcRect = Rect.fromLTRB(
        srcRect.left.clamp(0, img.width.toDouble()),
        srcRect.top.clamp(0, img.height.toDouble()),
        srcRect.right.clamp(0, img.width.toDouble()),
        srcRect.bottom.clamp(0, img.height.toDouble()),
      );
      if (srcRect.width < 2 || srcRect.height < 2) {
        throw Exception('Area crop terlalu kecil, perbesar dulu');
      }

      const outSize = 1024;
      final recorder = ui.PictureRecorder();
      final canvas = Canvas(recorder);
      final paint = Paint()..filterQuality = FilterQuality.high;
      // Background gelap
      canvas.drawRect(
        const Rect.fromLTWH(0, 0, 1024, 1024),
        Paint()..color = const Color(0xFF17121F),
      );
      canvas.drawImageRect(
        img,
        srcRect,
        const Rect.fromLTWH(0, 0, 1024, 1024),
        paint,
      );
      final picture = recorder.endRecording();
      final out = await picture.toImage(outSize, outSize);
      final bd = await out.toByteData(format: ui.ImageByteFormat.png);
      out.dispose();
      if (bd == null) throw Exception('Gagal memproses foto');

      final dir = Directory(widget.sourcePath).parent;
      final path =
          '${dir.path}/avatar_crop_${DateTime.now().millisecondsSinceEpoch}.png';
      await File(path).writeAsBytes(bd.buffer.asUint8List(), flush: true);

      if (!mounted) return;
      Navigator.of(context).pop(path);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))),
      );
      setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: const Text('Pangkas foto profil',
            style: TextStyle(fontWeight: FontWeight.w800)),
        actions: [
          TextButton(
            onPressed: _saving || _loading ? null : _save,
            child: _saving
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(
                        strokeWidth: 2, color: Color(0xFFFFD88A)),
                  )
                : const Text('Simpan',
                    style: TextStyle(
                        color: Color(0xFFFFD88A), fontWeight: FontWeight.w800)),
          ),
        ],
      ),
      body: _loading
          ? const Center(
              child: CircularProgressIndicator(color: Color(0xFFFFD88A)))
          : _error != null
              ? Center(
                  child: Text(_error!,
                      style: const TextStyle(color: Colors.white70)))
              : Column(
                  children: [
                    Expanded(
                      child: Stack(
                        fit: StackFit.expand,
                        children: [
                          // Area interaktif
                          KeyedSubtree(
                            key: _viewportKey,
                            child: InteractiveViewer(
                              transformationController: _transform,
                              minScale: 0.2,
                              maxScale: 8,
                              boundaryMargin: const EdgeInsets.all(300),
                              constrained: false,
                              child: SizedBox(
                                width: _image!.width.toDouble(),
                                height: _image!.height.toDouble(),
                                child: RawImage(
                                  image: _image,
                                  fit: BoxFit.fill,
                                  filterQuality: FilterQuality.high,
                                ),
                              ),
                            ),
                          ),
                          // Overlay gelap + lingkaran crop (abaikan gesture)
                          IgnorePointer(
                            child: CustomPaint(
                              painter: _CropOverlayPainter(),
                              child: const SizedBox.expand(),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      color: const Color(0xFF17121F),
                      padding: const EdgeInsets.fromLTRB(16, 12, 16, 20),
                      child: Column(
                        children: [
                          const Text(
                            'Cubit untuk perbesar/perkecil · geser untuk atur posisi\n'
                            'Cocok untuk foto 9:16, 16:9, atau apa saja',
                            textAlign: TextAlign.center,
                            style:
                                TextStyle(color: Colors.white54, fontSize: 12),
                          ),
                          const SizedBox(height: 14),
                          SizedBox(
                            width: double.infinity,
                            height: 48,
                            child: ElevatedButton(
                              onPressed: _saving || _loading ? null : _save,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFFFFD88A),
                                foregroundColor: const Color(0xFF17121F),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12)),
                              ),
                              child: Text(
                                _saving ? 'Menyimpan...' : 'Simpan hasil pangkas',
                                style: const TextStyle(
                                    fontWeight: FontWeight.w800),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
    );
  }
}

class _CropOverlayPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final side = math.min(size.width, size.height) * 0.86;
    final rect = Rect.fromCenter(
      center: size.center(Offset.zero),
      width: side,
      height: side,
    );
    final path = Path()
      ..addRect(Rect.fromLTWH(0, 0, size.width, size.height))
      ..addOval(rect)
      ..fillType = PathFillType.evenOdd;
    canvas.drawPath(path, Paint()..color = Colors.black.withOpacity(0.55));
    canvas.drawOval(
      rect,
      Paint()
        ..color = const Color(0xFFFFD88A)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.5,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
