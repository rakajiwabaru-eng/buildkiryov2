import 'dart:io';

import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'app_errors.dart';
import 'app_paths.dart';
import 'local_library.dart';

typedef DownloadProgressCallback = void Function(int percent);

class DirectDownloadResult {
  const DirectDownloadResult({required this.file, required this.bytes});
  final File file;
  final int bytes;
}

/// Notifikasi unduhan — 1 channel saja agar progress bisa diganti jadi selesai
/// (penting di Xiaomi/MIUI yang sering nempel ongoing).
class _DownloadNotification {
  static final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();
  static bool _ready = false;
  static bool _initAttempted = false;

  // Satu channel untuk progress + selesai (v6)
  static const _channelId = 'kiryomanz_dl_v6';

  static Future<void> _clearBrokenCache() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      for (final k in prefs.getKeys().toList()) {
        final low = k.toLowerCase();
        if (low.contains('scheduled') ||
            low.contains('flutter_local_notifications') ||
            (low.contains('notification') && low.contains('dexterous'))) {
          await prefs.remove(k);
        }
      }
      await prefs.remove('scheduled_notifications');
    } catch (_) {}
  }

  static Future<void> _init() async {
    if (_ready || _initAttempted) return;
    _initAttempted = true;
    try {
      await _clearBrokenCache();
      const settings = InitializationSettings(
        android: AndroidInitializationSettings('@mipmap/ic_launcher'),
      );
      await _plugin.initialize(settings);
      final android = _plugin
          .resolvePlatformSpecificImplementation<
              AndroidFlutterLocalNotificationsPlugin>();
      try {
        await android?.requestNotificationsPermission();
      } catch (_) {}

      try {
        await android?.createNotificationChannel(
          const AndroidNotificationChannel(
            _channelId,
            'Download Kiryo Nime',
            description: 'Progress & selesai unduhan',
            importance: Importance.high,
            playSound: true,
            enableVibration: true,
            sound: RawResourceAndroidNotificationSound('download_done'),
            audioAttributesUsage: AudioAttributesUsage.notification,
          ),
        );
      } catch (_) {}

      _ready = true;
    } catch (_) {
      _ready = false;
    }
  }

  static Future<void> progress({
    required int id,
    required String title,
    required int percent,
    bool indeterminate = false,
    int receivedBytes = 0,
  }) async {
    try {
      await _init();
      if (!_ready) return;
      final p = percent.clamp(0, 99).toInt();
      final body = indeterminate
          ? 'Mengunduh... ${_fmtBytes(receivedBytes)}'
          : 'Mengunduh... $p%';
      await _plugin.show(
        id,
        title,
        body,
        NotificationDetails(
          android: AndroidNotificationDetails(
            _channelId,
            'Download Kiryo Nime',
            channelDescription: 'Progress & selesai unduhan',
            importance: Importance.low,
            priority: Priority.low,
            onlyAlertOnce: true,
            playSound: false,
            enableVibration: false,
            silent: true,
            showProgress: true,
            maxProgress: 100,
            progress: indeterminate ? 0 : p,
            indeterminate: indeterminate,
            ongoing: true,
            autoCancel: false,
          ),
        ),
      );
    } catch (_) {}
  }

  static Future<void> complete({
    required int id,
    required String title,
    required bool success,
  }) async {
    try {
      await _init();
      if (!_ready) return;

      // Ganti notif progress di ID + channel yang sama.
      // ongoing:false + showProgress:false → MIUI melepas bar stuck.
      await _plugin.show(
        id,
        title,
        success ? 'Download selesai ✓' : 'Download gagal',
        NotificationDetails(
          android: AndroidNotificationDetails(
            _channelId,
            'Download Kiryo Nime',
            channelDescription: 'Progress & selesai unduhan',
            importance: Importance.high,
            priority: Priority.high,
            playSound: success,
            enableVibration: success,
            silent: false,
            sound: success
                ? const RawResourceAndroidNotificationSound('download_done')
                : null,
            audioAttributesUsage: AudioAttributesUsage.notification,
            category: AndroidNotificationCategory.status,
            showProgress: false,
            maxProgress: 0,
            progress: 0,
            indeterminate: false,
            ongoing: false,
            autoCancel: true,
            onlyAlertOnce: false,
            // Paksa update visual
            channelShowBadge: true,
            visibility: NotificationVisibility.public,
          ),
        ),
      );
    } catch (_) {
      // Fallback tanpa custom sound
      try {
        await _plugin.show(
          id,
          title,
          success ? 'Download selesai ✓' : 'Download gagal',
          NotificationDetails(
            android: AndroidNotificationDetails(
              _channelId,
              'Download Kiryo Nime',
              importance: Importance.high,
              priority: Priority.high,
              playSound: success,
              enableVibration: success,
              showProgress: false,
              ongoing: false,
              autoCancel: true,
              audioAttributesUsage: AudioAttributesUsage.notification,
            ),
          ),
        );
      } catch (_) {}
    }
  }

  static String _fmtBytes(int n) {
    if (n < 1024) return '$n B';
    if (n < 1024 * 1024) return '${(n / 1024).toStringAsFixed(0)} KB';
    return '${(n / (1024 * 1024)).toStringAsFixed(1)} MB';
  }
}

/// Folder video offline:
/// /storage/emulated/0/Android/data/com.kiryomanz.app/files/assets/video/
Future<Directory> resolveOfflineMediaDir({String sub = 'anime'}) async {
  // sub diabaikan — semua video offline di assets/video
  return AppPaths.video();
}

Future<Directory> resolvePublicDownloadDir() async {
  try {
    return await DownloadFolderPref.resolve();
  } catch (_) {}
  const publicPath = '/storage/emulated/0/Download';
  final public = Directory(publicPath);
  try {
    if (!await public.exists()) {
      await public.create(recursive: true);
    }
    final probe = File('${public.path}/.kiryo_write_probe');
    await probe.writeAsString('ok', flush: true);
    await probe.delete();
    return public;
  } catch (e) {
    try {
      final dirs =
          await getExternalStorageDirectories(type: StorageDirectory.downloads);
      if (dirs != null && dirs.isNotEmpty) {
        final d = dirs.first;
        if (!await d.exists()) await d.create(recursive: true);
        return d;
      }
    } catch (_) {}
    final docs = await getApplicationDocumentsDirectory();
    final folder = Directory('${docs.path}/Download');
    if (!await folder.exists()) await folder.create(recursive: true);
    return folder;
  }
}

Future<DirectDownloadResult> saveRemoteFile({
  required String url,
  required String fileName,
  required String notificationTitle,
  DownloadProgressCallback? onProgress,
  Duration timeout = const Duration(minutes: 8),
  Map<String, String>? headers,
  bool notify = true,
  bool notifyOnFailure = true,
  /// Ukuran minimum file. Audio TikTok sering kurang dari 100 KB, jadi
  /// batas ini tidak boleh dipaksakan untuk semua jenis media.
  int minBytes = 8 * 1024,
  String referer = 'https://www.tiktok.com/',
  /// Jika diisi, file disimpan ke folder ini (mis. offline app).
  /// Null = folder Download publik (default lama).
  Directory? targetDir,
  /// true = unduh APK/file generik (lewati cek content-type HTML/video).
  bool allowAnyContent = false,
}) async {
  final uri = Uri.tryParse(url);
  if (uri == null || !uri.hasScheme) throw Exception('Link file tidak valid');

  final notificationId =
      DateTime.now().millisecondsSinceEpoch.remainder(100000);
  final client = http.Client();
  var lastPercent = -1;
  var lastBytesTick = 0;

  Future<void> report({
    required int percent,
    required int received,
    required bool indeterminate,
  }) async {
    try {
      onProgress?.call(percent.clamp(0, 100));
    } catch (_) {}
    final shouldUpdate = indeterminate
        ? (received - lastBytesTick >= 256 * 1024 || lastPercent < 0)
        : (percent != lastPercent);
    if (!shouldUpdate || percent >= 100) return;
    lastPercent = percent;
    lastBytesTick = received;
    if (!notify) return;
    try {
      await _DownloadNotification.progress(
        id: notificationId,
        title: notificationTitle,
        percent: percent,
        indeterminate: indeterminate,
        receivedBytes: received,
      );
    } catch (_) {}
  }

  try {
    await report(percent: 0, received: 0, indeterminate: true);

    final request = http.Request('GET', uri);
    request.followRedirects = true;
    request.headers['User-Agent'] =
        'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36';
    request.headers['Accept'] = '*/*';
    if (headers != null) {
      request.headers.addAll(headers);
    } else {
      request.headers['Referer'] = referer;
    }
    final response = await client.send(request).timeout(timeout);
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('File gagal diunduh (${response.statusCode})');
    }

    final ctype = (response.headers['content-type'] ?? '').toLowerCase();
    if (!allowAnyContent) {
      if (ctype.contains('text/html') ||
          ctype.contains('text/plain') ||
          ctype.contains('application/json') ||
          ctype.contains('application/javascript')) {
        throw Exception('Link bukan file video (dapat halaman web)');
      }
    }

    final folder = targetDir ?? await resolvePublicDownloadDir();
    if (!await folder.exists()) {
      await folder.create(recursive: true);
    }
    final safeName = fileName.replaceAll(RegExp(r'[^a-zA-Z0-9._-]+'), '_');
    final file = File('${folder.path}/$safeName');
    final sink = file.openWrite();
    final total = response.contentLength ?? 0;
    final indeterminate = total <= 0;
    var received = 0;
    final probe = <int>[];

    await for (final chunk in response.stream) {
      if (probe.length < 12) {
        final need = 12 - probe.length;
        probe.addAll(chunk.take(need));
        if (probe.length >= 5) {
          final head = String.fromCharCodes(probe.take(12)).toLowerCase();
          final isHtml = head.startsWith('<!doc') ||
              head.startsWith('<html') ||
              head.startsWith('<head') ||
              head.startsWith('{') ||
              head.startsWith('[');
          final isMp4 = probe.length >= 8 &&
              probe[4] == 0x66 &&
              probe[5] == 0x74 &&
              probe[6] == 0x79 &&
              probe[7] == 0x70;
          final isMkv = probe.length >= 4 &&
              probe[0] == 0x1A &&
              probe[1] == 0x45 &&
              probe[2] == 0xDF &&
              probe[3] == 0xA3;
          final looksVideo = isMp4 ||
              isMkv ||
              ctype.contains('video/') ||
              ctype.contains('octet-stream') ||
              ctype.contains('mpeg') ||
              ctype.contains('mp4') ||
              ctype.contains('matroska');
          if (!allowAnyContent && isHtml && !looksVideo) {
            await sink.close();
            try {
              await file.delete();
            } catch (_) {}
            throw Exception('Link bukan file video (konten tidak valid)');
          }
        }
      }
      sink.add(chunk);
      received += chunk.length;
      final percent =
          !indeterminate ? (received * 100 ~/ total).clamp(0, 99) : 0;
      await report(
        percent: percent,
        received: received,
        indeterminate: indeterminate,
      );
    }
    await sink.flush();
    await sink.close();
    if (received == 0) {
      try { await file.delete(); } catch (_) {}
      throw Exception('File kosong');
    }
    // Validasi ringan untuk menolak respons error kecil. Jangan memakai
    // batas 100 KB global karena audio TikTok yang valid bisa lebih kecil.
    if (received < minBytes) {
      try { await file.delete(); } catch (_) {}
      throw Exception('File terlalu kecil ($received byte) — konten tidak valid');
    }

    try {
      onProgress?.call(100);
    } catch (_) {}

    // Pastikan notif selesai selalu dipanggil (ganti progress stuck)
    if (notify) {
      await _DownloadNotification.complete(
        id: notificationId,
        title: notificationTitle,
        success: true,
      );
      // Sedikit jeda + panggil lagi untuk OEM yang lag update notif
      await Future<void>.delayed(const Duration(milliseconds: 200));
      await _DownloadNotification.complete(
        id: notificationId,
        title: notificationTitle,
        success: true,
      );
    }

    return DirectDownloadResult(file: file, bytes: received);
  } catch (e) {
    if (notify && notifyOnFailure) {
      await _DownloadNotification.complete(
        id: notificationId,
        title: notificationTitle,
        success: false,
      );
    }
    throw Exception(AppErrors.describe(e));
  } finally {
    client.close();
  }
}
