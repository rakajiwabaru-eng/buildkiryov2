import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import 'api_config.dart';
import 'local_library.dart';
import 'manga.dart' show MangaReadStore;
import 'session.dart';

/// Sinkron data user ke API base (bookmark, history, offline metadata).
class ApiSync {
  static Future<Map<String, String>> _headers() async {
    final token = await SessionStore.getToken();
    return {
      'Content-Type': 'application/json',
      if (token != null && token.isNotEmpty) 'Authorization': 'Bearer $token',
    };
  }

  static Future<void> pushBookmarks(List<LibraryEntry> items) async {
    try {
      final h = await _headers();
      await http
          .put(
            Uri.parse('$apiBaseUrl/api/me/bookmarks'),
            headers: h,
            body: jsonEncode({'data': items.map((e) => e.toJson()).toList()}),
          )
          .timeout(const Duration(seconds: 15));
    } catch (_) {}
  }

  static Future<List<LibraryEntry>> pullBookmarks() async {
    try {
      final h = await _headers();
      final res = await http
          .get(Uri.parse('$apiBaseUrl/api/me/bookmarks'), headers: h)
          .timeout(const Duration(seconds: 15));
      final body = jsonDecode(res.body);
      if (body is Map && body['ok'] == true && body['data'] is List) {
        return (body['data'] as List)
            .whereType<Map>()
            .map((e) => LibraryEntry.fromJson(Map<String, dynamic>.from(e)))
            .toList();
      }
    } catch (_) {}
    return [];
  }

  // -------------------------------------------------------------------------
  // Sinkron dua arah untuk store favorit komik (manga/manhua/manhwa).
  // BookmarkStore = tab Favorit; manga_favorites_v1 = halaman Bookmark komik
  // + deteksi chapter baru. Keduanya harus ikut dipulihkan dari cloud.
  // -------------------------------------------------------------------------

  static const _mangaFavKey = 'manga_favorites_v1';

  static List<LibraryEntry> _favToEntries(List<dynamic> favs) {
    final out = <LibraryEntry>[];
    for (final f in favs) {
      if (f is! Map) continue;
      final slug = '${f['slug'] ?? ''}';
      if (slug.isEmpty) continue;
      out.add(LibraryEntry(
        id: slug,
        title: '${f['title'] ?? ''}',
        coverUrl: '${f['coverUrl'] ?? ''}',
        kind: 'manga',
        subtitle: f['type']?.toString(),
        progress: f['latestChapter']?.toString(),
      ));
    }
    return out;
  }

  static Future<List<dynamic>> _readMangaFavs() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(_mangaFavKey);
    if (raw == null || raw.isEmpty) return [];
    try {
      final d = jsonDecode(raw);
      if (d is List) return d;
    } catch (_) {}
    return [];
  }

  static Future<void> _writeMangaFavs(List<dynamic> favs) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_mangaFavKey, jsonEncode(favs));
  }

  /// Pulihkan KEDUA store bookmark dari cloud, saling melengkapi.
  static Future<void> _restoreBookmarksFromCloud() async {
    final remote = await pullBookmarks();
    if (remote.isEmpty) return;
    // 1) Tab Favorit (BookmarkStore)
    for (final e in remote.reversed) {
      await BookmarkStore.add(e);
    }
    // 2) Halaman Bookmark komik + deteksi chapter (MangaFavoriteStore)
    final favs = await _readMangaFavs();
    final have = favs
        .map((f) => f is Map ? '${f['slug'] ?? ''}' : '')
        .toSet();
    final additions = <Map<String, dynamic>>[];
    for (final e in remote.reversed) {
      if (e.kind != 'manga' || e.id.isEmpty) continue;
      if (have.contains(e.id)) continue;
      have.add(e.id);
      additions.add({
        'slug': e.id,
        'title': e.title,
        'coverUrl': e.coverUrl,
        'type': e.subtitle,
        'latestChapter': e.progress,
      });
    }
    if (additions.isNotEmpty) {
      await _writeMangaFavs([...additions, ...favs]);
    }
  }

  /// Push GABUNGAN (union) BookmarkStore + favorit komik + data cloud.
  /// Mencegah data cloud tertimpa daftar lokal yang lebih kecil/kosong.
  static Future<void> _pushMergedBookmarks() async {
    final merged = <LibraryEntry>[];
    final seen = <String>{};
    void absorb(List<LibraryEntry> items) {
      for (final e in items) {
        if (e.id.isEmpty) continue;
        if (seen.add('${e.kind}:${e.id}')) merged.add(e);
      }
    }

    absorb(await BookmarkStore.list());
    absorb(_favToEntries(await _readMangaFavs()));
    absorb(await pullBookmarks());
    await pushBookmarks(merged);
  }

  static Future<void> pushHistory(List<LibraryEntry> items) async {
    try {
      final h = await _headers();
      await http
          .put(
            Uri.parse('$apiBaseUrl/api/me/history'),
            headers: h,
            body: jsonEncode({'data': items.map((e) => e.toJson()).toList()}),
          )
          .timeout(const Duration(seconds: 15));
    } catch (_) {}
  }

  static Future<List<LibraryEntry>> pullHistory() async {
    try {
      final h = await _headers();
      final res = await http
          .get(Uri.parse('$apiBaseUrl/api/me/history'), headers: h)
          .timeout(const Duration(seconds: 15));
      final body = jsonDecode(res.body);
      if (body is Map && body['ok'] == true && body['data'] is List) {
        return (body['data'] as List)
            .whereType<Map>()
            .map((e) => LibraryEntry.fromJson(Map<String, dynamic>.from(e)))
            .toList();
      }
    } catch (_) {}
    return [];
  }

  static Future<void> pushOffline(List<Map<String, dynamic>> items) async {
    try {
      final h = await _headers();
      await http
          .put(
            Uri.parse('$apiBaseUrl/api/me/offline'),
            headers: h,
            body: jsonEncode({'data': items}),
          )
          .timeout(const Duration(seconds: 15));
    } catch (_) {}
  }

  static Future<List<Map<String, dynamic>>> pullOffline() async {
    try {
      final h = await _headers();
      final res = await http
          .get(Uri.parse('$apiBaseUrl/api/me/offline'), headers: h)
          .timeout(const Duration(seconds: 15));
      final body = jsonDecode(res.body);
      if (body is Map && body['ok'] == true && body['data'] is List) {
        return (body['data'] as List)
            .whereType<Map>()
            .map((e) => Map<String, dynamic>.from(e))
            .toList();
      }
    } catch (_) {}
    return [];
  }

  // -------------------------------------------------------------------------
  // Progress baca (chapter yang pernah dibuka) — supaya tanda "sudah dibaca"
  // & posisi halaman terakhir tidak hilang setelah APK di-uninstall.
  // -------------------------------------------------------------------------

  static Future<void> pushReading() async {
    try {
      final data = await MangaReadStore.all();
      if (data.isEmpty) return;
      final h = await _headers();
      await http
          .put(
            Uri.parse('$apiBaseUrl/api/me/reading'),
            headers: h,
            body: jsonEncode({'data': data}),
          )
          .timeout(const Duration(seconds: 15));
    } catch (_) {}
  }

  static Future<void> pullReading() async {
    try {
      final h = await _headers();
      final res = await http
          .get(Uri.parse('$apiBaseUrl/api/me/reading'), headers: h)
          .timeout(const Duration(seconds: 15));
      final body = jsonDecode(res.body);
      if (body is Map && body['ok'] == true && body['data'] is Map) {
        await MangaReadStore.mergeFrom(
          Map<String, dynamic>.from(body['data'] as Map),
        );
      }
    } catch (_) {}
  }

  /// Pull dari server lalu merge ke local stores. Dipanggil saat login —
  /// ini jalur restore setelah APK di-uninstall lalu dipasang lagi.
  static Future<void> syncOnLogin() async {
    // Bookmark: pulihkan tab Favorit DAN halaman Bookmark komik sekaligus
    await _restoreBookmarksFromCloud();

    final remoteHi = await pullHistory();
    if (remoteHi.isNotEmpty) {
      for (final e in remoteHi.reversed) {
        await HistoryStore.add(e);
      }
    }
    // Progress baca: chapter yang pernah dibuka + posisi halaman terakhir
    await pullReading();

    final remoteOff = await pullOffline();
    for (final o in remoteOff) {
      final key = o['key']?.toString() ?? '';
      final path = o['path']?.toString() ?? '';
      final title = o['title']?.toString() ?? key;
      if (key.isEmpty) continue;
      await OfflineIndex.register(key: key, filePath: path, title: title);
    }

    // Blue Archive library + favorit anime + livechart
    await pullBa();
    await pullAnimeFavorites();
    await pullLiveChartBookmarks();

    // Preferensi notifikasi / settings → terapkan ke AppPrefs lokal
    final remoteSettings = await pullSettings();
    if (remoteSettings != null) {
      try {
        // AppPrefs di session.dart — optional soft import via SharedPreferences
        final prefs = await SharedPreferences.getInstance();
        if (remoteSettings['notifChapter'] is bool) {
          await prefs.setBool('pref_notif_chapter', remoteSettings['notifChapter'] as bool);
        }
        if (remoteSettings['notifComment'] is bool) {
          await prefs.setBool('pref_notif_comment', remoteSettings['notifComment'] as bool);
        }
      } catch (_) {}
    }

    // Kirim balik GABUNGAN (lokal + cloud)
    await _pushMergedBookmarks();
    await pushHistory(await HistoryStore.list());
    await pushReading();
    await pushOffline(await OfflineIndex.listAll());
    await pushBa();
    await pushAnimeFavorites();
    await pushLiveChartBookmarks();
    // Settings: kirim lokal (setelah merge cloud) jika ada
    try {
      final prefs = await SharedPreferences.getInstance();
      await pushSettings({
        'notifChapter': prefs.getBool('pref_notif_chapter') ?? true,
        'notifComment': prefs.getBool('pref_notif_comment') ?? true,
      });
    } catch (_) {}
  }

  // ----- Settings -----
  static Future<void> pushSettings(Map<String, dynamic> data) async {
    try {
      final h = await _headers();
      await http
          .put(
            Uri.parse('$apiBaseUrl/api/me/settings'),
            headers: h,
            body: jsonEncode({'data': data}),
          )
          .timeout(const Duration(seconds: 12));
    } catch (_) {}
  }

  static Future<Map<String, dynamic>?> pullSettings() async {
    try {
      final h = await _headers();
      final res = await http
          .get(Uri.parse('$apiBaseUrl/api/me/settings'), headers: h)
          .timeout(const Duration(seconds: 12));
      final body = jsonDecode(res.body);
      if (body is Map && body['ok'] == true && body['data'] is Map) {
        return Map<String, dynamic>.from(body['data'] as Map);
      }
    } catch (_) {}
    return null;
  }

  // ----- Blue Archive library -----
  static Future<void> pushBa() async {
    try {
      final items = await BaLibrary.list();
      final h = await _headers();
      // Jangan kirim localPath (path device) ke cloud
      final data = items
          .map((e) => {
                'id': e.id,
                'url': e.url,
                'favorite': e.favorite,
                'savedAt': e.savedAt?.toIso8601String(),
              })
          .toList();
      await http
          .put(
            Uri.parse('$apiBaseUrl/api/me/ba'),
            headers: h,
            body: jsonEncode({'data': data}),
          )
          .timeout(const Duration(seconds: 15));
    } catch (_) {}
  }

  static Future<void> pullBa() async {
    try {
      final h = await _headers();
      final res = await http
          .get(Uri.parse('$apiBaseUrl/api/me/ba'), headers: h)
          .timeout(const Duration(seconds: 15));
      final body = jsonDecode(res.body);
      if (body is! Map || body['ok'] != true || body['data'] is! List) return;
      final remote = (body['data'] as List)
          .whereType<Map>()
          .map((e) => BaImageEntry.fromJson(Map<String, dynamic>.from(e)))
          .where((e) => e.id.isNotEmpty)
          .toList();
      if (remote.isEmpty) return;
      final local = await BaLibrary.list();
      final byId = {for (final e in local) e.id: e};
      for (final r in remote) {
        final old = byId[r.id];
        if (old == null) {
          await BaLibrary.add(r);
        } else {
          // pertahankan localPath device
          await BaLibrary.add(r.copyWith(
            localPath: old.localPath,
            favorite: r.favorite || old.favorite,
          ));
        }
      }
    } catch (_) {}
  }

  // ----- Anime favorites (SharedPreferences key sama dengan AnimeFavoriteStore) -----
  static const _animeFavKey = 'anime_favorites_v1';

  static Future<void> pushAnimeFavorites() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_animeFavKey);
      final list = <dynamic>[];
      if (raw != null && raw.isNotEmpty) {
        final decoded = jsonDecode(raw);
        if (decoded is List) list.addAll(decoded);
      }
      final h = await _headers();
      await http
          .put(
            Uri.parse('$apiBaseUrl/api/me/anime-favorites'),
            headers: h,
            body: jsonEncode({'data': list}),
          )
          .timeout(const Duration(seconds: 15));
    } catch (_) {}
  }

  static Future<void> pullAnimeFavorites() async {
    try {
      final h = await _headers();
      final res = await http
          .get(Uri.parse('$apiBaseUrl/api/me/anime-favorites'), headers: h)
          .timeout(const Duration(seconds: 15));
      final body = jsonDecode(res.body);
      if (body is! Map || body['ok'] != true || body['data'] is! List) return;
      final remote = (body['data'] as List).whereType<Map>().toList();
      if (remote.isEmpty) return;

      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_animeFavKey);
      final local = <Map<String, dynamic>>[];
      if (raw != null && raw.isNotEmpty) {
        final decoded = jsonDecode(raw);
        if (decoded is List) {
          for (final e in decoded) {
            if (e is Map) local.add(Map<String, dynamic>.from(e));
          }
        }
      }
      final byId = {
        for (final e in local) '${e['id'] ?? ''}': e,
      };
      for (final r0 in remote) {
        final r = Map<String, dynamic>.from(r0);
        final id = '${r['id'] ?? ''}';
        if (id.isEmpty) continue;
        final old = byId[id];
        if (old == null) {
          byId[id] = r;
        } else {
          final rc = int.tryParse('${r['episodeCount'] ?? 0}') ?? 0;
          final oc = int.tryParse('${old['episodeCount'] ?? 0}') ?? 0;
          byId[id] = rc >= oc ? r : old;
        }
      }
      final merged = byId.values.where((e) => '${e['id'] ?? ''}'.isNotEmpty).toList();
      await prefs.setString(_animeFavKey, jsonEncode(merged));
    } catch (_) {}
  }

  
  // ----- LiveChart upcoming bookmarks -----
  static const _lcBookmarkKey = 'livechart_bookmarks_v1';

  static Future<void> pushLiveChartBookmarks() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_lcBookmarkKey);
      final list = <dynamic>[];
      if (raw != null && raw.isNotEmpty) {
        final decoded = jsonDecode(raw);
        if (decoded is List) list.addAll(decoded);
      }
      final h = await _headers();
      await http
          .put(
            Uri.parse('$apiBaseUrl/api/me/livechart-bookmarks'),
            headers: h,
            body: jsonEncode({'data': list}),
          )
          .timeout(const Duration(seconds: 15));
    } catch (_) {}
  }

  static Future<void> pullLiveChartBookmarks() async {
    try {
      final h = await _headers();
      final res = await http
          .get(Uri.parse('$apiBaseUrl/api/me/livechart-bookmarks'), headers: h)
          .timeout(const Duration(seconds: 15));
      final body = jsonDecode(res.body);
      if (body is! Map || body['ok'] != true || body['data'] is! List) return;
      final remote = (body['data'] as List).whereType<Map>().toList();
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_lcBookmarkKey);
      final local = <Map<String, dynamic>>[];
      if (raw != null && raw.isNotEmpty) {
        final decoded = jsonDecode(raw);
        if (decoded is List) {
          for (final e in decoded) {
            if (e is Map) local.add(Map<String, dynamic>.from(e));
          }
        }
      }
      final byId = {
        for (final e in local) '${e['id'] ?? ''}': e,
      };
      for (final r0 in remote) {
        final r = Map<String, dynamic>.from(r0);
        final id = '${r['id'] ?? ''}';
        if (id.isEmpty) continue;
        final old = byId[id];
        if (old == null) {
          byId[id] = r;
        } else {
          final notified = old['notified'] == true || r['notified'] == true;
          byId[id] = {
            ...r,
            'notified': notified,
            'premiereUnix': r['premiereUnix'] ?? old['premiereUnix'],
          };
        }
      }
      await prefs.setString(
        _lcBookmarkKey,
        jsonEncode(byId.values.toList()),
      );
    } catch (_) {}
  }

  static Future<void> pushAllLocal() async {
    await _pushMergedBookmarks();
    await pushHistory(await HistoryStore.list());
    await pushOffline(await OfflineIndex.listAll());
    await pushReading();
    await pushBa();
    await pushAnimeFavorites();
    await pushLiveChartBookmarks();
    try {
      final prefs = await SharedPreferences.getInstance();
      await pushSettings({
        'notifChapter': prefs.getBool('pref_notif_chapter') ?? true,
        'notifComment': prefs.getBool('pref_notif_comment') ?? true,
      });
    } catch (_) {}
  }
}
