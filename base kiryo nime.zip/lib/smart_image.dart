import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

/// Cover/thumbnail portrait dengan skeleton loading.
/// Tampilan bisa diperkecil (cepat); unduhan tetap pakai byte asli (HD).
class SmartCover extends StatelessWidget {
  const SmartCover({
    super.key,
    required this.url,
    this.width,
    this.height,
    this.borderRadius = 12,
    this.heroTag,
  });

  final String url;
  final double? width;
  final double? height;
  final double borderRadius;
  final String? heroTag;

  @override
  Widget build(BuildContext context) {
    final child = ClipRRect(
      borderRadius: BorderRadius.circular(borderRadius),
      child: ColoredBox(
        color: const Color(0xFF2A2233),
        child: url.isEmpty
            ? const _Skeleton()
            : Image.network(
                url,
                width: width,
                height: height,
                fit: BoxFit.cover, // isi frame portrait, tidak paksa 16:9
                alignment: Alignment.topCenter,
                filterQuality: FilterQuality.medium,
                errorBuilder: (_, __, ___) => const _CoverFallback(),
                loadingBuilder: (context, child, progress) {
                  if (progress == null) return child;
                  return const _Skeleton();
                },
              ),
      ),
    );
    if (heroTag != null && heroTag!.isNotEmpty) {
      return Hero(tag: heroTag!, child: child);
    }
    return child;
  }
}

class _Skeleton extends StatefulWidget {
  const _Skeleton();

  @override
  State<_Skeleton> createState() => _SkeletonState();
}

class _SkeletonState extends State<_Skeleton> with SingleTickerProviderStateMixin {
  late final AnimationController _c;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 1100))
      ..repeat(reverse: true);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (_, __) {
        final t = 0.35 + (_c.value * 0.35);
        return Container(
          alignment: Alignment.center,
          color: Color.lerp(const Color(0xFF241C2C), const Color(0xFF3A3145), t),
          child: Icon(Icons.image_outlined, color: Colors.white.withOpacity(0.25), size: 28),
        );
      },
    );
  }
}

class _CoverFallback extends StatelessWidget {
  const _CoverFallback();

  @override
  Widget build(BuildContext context) {
    return const ColoredBox(
      color: Color(0xFF2A2233),
      child: Center(
        child: Icon(Icons.broken_image_outlined, color: Colors.white38, size: 28),
      ),
    );
  }
}

/// Kompres untuk tampilan cepat (cache memori/disk ringan).
/// Jangan dipakai untuk file unduhan — unduhan tetap HD/asli.
class DisplayImageCodec {
  static Future<Uint8List?> compressForDisplay(
    Uint8List src, {
    int maxSide = 720,
    int quality = 85,
  }) async {
    try {
      final codec = await ui.instantiateImageCodec(
        src,
        targetWidth: maxSide,
        targetHeight: maxSide,
      );
      final frame = await codec.getNextFrame();
      final img = frame.image;
      final bd = await img.toByteData(format: ui.ImageByteFormat.png);
      img.dispose();
      return bd?.buffer.asUint8List();
    } catch (_) {
      return null;
    }
  }

  static Future<Uint8List?> downloadBytes(String url) async {
    try {
      final res = await http.get(Uri.parse(url)).timeout(const Duration(seconds: 20));
      if (res.statusCode >= 200 && res.statusCode < 300) return res.bodyBytes;
    } catch (_) {}
    return null;
  }
}

/// Avatar konsisten dari path asset atau file lokal.
class ProfileAvatar extends StatefulWidget {
  const ProfileAvatar({
    super.key,
    required this.path,
    this.radius = 22,
  });

  final String path;
  final double radius;

  @override
  State<ProfileAvatar> createState() => _ProfileAvatarState();
}

class _ProfileAvatarState extends State<ProfileAvatar> {
  Uint8List? _bytes;
  int? _len;
  String _loadedFor = '';

  @override
  void initState() {
    super.initState();
    _loadBytes();
  }

  @override
  void didUpdateWidget(covariant ProfileAvatar oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.path != widget.path) _loadBytes();
  }

  /// Baca byte terbaru LANGSUNG dari disk (async).
  /// Image.file men-cache byte di memory, sehingga file yang baru ditulis
  /// di path yang sama bisa tampil hitam/lama — Image.memory mem-bypass itu.
  Future<void> _loadBytes() async {
    final p = widget.path.trim();
    if (p.isEmpty ||
        p.startsWith('assets/') ||
        p.startsWith('http://') ||
        p.startsWith('https://')) {
      return;
    }
    final filePath = p.replaceFirst('file://', '');
    try {
      final f = File(filePath);
      if (!await f.exists()) {
        if (mounted && (_bytes != null || _loadedFor != p)) {
          setState(() {
            _bytes = null;
            _loadedFor = p;
          });
        }
        return;
      }
      final b = await f.readAsBytes();
      final l = await f.length();
      if (!mounted) return;
      setState(() {
        _bytes = b;
        _len = l;
        _loadedFor = p;
      });
    } catch (_) {
      if (mounted) {
        setState(() {
          _bytes = null;
          _loadedFor = p;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final size = widget.radius * 2;
    Widget img;
    final p = widget.path.trim();
    if (p.startsWith('assets/')) {
      img = Image.asset(
        p,
        key: ValueKey(p),
        width: size,
        height: size,
        fit: BoxFit.cover,
        gaplessPlayback: false,
        errorBuilder: (_, __, ___) => _fallback(size),
      );
    } else if (p.startsWith('http://') || p.startsWith('https://')) {
      img = Image.network(
        p,
        key: ValueKey(p),
        width: size,
        height: size,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => _fallback(size),
      );
    } else if (p.isNotEmpty) {
      final b = (_loadedFor == p) ? _bytes : null;
      if (b != null && b.isNotEmpty) {
        // Render byte yang BARU dibaca dari disk — tidak kena cache lama
        img = Image.memory(
          b,
          key: ValueKey('mem_${p}_$_len'),
          width: size,
          height: size,
          fit: BoxFit.cover,
          gaplessPlayback: false,
          errorBuilder: (_, __, ___) => _fallback(size),
        );
      } else if (_loadedFor != p) {
        // Byte terbaru sedang dibaca — tahan placeholder gelap sebentar
        img = SizedBox(width: size, height: size);
      } else {
        img = _fallback(size);
      }
    } else {
      img = _fallback(size);
    }
    return CircleAvatar(
      radius: widget.radius,
      backgroundColor: const Color(0xFF3A3145),
      child: ClipOval(child: img),
    );
  }

  Widget _fallback(double size) {
    return Image.asset(
      'assets/images/default_avatar.jpg',
      width: size,
      height: size,
      fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => Icon(Icons.person, size: size * 0.6, color: Colors.white54),
    );
  }
}
