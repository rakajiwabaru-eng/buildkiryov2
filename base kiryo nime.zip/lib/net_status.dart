import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'api_config.dart';

/// Cek koneksi: harus bisa HTTP beneran (bukan cuma DNS / sinyal hidup).
/// Kasus "data hidup tapi paket habis" → DNS kadang masih OK, tapi HTTP gagal.
class NetStatus {
  static Future<bool> hasConnection() async {
    // Wajib lolos minimal 1 ping HTTP. DNS saja TIDAK cukup.
    if (await _pingApi()) return true;
    if (await _pingPublic()) return true;
    return false;
  }

  static Future<bool> _pingApi() async {
    try {
      final uri = Uri.parse('$apiBaseUrl/health');
      final res = await http.get(uri).timeout(const Duration(seconds: 4));
      return res.statusCode >= 200 && res.statusCode < 500;
    } catch (_) {
      try {
        final uri = Uri.parse(apiBaseUrl);
        final res = await http
            .get(uri)
            .timeout(const Duration(seconds: 4));
        return res.statusCode > 0;
      } catch (_) {
        return false;
      }
    }
  }

  /// Cadangan: generate_204 / connectivity check publik.
  static Future<bool> _pingPublic() async {
    const urls = [
      'https://clients3.google.com/generate_204',
      'https://www.gstatic.com/generate_204',
      'https://connectivitycheck.gstatic.com/generate_204',
    ];
    for (final u in urls) {
      try {
        final res = await http
            .get(Uri.parse(u))
            .timeout(const Duration(seconds: 3));
        // 204 / 200 / 204-like = online
        if (res.statusCode == 204 || res.statusCode == 200) return true;
      } catch (_) {}
    }
    // Terakhir coba DNS hanya sebagai sinyal lemah — tetap false
    // agar "paket habis" tidak dianggap online.
    return false;
  }
}

/// Overlay jaringan bermasalah + tombol Retry.
class NoConnectionView extends StatelessWidget {
  const NoConnectionView({super.key, required this.onRetry, this.busy = false});

  final VoidCallback onRetry;
  final bool busy;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: Image.asset(
                'assets/images/no_connection.png',
                width: 140,
                height: 140,
                fit: BoxFit.contain,
                errorBuilder: (_, __, ___) => Icon(
                  Icons.wifi_off_rounded,
                  size: 56,
                  color: Colors.white.withOpacity(0.45),
                ),
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              'Jaringanmu saat ini bermasalah',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w800,
                fontSize: 17,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Periksa internet lalu coba lagi',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.white.withOpacity(0.55),
                fontSize: 13,
                height: 1.35,
              ),
            ),
            const SizedBox(height: 22),
            ElevatedButton.icon(
              onPressed: busy ? null : onRetry,
              icon: busy
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Color(0xFF17121F),
                      ),
                    )
                  : const Icon(Icons.refresh_rounded),
              label: Text(
                busy ? 'Mencoba...' : 'Retry',
                style: const TextStyle(fontWeight: FontWeight.w800),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFFFD88A),
                foregroundColor: const Color(0xFF17121F),
                padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
