import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import 'app_errors.dart';
import 'direct_download.dart';
import 'local_library.dart';
import 'api_sync.dart';

/// Random foto Blue Archive dari api.siputzx.my.id
class BlueArchivePage extends StatefulWidget {
  const BlueArchivePage({super.key});

  @override
  State<BlueArchivePage> createState() => _BlueArchivePageState();
}

class _BlueArchivePageState extends State<BlueArchivePage> {
  static const _apiUrl = 'https://api.siputzx.my.id/api/r/blue-archive';

  Uint8List? _imageBytes;
  String? _currentId;
  String _ext = 'png';
  bool _loading = false;
  bool _saving = false;
  String? _error;
  List<BaImageEntry> _history = [];
  bool _showFavOnly = false;
  bool _selectMode = false;
  final Set<String> _selected = {};

  @override
  void initState() {
    super.initState();
    _loadHistory();
  }

  Future<void> _loadHistory() async {
    final list = await BaLibrary.list();
    if (!mounted) return;
    setState(() => _history = list);
  }

  void _enterSelectMode(String id) {
    setState(() {
      _selectMode = true;
      _selected
        ..clear()
        ..add(id);
    });
  }

  void _exitSelectMode() {
    setState(() {
      _selectMode = false;
      _selected.clear();
    });
  }

  void _toggleSelect(String id) {
    setState(() {
      if (_selected.contains(id)) {
        _selected.remove(id);
        if (_selected.isEmpty) _selectMode = false;
      } else {
        _selected.add(id);
      }
    });
  }

  Future<void> _deleteSelected() async {
    if (_selected.isEmpty) return;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF241C2C),
        title: const Text('Hapus foto?', style: TextStyle(color: Colors.white)),
        content: Text(
          'Hapus ${_selected.length} foto dari riwayat?',
          style: const TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Hapus', style: TextStyle(color: Colors.redAccent)),
          ),
        ],
      ),
    );
    if (ok != true) return;
    final ids = Set<String>.from(_selected);
    await BaLibrary.removeIds(ids);
    if (_currentId != null && ids.contains(_currentId)) {
      setState(() {
        _imageBytes = null;
        _currentId = null;
      });
    }
    _exitSelectMode();
    await _loadHistory();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('${ids.length} foto dihapus')),
    );
  }

  Future<Directory> _cacheDir() async {
    final root = await getApplicationDocumentsDirectory();
    final d = Directory('${root.path}/ba_cache');
    if (!await d.exists()) await d.create(recursive: true);
    return d;
  }

  /// Fingerprint konten gambar (bukan timestamp) untuk deteksi duplikat.
  static String _fingerprint(Uint8List b) {
    // FNV-1a 64-bit style + panjang file
    var h = 0xcbf29ce484222325;
    final step = b.length > 4096 ? (b.length ~/ 2048) : 1;
    for (var i = 0; i < b.length; i += step) {
      h ^= b[i];
      h = (h * 0x100000001b3) & 0xFFFFFFFFFFFFFFFF;
    }
    h ^= b.length;
    return '${b.length.toRadixString(16)}_${h.toRadixString(16)}';
  }

  Future<Set<String>> _knownFingerprints() async {
    final known = <String>{};
    // fingerprint dari file cache di riwayat
    for (final e in _history) {
      final path = e.localPath;
      if (path == null || path.isEmpty) continue;
      try {
        final f = File(path);
        if (!await f.exists()) continue;
        final bytes = await f.readAsBytes();
        if (bytes.isNotEmpty) known.add(_fingerprint(bytes));
      } catch (_) {}
    }
    // fingerprint gambar yang sedang ditampilkan
    final cur = _imageBytes;
    if (cur != null && cur.isNotEmpty) known.add(_fingerprint(cur));
    return known;
  }

  String _detectExt(http.Response res) {
    final ctype = (res.headers['content-type'] ?? '').toLowerCase();
    if (ctype.contains('jpeg') || ctype.contains('jpg')) return 'jpg';
    if (ctype.contains('webp')) return 'webp';
    if (ctype.contains('png')) return 'png';
    final b = res.bodyBytes;
    if (b.length >= 3 && b[0] == 0xFF && b[1] == 0xD8 && b[2] == 0xFF) {
      return 'jpg';
    }
    if (b.length >= 4 &&
        b[0] == 0x89 &&
        b[1] == 0x50 &&
        b[2] == 0x4E &&
        b[3] == 0x47) {
      return 'png';
    }
    return 'png';
  }

  Future<void> _fetchRandom() async {
    setState(() {
      _loading = true;
      _error = null;
      _imageBytes = null;
      _currentId = null;
    });
    try {
      final known = await _knownFingerprints();
      Uint8List? chosen;
      var ext = 'png';
      String? fp;
      const maxTries = 10;

      for (var attempt = 0; attempt < maxTries; attempt++) {
        final res = await http
            .get(Uri.parse('$_apiUrl?t=${DateTime.now().millisecondsSinceEpoch}'))
            .timeout(const Duration(seconds: 30));
        if (res.statusCode < 200 || res.statusCode >= 300) {
          if (attempt == maxTries - 1) {
            throw Exception('Gagal mengambil foto (${res.statusCode})');
          }
          continue;
        }
        if (res.bodyBytes.isEmpty) continue;

        final print = _fingerprint(res.bodyBytes);
        if (known.contains(print)) {
          // Sama dengan riwayat / foto sebelumnya → coba lagi
          continue;
        }
        chosen = res.bodyBytes;
        ext = _detectExt(res);
        fp = print;
        break;
      }

      if (chosen == null || chosen.isEmpty) {
        // Semua percobaan duplikat — tetap tampilkan yang terakhir dari API
        final res = await http
            .get(Uri.parse('$_apiUrl?t=${DateTime.now().millisecondsSinceEpoch}'))
            .timeout(const Duration(seconds: 30));
        if (res.statusCode < 200 || res.statusCode >= 300 || res.bodyBytes.isEmpty) {
          throw Exception('Tidak dapat foto baru (banyak duplikat dari API)');
        }
        chosen = res.bodyBytes;
        ext = _detectExt(res);
        fp = _fingerprint(chosen);
      }

      // id = fingerprint supaya entry riwayat unik per konten
      final id = fp ?? DateTime.now().millisecondsSinceEpoch.toRadixString(36);
      final dir = await _cacheDir();
      final cacheFile = File('${dir.path}/$id.$ext');
      await cacheFile.writeAsBytes(chosen, flush: true);
      await BaLibrary.add(BaImageEntry(
        id: id,
        url: _apiUrl,
        localPath: cacheFile.path,
      ));
      if (!mounted) return;
      setState(() {
        _imageBytes = chosen;
        _ext = ext;
        _currentId = id;
        _loading = false;
      });
      await _loadHistory();
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = AppErrors.describe(e);
      });
    }
  }

  Future<Uint8List> _upscaleBytes(Uint8List src, {double scale = 2.5}) async {
    final codec = await ui.instantiateImageCodec(src);
    final frame = await codec.getNextFrame();
    final image = frame.image;
    final tw = (image.width * scale).round().clamp(1, 4096);
    final th = (image.height * scale).round().clamp(1, 4096);
    final recorder = ui.PictureRecorder();
    final canvas = Canvas(recorder);
    final paint = Paint()..filterQuality = FilterQuality.high;
    canvas.drawImageRect(
      image,
      Rect.fromLTWH(0, 0, image.width.toDouble(), image.height.toDouble()),
      Rect.fromLTWH(0, 0, tw.toDouble(), th.toDouble()),
      paint,
    );
    final picture = recorder.endRecording();
    final out = await picture.toImage(tw, th);
    final bd = await out.toByteData(format: ui.ImageByteFormat.png);
    image.dispose();
    out.dispose();
    if (bd == null) return src;
    return bd.buffer.asUint8List();
  }

  Future<void> _download() async {
    final bytes = _imageBytes;
    if (bytes == null || bytes.isEmpty) return;
    setState(() => _saving = true);
    try {
      final big = await _upscaleBytes(bytes, scale: 2.5);
      final folder = await resolvePublicDownloadDir();
      final acak = DateTime.now().millisecondsSinceEpoch.toRadixString(36);
      final name = 'ba_kiryo_$acak.png';
      final path = '${folder.path}/$name';
      await File(path).writeAsBytes(big, flush: true);
      if (_currentId != null) {
        final all = await BaLibrary.list();
        final i = all.indexWhere((e) => e.id == _currentId);
        if (i >= 0) {
          await BaLibrary.add(all[i].copyWith(localPath: path));
        }
      }
      if (!mounted) return;
      final mb = (big.length / 1024 / 1024).toStringAsFixed(2);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Tersimpan ($mb MB): $path')),
      );
      await _loadHistory();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(AppErrors.describe(e))),
      );
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _toggleFav() async {
    final id = _currentId;
    if (id == null) return;
    final all = await BaLibrary.list();
    BaImageEntry? item;
    for (final e in all) {
      if (e.id == id) {
        item = e;
        break;
      }
    }
    if (item == null) return;
    await BaLibrary.setFavorite(id, !item.favorite);
    // ignore: unawaited_futures
    ApiSync.pushBa();
    await _loadHistory();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(item.favorite ? 'Dihapus dari favorit' : 'Ditambah ke favorit'),
      ),
    );
  }

  Future<void> _shareCurrent() async {
    final id = _currentId;
    final bytes = _imageBytes;
    try {
      String? path;
      if (id != null) {
        final all = await BaLibrary.list();
        for (final e in all) {
          if (e.id == id) {
            path = e.localPath;
            break;
          }
        }
      }
      if ((path == null || !await File(path).exists()) && bytes != null) {
        final dir = await _cacheDir();
        path = '${dir.path}/share_${DateTime.now().millisecondsSinceEpoch}.$_ext';
        await File(path).writeAsBytes(bytes, flush: true);
      }
      if (path == null || !await File(path).exists()) {
        throw Exception('Tidak ada foto untuk dibagikan');
      }
      await Share.shareXFiles([XFile(path)], text: 'Blue Archive — KIRYO NIME');
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(AppErrors.describe(e))),
      );
    }
  }

  void _openHistoryItem(BaImageEntry e) {
    final path = e.localPath;
    if (path == null || !File(path).existsSync()) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('File cache sudah tidak ada')),
      );
      return;
    }
    final bytes = File(path).readAsBytesSync();
    setState(() {
      _imageBytes = bytes;
      _currentId = e.id;
      _error = null;
    });
  }

  bool get _isFav {
    final id = _currentId;
    if (id == null) return false;
    return _history.any((e) => e.id == id && e.favorite);
  }

  List<BaImageEntry> get _gridItems {
    if (_showFavOnly) return _history.where((e) => e.favorite).toList();
    return _history;
  }

  @override
  Widget build(BuildContext context) {
    final grid = _gridItems;
    return Scaffold(
      backgroundColor: const Color(0xFF17121F),
      appBar: AppBar(
        backgroundColor: const Color(0xFF17121F),
        foregroundColor: Colors.white,
        leading: _selectMode
            ? IconButton(
                icon: const Icon(Icons.close),
                onPressed: _exitSelectMode,
              )
            : null,
        title: Text(
          _selectMode ? '${_selected.length} dipilih' : 'Blue Archive Random',
        ),
        actions: [
          if (_selectMode) ...[
            IconButton(
              tooltip: 'Hapus',
              onPressed: _selected.isEmpty ? null : _deleteSelected,
              icon: const Icon(Icons.delete_outline_rounded, color: Colors.redAccent),
            ),
          ] else
            IconButton(
              tooltip: _showFavOnly ? 'Semua' : 'Favorit saja',
              onPressed: () => setState(() => _showFavOnly = !_showFavOnly),
              icon: Icon(
                _showFavOnly ? Icons.favorite : Icons.favorite_border,
                color: const Color(0xFFFFD88A),
              ),
            ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
        children: [
          if (_error != null) ...[
            Text(_error!, style: const TextStyle(color: Colors.redAccent, fontSize: 13), textAlign: TextAlign.center),
            const SizedBox(height: 12),
          ],
          if (_loading)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 48),
              child: Column(
                children: [
                  CircularProgressIndicator(color: Color(0xFFFFD88A)),
                  SizedBox(height: 12),
                  Text('tunggu lagi proses ya >.<', style: TextStyle(color: Colors.white54)),
                ],
              ),
            )
          else if (_imageBytes != null)
            ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: Image.memory(_imageBytes!, fit: BoxFit.contain),
            )
          else
            Container(
              height: 220,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: const Color(0xFF2A2233),
                borderRadius: BorderRadius.circular(16),
              ),
              child: const Text('Tekan Cari untuk foto random', style: TextStyle(color: Colors.white54)),
            ),
          const SizedBox(height: 12),
          SizedBox(
            height: 50,
            child: ElevatedButton.icon(
              onPressed: _loading || _saving ? null : _fetchRandom,
              icon: _loading
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFF17121F)),
                    )
                  : const Icon(Icons.search_rounded),
              label: Text(_loading ? 'Mencari...' : 'Cari', style: const TextStyle(fontWeight: FontWeight.w800)),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFFFD88A),
                foregroundColor: const Color(0xFF17121F),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              ),
            ),
          ),
          if (!_loading && _imageBytes != null) ...[
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _saving ? null : _download,
                    icon: _saving
                        ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFFFFD88A)))
                        : const Icon(Icons.download_rounded),
                    label: Text(_saving ? '...' : 'Unduh', style: const TextStyle(fontWeight: FontWeight.w800)),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: const Color(0xFFFFD88A),
                      side: const BorderSide(color: Color(0xFFFFD88A)),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton(
                  tooltip: 'Favorit',
                  onPressed: _toggleFav,
                  icon: Icon(_isFav ? Icons.favorite : Icons.favorite_border, color: Colors.pinkAccent),
                ),
                IconButton(
                  tooltip: 'Bagikan',
                  onPressed: _shareCurrent,
                  icon: const Icon(Icons.share_rounded, color: Color(0xFFFFD88A)),
                ),
              ],
            ),
          ],
          if (grid.isNotEmpty) ...[
            const SizedBox(height: 22),
            Text(
              _showFavOnly ? 'Favorit (${grid.length})' : 'Riwayat (${grid.length})',
              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 16),
            ),
            const SizedBox(height: 10),
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: grid.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                mainAxisSpacing: 8,
                crossAxisSpacing: 8,
                childAspectRatio: 0.72,
              ),
              itemBuilder: (_, i) {
                final e = grid[i];
                final path = e.localPath;
                final selected = _selected.contains(e.id);
                return GestureDetector(
                  onTap: () {
                    if (_selectMode) {
                      _toggleSelect(e.id);
                    } else {
                      _openHistoryItem(e);
                    }
                  },
                  onLongPress: () {
                    if (_selectMode) {
                      _toggleSelect(e.id);
                    } else {
                      _enterSelectMode(e.id);
                    }
                  },
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: path != null && File(path).existsSync()
                            ? Image.file(File(path), fit: BoxFit.cover)
                            : const ColoredBox(color: Color(0xFF2A2233), child: Icon(Icons.image, color: Colors.white24)),
                      ),
                      if (_selectMode)
                        Positioned(
                          left: 6,
                          top: 6,
                          child: Container(
                            width: 22,
                            height: 22,
                            decoration: BoxDecoration(
                              color: selected ? const Color(0xFFFFD88A) : Colors.black54,
                              shape: BoxShape.circle,
                              border: Border.all(color: Colors.white70, width: 1.5),
                            ),
                            child: selected
                                ? const Icon(Icons.check, size: 14, color: Color(0xFF17121F))
                                : null,
                          ),
                        )
                      else if (e.favorite)
                        const Positioned(
                          right: 4,
                          top: 4,
                          child: Icon(Icons.favorite, color: Colors.pinkAccent, size: 16),
                        ),
                      if (selected)
                        Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: const Color(0xFFFFD88A), width: 2.5),
                          ),
                        ),
                    ],
                  ),
                );
              },
            ),
          ],
        ],
      ),
    );
  }
}
