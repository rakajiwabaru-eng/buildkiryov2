import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';

import 'app_features.dart';

/// Putar video file lokal (offline) tanpa internet.
class OfflineVideoPage extends StatefulWidget {
  const OfflineVideoPage({
    super.key,
    required this.filePath,
    required this.title,
    this.progressKey,
    this.animeTitle,
    this.coverUrl,
  });

  final String filePath;
  final String title;
  final String? progressKey;
  final String? animeTitle;
  final String? coverUrl;

  @override
  State<OfflineVideoPage> createState() => _OfflineVideoPageState();
}

class _OfflineVideoPageState extends State<OfflineVideoPage> {
  VideoPlayerController? _controller;
  bool _ready = false;
  bool _error = false;
  String? _errorMsg;
  bool _showControls = true;
  bool _fullscreen = false;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final file = File(widget.filePath);
    if (!await file.exists()) {
      setState(() {
        _error = true;
        _errorMsg = 'File tidak ditemukan';
      });
      return;
    }
    try {
      final c = VideoPlayerController.file(file);
      await c.initialize();
      c.setLooping(false);
      c.addListener(() {
        if (mounted) setState(() {});
      });
      if (!mounted) {
        await c.dispose();
        return;
      }
      final pk = widget.progressKey;
      if (pk != null && pk.isNotEmpty) {
        final pos = await WatchProgressStore.getPosition(pk);
        if (pos != null && pos > 0) {
          final dur = c.value.duration.inSeconds;
          if (dur > 0 && pos < dur - 3) {
            await c.seekTo(Duration(seconds: pos));
          }
        }
        c.addListener(() {
          final v = c.value;
          if (!v.isInitialized || !v.isPlaying) return;
          final pos = v.position.inSeconds;
          final dur = v.duration.inSeconds;
          if (pos > 0 && dur > 0 && pos % 5 == 0) {
            WatchProgressStore.save(
              key: pk,
              positionSec: pos,
              durationSec: dur,
              title: widget.title,
              animeTitle: widget.animeTitle,
              coverUrl: widget.coverUrl,
              episodeTitle: widget.title,
            );
          }
        });
      }
      setState(() {
        _controller = c;
        _ready = true;
      });
      await c.play();
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = true;
        _errorMsg = e.toString().replaceFirst('Exception: ', '');
      });
    }
  }

  @override
  void dispose() {
    final c = _controller;
    final pk = widget.progressKey;
    if (c != null && pk != null && pk.isNotEmpty && c.value.isInitialized) {
      final pos = c.value.position.inSeconds;
      final dur = c.value.duration.inSeconds;
      if (pos > 0 && dur > 0) {
        WatchProgressStore.save(
          key: pk,
          positionSec: pos,
          durationSec: dur,
          title: widget.title,
          animeTitle: widget.animeTitle,
          coverUrl: widget.coverUrl,
          episodeTitle: widget.title,
        );
      }
    }
    _controller?.dispose();
    SystemChrome.setPreferredOrientations(const [
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  Future<void> _toggleFullscreen() async {
    final next = !_fullscreen;
    setState(() => _fullscreen = next);
    if (next) {
      await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
      await SystemChrome.setPreferredOrientations(const [
        DeviceOrientation.landscapeLeft,
        DeviceOrientation.landscapeRight,
      ]);
    } else {
      await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
      await SystemChrome.setPreferredOrientations(const [
        DeviceOrientation.portraitUp,
      ]);
      Future.delayed(const Duration(milliseconds: 280), () {
        SystemChrome.setPreferredOrientations(const [
          DeviceOrientation.portraitUp,
          DeviceOrientation.portraitDown,
          DeviceOrientation.landscapeLeft,
          DeviceOrientation.landscapeRight,
        ]);
      });
    }
  }

  String _fmt(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    final h = d.inHours;
    if (h > 0) return '$h:$m:$s';
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    final c = _controller;

    if (_fullscreen) {
      return PopScope(
        canPop: false,
        onPopInvoked: (didPop) {
          if (!didPop) _toggleFullscreen();
        },
        child: Scaffold(
          backgroundColor: Colors.black,
          body: GestureDetector(
            onTap: () => setState(() => _showControls = !_showControls),
            child: Stack(
              fit: StackFit.expand,
              children: [
                if (_ready && c != null)
                  Center(
                    child: AspectRatio(
                      aspectRatio: c.value.aspectRatio == 0 ? 16 / 9 : c.value.aspectRatio,
                      child: VideoPlayer(c),
                    ),
                  ),
                if (_showControls) _controlsOverlay(c, full: true),
              ],
            ),
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: const Color(0xFF17121F),
      appBar: AppBar(
        backgroundColor: Colors.black54,
        foregroundColor: Colors.white,
        title: Text(
          widget.title,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15),
        ),
      ),
      body: _error
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Text(
                  _errorMsg ?? 'Gagal memutar video',
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.white70),
                ),
              ),
            )
          : !_ready || c == null
              ? const Center(child: CircularProgressIndicator(color: Color(0xFFFFD88A)))
              : Column(
                  children: [
                    AspectRatio(
                      aspectRatio: c.value.aspectRatio == 0 ? 16 / 9 : c.value.aspectRatio,
                      child: GestureDetector(
                        onTap: () => setState(() => _showControls = !_showControls),
                        child: Stack(
                          fit: StackFit.expand,
                          children: [
                            const ColoredBox(color: Colors.black),
                            VideoPlayer(c),
                            if (_showControls) _controlsOverlay(c, full: false),
                          ],
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
                      child: Text(
                        widget.title,
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w800,
                          fontSize: 15,
                        ),
                      ),
                    ),
                  ],
                ),
    );
  }

  Widget _controlsOverlay(VideoPlayerController? c, {required bool full}) {
    if (c == null) return const SizedBox.shrink();
    final pos = c.value.position;
    final dur = c.value.duration;
    final playing = c.value.isPlaying;
    return ColoredBox(
      color: Colors.black38,
      child: Column(
        children: [
          const Spacer(),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              IconButton(
                iconSize: 36,
                color: Colors.white,
                onPressed: () {
                  final t = pos - const Duration(seconds: 10);
                  c.seekTo(t < Duration.zero ? Duration.zero : t);
                },
                icon: const Icon(Icons.replay_10_rounded),
              ),
              const SizedBox(width: 12),
              IconButton(
                iconSize: 52,
                color: const Color(0xFFFFD88A),
                onPressed: () {
                  if (playing) {
                    c.pause();
                  } else {
                    c.play();
                  }
                  setState(() {});
                },
                icon: Icon(playing ? Icons.pause_circle_filled : Icons.play_circle_filled),
              ),
              const SizedBox(width: 12),
              IconButton(
                iconSize: 36,
                color: Colors.white,
                onPressed: () {
                  final t = pos + const Duration(seconds: 10);
                  c.seekTo(t > dur ? dur : t);
                },
                icon: const Icon(Icons.forward_10_rounded),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 4, 12, 12),
            child: Row(
              children: [
                Text(
                  _fmt(pos),
                  style: const TextStyle(color: Colors.white70, fontSize: 11),
                ),
                Expanded(
                  child: SliderTheme(
                    data: SliderTheme.of(context).copyWith(
                      trackHeight: 2,
                      thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 6),
                      activeTrackColor: const Color(0xFFFFD88A),
                      inactiveTrackColor: Colors.white24,
                      thumbColor: const Color(0xFFFFD88A),
                    ),
                    child: Slider(
                      value: dur.inMilliseconds == 0
                          ? 0
                          : pos.inMilliseconds.clamp(0, dur.inMilliseconds).toDouble(),
                      max: dur.inMilliseconds == 0 ? 1 : dur.inMilliseconds.toDouble(),
                      onChanged: (v) => c.seekTo(Duration(milliseconds: v.round())),
                    ),
                  ),
                ),
                Text(
                  _fmt(dur),
                  style: const TextStyle(color: Colors.white70, fontSize: 11),
                ),
                IconButton(
                  color: Colors.white,
                  onPressed: _toggleFullscreen,
                  icon: Icon(full ? Icons.fullscreen_exit_rounded : Icons.fullscreen_rounded),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
