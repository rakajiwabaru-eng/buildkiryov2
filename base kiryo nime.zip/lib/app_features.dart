import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import 'direct_download.dart';
import 'local_library.dart';
import 'session.dart';

class DlLink {
  const DlLink({required this.quality, required this.link, required this.host});
  final String quality;
  final String link;
  final String host;
}

class WatchProgressStore {
  static const _baseKey = 'watch_progress_v1';
  static Future<String> _key() => UserDataKeys.of(_baseKey);

  static Future<Map<String, dynamic>> _all() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(await _key());
    if (raw == null || raw.isEmpty) return {};
    try {
      final d = jsonDecode(raw);
      if (d is Map) return Map<String, dynamic>.from(d);
    } catch (_) {}
    return {};
  }

  static Future<void> _write(Map<String, dynamic> data) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(await _key(), jsonEncode(data));
  }

  static Future<void> save({
    required String key,
    required int positionSec,
    required int durationSec,
    String? title,
    String? animeTitle,
    String? coverUrl,
    String? episodeTitle,
    String? link,
  }) async {
    if (key.isEmpty || durationSec <= 0 || positionSec < 5) return;
    final ratio = positionSec / durationSec;
    if (ratio > 0.95) {
      await clear(key);
      await WatchStatsStore.addWatchSeconds(durationSec);
      await WatchStatsStore.markEpisodeDone(key);
      return;
    }
    final all = await _all();
    final prev = all[key];
    final lastReported = (prev is Map && prev['lastReported'] is int)
        ? prev['lastReported'] as int
        : 0;
    all[key] = {
      'positionSec': positionSec,
      'durationSec': durationSec,
      'ratio': ratio,
      'title': title ?? '',
      'animeTitle': animeTitle ?? '',
      'coverUrl': coverUrl ?? '',
      'episodeTitle': episodeTitle ?? '',
      'link': link ?? '',
      'updatedAt': DateTime.now().toIso8601String(),
      'lastReported': positionSec,
    };
    await _write(all);
    final delta = (positionSec - lastReported).clamp(0, 3600);
    if (delta > 0) await WatchStatsStore.addWatchSeconds(delta);
    await WidgetBridge.update();
  }

  static Future<int?> getPosition(String key) async {
    final e = (await _all())[key];
    if (e is! Map) return null;
    final pos = e['positionSec'];
    if (pos is int) return pos;
    if (pos is num) return pos.toInt();
    return int.tryParse('$pos');
  }

  static Future<void> clear(String key) async {
    final all = await _all();
    all.remove(key);
    await _write(all);
  }

  static Future<List<Map<String, dynamic>>> continueList({int max = 20}) async {
    final all = await _all();
    final items = <Map<String, dynamic>>[];
    all.forEach((k, v) {
      if (v is Map) items.add({...Map<String, dynamic>.from(v), 'key': k});
    });
    items.sort((a, b) {
      final aa = DateTime.tryParse('${a['updatedAt'] ?? ''}') ?? DateTime(2000);
      final bb = DateTime.tryParse('${b['updatedAt'] ?? ''}') ?? DateTime(2000);
      return bb.compareTo(aa);
    });
    return items.length > max ? items.sublist(0, max) : items;
  }
}

class DownloadQualityPref {
  static const _k = 'pref_default_download_quality';
  static Future<String> get() async {
    final p = await SharedPreferences.getInstance();
    return p.getString(_k) ?? '';
  }
  static Future<void> set(String q) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_k, q);
  }
  static bool matches(String qualityLabel, String pref) {
    if (pref.isEmpty) return true;
    return qualityLabel.toLowerCase().contains(pref.toLowerCase());
  }
  static String? pickPreferred(Iterable<String> qualities, String pref) {
    final list = qualities.toList();
    if (list.isEmpty) return null;
    if (pref.isEmpty) {
      for (final want in ['720', '480', '360', '1080']) {
        for (final k in list) {
          if (k.toLowerCase().contains(want)) return k;
        }
      }
      return list.first;
    }
    for (final k in list) {
      if (matches(k, pref)) return k;
    }
    return list.first;
  }
}

class SubLabel {
  static String fromParts({required String quality, required String host, String link = ''}) {
    final blob = '$quality $host $link'.toLowerCase();
    if (blob.contains('softsub') || blob.contains('soft sub')) return 'Softsub';
    if (blob.contains('hardsub') || blob.contains('hard sub')) return 'Hardsub';
    if (blob.contains('raw')) return 'RAW';
    if (blob.contains('dual') || blob.contains('multi')) return 'Dual audio';
    if (blob.contains('indosub') || blob.contains('indo')) return 'Indo';
    return '';
  }
  static String badge(List<({String quality, String host, String link})> items) {
    final labels = <String>{};
    for (final it in items) {
      final s = fromParts(quality: it.quality, host: it.host, link: it.link);
      if (s.isNotEmpty) labels.add(s);
    }
    return labels.join(' · ');
  }
}

enum QueueStatus { pending, waiting, downloading, done, failed, cancelled }

class QueueItem {
  QueueItem({
    required this.id,
    required this.episodeTitle,
    required this.quality,
    required this.links,
    this.animeTitle = '',
    this.coverUrl = '',
    this.seriesKey,
    this.episodeSlug,
    this.status = QueueStatus.pending,
    this.error,
    this.progress = 0,
  });
  final String id;
  final String episodeTitle;
  final String quality;
  final List<DlLink> links;
  final String animeTitle;
  final String coverUrl;
  final String? seriesKey;
  final String? episodeSlug;
  QueueStatus status;
  String? error;
  int progress;

  Map<String, dynamic> toJson() => {
    'id': id, 'episodeTitle': episodeTitle, 'quality': quality,
    'animeTitle': animeTitle, 'coverUrl': coverUrl, 'seriesKey': seriesKey,
    'episodeSlug': episodeSlug, 'status': status.name, 'error': error,
    'progress': progress,
    'links': [for (final l in links) {'quality': l.quality, 'link': l.link, 'host': l.host}],
  };

  factory QueueItem.fromJson(Map<String, dynamic> j) => QueueItem(
    id: '${j['id'] ?? ''}',
    episodeTitle: '${j['episodeTitle'] ?? ''}',
    quality: '${j['quality'] ?? ''}',
    animeTitle: '${j['animeTitle'] ?? ''}',
    coverUrl: '${j['coverUrl'] ?? ''}',
    seriesKey: j['seriesKey']?.toString(),
    episodeSlug: j['episodeSlug']?.toString(),
    status: QueueStatus.values.firstWhere((e) => e.name == '${j['status']}', orElse: () => QueueStatus.pending),
    error: j['error']?.toString(),
    progress: (j['progress'] is int) ? j['progress'] as int : int.tryParse('${j['progress']}') ?? 0,
    links: [
      for (final e in (j['links'] is List ? j['links'] as List : const []))
        if (e is Map) DlLink(quality: '${e['quality'] ?? ''}', link: '${e['link'] ?? ''}', host: '${e['host'] ?? ''}'),
    ],
  );
}


// =============================================================================
// Acefile.co → Google Drive direct link
// =============================================================================

class AcefileResolver {
  static String? fileIdFromUrl(String url) {
    final u = Uri.tryParse(url);
    if (u == null) return null;
    if (!u.host.toLowerCase().contains('acefile')) return null;
    final segs = u.pathSegments.where((s) => s.isNotEmpty).toList();
    // /f/{id}/... or /player/{id}
    if (segs.length >= 2 && (segs[0] == 'f' || segs[0] == 'player')) {
      return segs[1];
    }
    if (segs.isNotEmpty && RegExp(r'^\d+$').hasMatch(segs.first)) {
      return segs.first;
    }
    return null;
  }

  /// Resolve acefile page/API ke link unduhan Google Drive.
  static Future<String?> resolve(String raw) async {
    final url = raw.trim();
    if (url.isEmpty) return null;
    final id = fileIdFromUrl(url);
    if (id == null) return null;

    final ua =
        'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36';

    // 1) API resource_check
    try {
      final res = await http
          .get(
            Uri.parse('https://acefile.co/service/resource_check/$id/'),
            headers: {
              'User-Agent': ua,
              'Accept': 'application/json, text/plain, */*',
              'Referer': url,
            },
          )
          .timeout(const Duration(seconds: 20));
      if (res.statusCode >= 200 && res.statusCode < 300) {
        final body = res.body;
        try {
          final j = jsonDecode(body);
          if (j is Map) {
            final data = j['data'];
            String? driveId;
            if (data is String && data.isNotEmpty) driveId = data;
            if (data is Map) {
              driveId = (data['id'] ?? data['code'] ?? data['file_id'])?.toString();
            }
            if (driveId != null && driveId.isNotEmpty) {
              // bisa base64
              if (!RegExp(r'^[a-zA-Z0-9_-]{10,}$').hasMatch(driveId)) {
                try {
                  driveId = utf8.decode(base64.decode(driveId));
                } catch (_) {}
              }
              return 'https://drive.google.com/uc?export=download&id=$driveId';
            }
          }
        } catch (_) {}
        // regex fallback
        final m = RegExp(r'"data"\s*:\s*"([^"]+)"').firstMatch(body);
        if (m != null) {
          var driveId = m.group(1)!;
          try {
            if (driveId.length % 4 == 0) {
              driveId = utf8.decode(base64.decode(driveId));
            }
          } catch (_) {}
          return 'https://drive.google.com/uc?export=download&id=$driveId';
        }
      }
    } catch (_) {}

    // 2) Parse halaman /f/{id}
    try {
      final res = await http
          .get(
            Uri.parse(url.contains('acefile') ? url : 'https://acefile.co/f/$id'),
            headers: {
              'User-Agent': ua,
              'Accept': 'text/html',
              'Referer': 'https://acefile.co/',
            },
          )
          .timeout(const Duration(seconds: 20));
      final body = res.body;
      // packed "code":"BASE64"
      final code = RegExp(r'"code"\s*:\s*"([A-Za-z0-9+/=]+)"').firstMatch(body);
      if (code != null) {
        try {
          final driveId = utf8.decode(base64.decode(code.group(1)!));
          if (driveId.isNotEmpty) {
            return 'https://drive.google.com/uc?export=download&id=$driveId';
          }
        } catch (_) {}
      }
      final gdrive = RegExp(
        r'https?://(?:drive|docs)\.google\.com/(?:file/d/|open\?id=|uc\?[^\s"]*id=)([a-zA-Z0-9_-]+)',
      ).firstMatch(body);
      if (gdrive != null) {
        return 'https://drive.google.com/uc?export=download&id=${gdrive.group(1)}';
      }
    } catch (_) {}

    return null;
  }
}

class DownloadQueue extends ChangeNotifier {
  DownloadQueue._();
  static final DownloadQueue instance = DownloadQueue._();
  static const _baseKey = 'download_queue_v1';
  final List<QueueItem> items = [];
  bool _running = false;
  bool get isRunning => _running;
  Future<String?> Function(String url)? resolveUrl;
  Future<String> _key() => UserDataKeys.of(_baseKey);

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(await _key());
    items.clear();
    if (raw != null && raw.isNotEmpty) {
      try {
        final list = jsonDecode(raw);
        if (list is List) {
          for (final e in list) {
            if (e is Map) {
              final qi = QueueItem.fromJson(Map<String, dynamic>.from(e));
              if (qi.status == QueueStatus.downloading || qi.status == QueueStatus.waiting) {
                qi.status = QueueStatus.pending;
                qi.progress = 0;
              }
              if (qi.status != QueueStatus.done) items.add(qi);
            }
          }
        }
      } catch (_) {}
    }
    notifyListeners();
  }

  Future<void> _persist() async {
    final p = await SharedPreferences.getInstance();
    await p.setString(await _key(), jsonEncode(items.map((e) => e.toJson()).toList()));
  }

  Future<void> enqueue(QueueItem item) async {
    if (items.any((e) => e.id == item.id && e.status != QueueStatus.failed)) return;
    items.add(item);
    await _persist();
    notifyListeners();
    unawaited(pump());
  }

  Future<void> enqueueMany(List<QueueItem> list) async {
    for (final item in list) {
      if (items.any((e) => e.id == item.id && e.status != QueueStatus.failed)) continue;
      items.add(item);
    }
    await _persist();
    notifyListeners();
    unawaited(pump());
  }

  Future<void> cancel(String id) async {
    final i = items.indexWhere((e) => e.id == id);
    if (i < 0) return;
    if (items[i].status == QueueStatus.downloading) {
      items[i].status = QueueStatus.cancelled;
    } else {
      items.removeAt(i);
    }
    await _persist();
    notifyListeners();
  }

  Future<void> clearFinished() async {
    items.removeWhere((e) => e.status == QueueStatus.done || e.status == QueueStatus.cancelled || e.status == QueueStatus.failed);
    await _persist();
    notifyListeners();
  }

  Future<void> pump() async {
    if (_running) return;
    _running = true;
    notifyListeners();
    try {
      while (true) {
        QueueItem? next;
        for (final e in items) {
          if (e.status == QueueStatus.pending) { next = e; break; }
        }
        if (next == null) break;
        await _process(next);
      }
    } finally {
      _running = false;
      notifyListeners();
    }
  }

  Future<void> _process(QueueItem item) async {
    item.status = QueueStatus.waiting;
    item.progress = 0;
    notifyListeners();
    await _persist();
    item.status = QueueStatus.downloading;
    notifyListeners();
    Object? lastError;
    try {
      // Batch / acefile dulu, lalu filedon, lalu lainnya
      final ace = [
        for (final l in item.links)
          if ((l.host.toLowerCase().contains('acefile') ||
                  l.link.toLowerCase().contains('acefile')) &&
              l.link.isNotEmpty)
            l,
      ];
      final filedon = [
        for (final l in item.links)
          if (l.host.toLowerCase().contains('filedon') && l.link.isNotEmpty) l,
      ];
      final list = <DlLink>[
        ...ace,
        ...filedon,
        for (final l in item.links)
          if (l.link.isNotEmpty && !ace.contains(l) && !filedon.contains(l)) l,
      ];
      for (final pick in list) {
        try {
          var resolved = pick.link;
          // Acefile → Google Drive direct
          if (pick.host.toLowerCase().contains('acefile') ||
              pick.link.toLowerCase().contains('acefile')) {
            final aceUrl = await AcefileResolver.resolve(pick.link);
            if (aceUrl != null && aceUrl.isNotEmpty) resolved = aceUrl;
          } else if (resolveUrl != null) {
            final r = await resolveUrl!(pick.link);
            if (r != null && r.isNotEmpty) resolved = r;
          }
          final offlineDir = await resolveOfflineMediaDir(sub: 'anime');
          final safeName = _safeName('${item.episodeTitle}_${item.quality}');
          final result = await saveRemoteFile(
            url: resolved,
            fileName: safeName,
            notificationTitle: 'Queue: ${item.episodeTitle}',
            notify: true,
            notifyOnFailure: false,
            targetDir: offlineDir,
            onProgress: (pct) { item.progress = pct; notifyListeners(); },
            headers: {
              'Referer': pick.link,
              'Accept': 'video/*,application/octet-stream,*/*',
              'User-Agent': 'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36',
            },
          );
          final f = File(result.file.path);
          if (!await f.exists() || await f.length() < 50 * 1024) {
            try { await f.delete(); } catch (_) {}
            throw Exception('File unduhan tidak valid');
          }
          final owner = await SessionStore.getUsername() ?? '';
          await OfflineIndex.register(
            key: 'anime:${item.episodeSlug ?? item.episodeTitle}:${item.quality}',
            filePath: result.file.path,
            title: '${item.episodeTitle} (${item.quality})',
            owner: owner,
            animeTitle: item.animeTitle,
            coverUrl: item.coverUrl,
            seriesKey: item.seriesKey,
          );
          item.status = QueueStatus.done;
          item.progress = 100;
          await _persist();
          notifyListeners();
          return;
        } catch (e) {
          lastError = e;
        }
      }
      item.status = QueueStatus.failed;
      item.error = '$lastError'.replaceFirst('Exception: ', '');
    } catch (e) {
      item.status = QueueStatus.failed;
      item.error = e.toString().replaceFirst('Exception: ', '');
    }
    await _persist();
    notifyListeners();
  }

  static String _safeName(String raw) {
    final base = raw.replaceAll(RegExp(r'[^a-zA-Z0-9._\-\s]+'), '').trim().replaceAll(RegExp(r'\s+'), '_');
    final name = '${base.isEmpty ? 'anime' : base}.mp4';
    return name.length > 80 ? '${name.substring(0, 76)}.mp4' : name;
  }

  int get pendingCount => items.where((e) =>
      e.status == QueueStatus.pending || e.status == QueueStatus.waiting || e.status == QueueStatus.downloading).length;
}

class WatchStatsStore {
  static const _baseKey = 'watch_stats_v1';
  static Future<String> _key() => UserDataKeys.of(_baseKey);

  static Future<Map<String, dynamic>> _all() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(await _key());
    if (raw == null || raw.isEmpty) return {'totalSeconds': 0, 'episodesDone': <String>[], 'seriesDone': <String>[]};
    try {
      final d = jsonDecode(raw);
      if (d is Map) return Map<String, dynamic>.from(d);
    } catch (_) {}
    return {'totalSeconds': 0, 'episodesDone': <String>[], 'seriesDone': <String>[]};
  }

  static Future<void> _write(Map<String, dynamic> data) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(await _key(), jsonEncode(data));
  }

  static Future<void> addWatchSeconds(int sec) async {
    if (sec <= 0) return;
    final all = await _all();
    final cur = (all['totalSeconds'] is int) ? all['totalSeconds'] as int : int.tryParse('${all['totalSeconds']}') ?? 0;
    all['totalSeconds'] = cur + sec;
    await _write(all);
  }

  static Future<void> markEpisodeDone(String episodeKey) async {
    final all = await _all();
    final list = [for (final e in (all['episodesDone'] is List ? all['episodesDone'] as List : const [])) '$e'];
    if (!list.contains(episodeKey)) { list.add(episodeKey); all['episodesDone'] = list; await _write(all); }
  }

  static Future<void> markSeriesDone(String seriesKey) async {
    final all = await _all();
    final list = [for (final e in (all['seriesDone'] is List ? all['seriesDone'] as List : const [])) '$e'];
    if (!list.contains(seriesKey)) { list.add(seriesKey); all['seriesDone'] = list; await _write(all); }
  }

  static Future<WatchStats> snapshot() async {
    final all = await _all();
    final totalSec = (all['totalSeconds'] is int) ? all['totalSeconds'] as int : int.tryParse('${all['totalSeconds']}') ?? 0;
    final eps = (all['episodesDone'] is List) ? (all['episodesDone'] as List).length : 0;
    final series = (all['seriesDone'] is List) ? (all['seriesDone'] as List).length : 0;
    int bytes = 0;
    try {
      final offline = await OfflineIndex.listAll();
      for (final e in offline) {
        final path = '${e['path'] ?? ''}';
        if (path.isEmpty) continue;
        final f = File(path);
        if (await f.exists()) bytes += await f.length();
      }
    } catch (_) {}
    return WatchStats(totalSeconds: totalSec, episodesDone: eps, seriesDone: series, offlineBytes: bytes);
  }
}

class WatchStats {
  const WatchStats({required this.totalSeconds, required this.episodesDone, required this.seriesDone, required this.offlineBytes});
  final int totalSeconds;
  final int episodesDone;
  final int seriesDone;
  final int offlineBytes;
  String get hoursLabel {
    final h = totalSeconds / 3600;
    if (h < 1) return '${(totalSeconds / 60).floor()} menit';
    return '${h.toStringAsFixed(1)} jam';
  }
  String get storageLabel {
    if (offlineBytes < 1024 * 1024) return '${(offlineBytes / 1024).toStringAsFixed(0)} KB';
    if (offlineBytes < 1024 * 1024 * 1024) return '${(offlineBytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    return '${(offlineBytes / (1024 * 1024 * 1024)).toStringAsFixed(2)} GB';
  }
}

class WidgetBridge {
  static const _channel = MethodChannel('kiryo.nime/widget');
  static Future<void> update({List<String>? favoriteLines, int? favoriteCount}) async {
    try {
      final cont = await WatchProgressStore.continueList(max: 3);
      final p = await SharedPreferences.getInstance();
      if (favoriteLines != null) await p.setString('widget_favorites_lines', favoriteLines.join('\n'));
      if (favoriteCount != null) await p.setInt('widget_favorites_count', favoriteCount);
      if (cont.isNotEmpty) {
        final c = cont.first;
        await p.setString('widget_continue_title', '${c['animeTitle'] ?? c['title'] ?? ''}');
        await p.setString('widget_continue_ep', '${c['episodeTitle'] ?? ''}');
        final ratio = (c['ratio'] is num) ? (c['ratio'] as num).toDouble() : 0.0;
        await p.setDouble('widget_continue_ratio', ratio);
      }
      try { await _channel.invokeMethod('updateWidget'); } catch (_) {}
    } catch (_) {}
  }
}

class DownloadQueuePage extends StatefulWidget {
  const DownloadQueuePage({super.key});
  @override
  State<DownloadQueuePage> createState() => _DownloadQueuePageState();
}

class _DownloadQueuePageState extends State<DownloadQueuePage> {
  final q = DownloadQueue.instance;
  @override
  void initState() {
    super.initState();
    q.addListener(_on);
    q.load().then((_) => q.pump());
  }
  void _on() { if (mounted) setState(() {}); }
  @override
  void dispose() { q.removeListener(_on); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF17121F),
      appBar: AppBar(
        backgroundColor: Colors.black54, foregroundColor: Colors.white,
        title: const Text('Antrian unduhan', style: TextStyle(fontWeight: FontWeight.w800)),
        actions: [
          if (q.items.any((e) => e.status == QueueStatus.done || e.status == QueueStatus.failed || e.status == QueueStatus.cancelled))
            TextButton(onPressed: () => q.clearFinished(), child: const Text('Bersihkan', style: TextStyle(color: Color(0xFFFFD88A)))),
        ],
      ),
      body: q.items.isEmpty
        ? const Center(child: Text('Antrian kosong', style: TextStyle(color: Colors.white54)))
        : ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: q.items.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (ctx, i) {
              final it = q.items[i];
              final label = switch (it.status) {
                QueueStatus.pending => 'Menunggu',
                QueueStatus.waiting => 'Konfirmasi unduh…',
                QueueStatus.downloading => 'Mengunduh ${it.progress}%',
                QueueStatus.done => 'Selesai',
                QueueStatus.failed => 'Gagal${it.error != null ? ': ${it.error}' : ''}',
                QueueStatus.cancelled => 'Dibatalkan',
              };
              return Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(color: const Color(0xFF241C2C), borderRadius: BorderRadius.circular(14), border: Border.all(color: Colors.white10)),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Expanded(child: Text(it.episodeTitle, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700))),
                    if (it.status == QueueStatus.pending || it.status == QueueStatus.failed)
                      IconButton(icon: const Icon(Icons.close, color: Colors.white54, size: 18), onPressed: () => q.cancel(it.id)),
                  ]),
                  if (it.animeTitle.isNotEmpty) Text(it.animeTitle, style: const TextStyle(color: Colors.white54, fontSize: 12)),
                  const SizedBox(height: 6),
                  Text('${it.quality} · $label', style: const TextStyle(color: Color(0xFFFFD88A), fontSize: 12, fontWeight: FontWeight.w600)),
                  if (it.status == QueueStatus.downloading || it.status == QueueStatus.waiting) ...[
                    const SizedBox(height: 8),
                    LinearProgressIndicator(value: it.status == QueueStatus.waiting ? null : (it.progress / 100).clamp(0.0, 1.0), backgroundColor: Colors.white12, color: const Color(0xFFFFD88A)),
                  ],
                ]),
              );
            },
          ),
    );
  }
}

class StatsPage extends StatefulWidget {
  const StatsPage({super.key});
  @override
  State<StatsPage> createState() => _StatsPageState();
}

class _StatsPageState extends State<StatsPage> {
  WatchStats? _stats;
  bool _loading = true;
  @override
  void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final s = await WatchStatsStore.snapshot();
    if (!mounted) return;
    setState(() { _stats = s; _loading = false; });
  }
  @override
  Widget build(BuildContext context) {
    final s = _stats;
    return Scaffold(
      backgroundColor: const Color(0xFF17121F),
      appBar: AppBar(backgroundColor: Colors.black54, foregroundColor: Colors.white, title: const Text('Statistik', style: TextStyle(fontWeight: FontWeight.w800))),
      body: _loading
        ? const Center(child: CircularProgressIndicator(color: Color(0xFFFFD88A)))
        : ListView(padding: const EdgeInsets.all(16), children: [
            _card(Icons.schedule_rounded, 'Total nonton', s?.hoursLabel ?? '0'),
            const SizedBox(height: 12),
            _card(Icons.play_circle_outline, 'Episode selesai', '${s?.episodesDone ?? 0}'),
            const SizedBox(height: 12),
            _card(Icons.video_library_outlined, 'Serial selesai', '${s?.seriesDone ?? 0}'),
            const SizedBox(height: 12),
            _card(Icons.folder_outlined, 'Storage offline', s?.storageLabel ?? '0'),
          ]),
    );
  }
  Widget _card(IconData icon, String label, String value) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(color: const Color(0xFF241C2C), borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.white10)),
      child: Row(children: [
        Icon(icon, color: const Color(0xFFFFD88A), size: 28),
        const SizedBox(width: 14),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: const TextStyle(color: Colors.white54, fontSize: 12)),
          const SizedBox(height: 4),
          Text(value, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800)),
        ])),
      ]),
    );
  }
}
