import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';

import 'api_config.dart';
import 'api_sync.dart';
import 'avatar_crop.dart';
import 'avatar_persist.dart';
import 'login.dart';
import 'manga.dart';
import 'net_status.dart';
import 'session.dart';
import 'smart_image.dart';

class AccountPage extends StatefulWidget {
  const AccountPage({super.key});

  @override
  State<AccountPage> createState() => _AccountPageState();
}

class _AccountPageState extends State<AccountPage> {
  final _username = TextEditingController();
  final _oldPass = TextEditingController();
  final _newPass = TextEditingController();
  final _confirmPass = TextEditingController();

  String _avatar = SessionStore.defaultAvatar;
  String _initialUsername = '';
  String _initialAvatar = SessionStore.defaultAvatar;
  String _email = '';
  String _createdAt = '';
  String _lastLoginAt = '';

  bool _obscureOld = true;
  bool _obscureNew = true;
  bool _obscureConfirm = true;
  bool _loading = true;
  bool _saving = false;
  bool _changingPass = false;
  bool _online = true;
  bool _checkingNet = false;

  // Preferensi
  bool _notifChapter = true;
  bool _notifComment = true;
  String _orientation = 'system';

  bool get _isDefaultAvatar =>
      _avatar.isEmpty ||
      _avatar == SessionStore.defaultAvatar ||
      _avatar.startsWith('assets/');

  @override
  void initState() {
    super.initState();
    for (final c in [_username, _oldPass, _newPass, _confirmPass]) {
      c.addListener(() {
        if (mounted) setState(() {});
      });
    }
    _load();
    _checkNet();
  }

  Future<void> _checkNet() async {
    if (_checkingNet) return;
    setState(() => _checkingNet = true);
    final ok = await NetStatus.hasConnection();
    if (!mounted) return;
    setState(() {
      _online = ok;
      _checkingNet = false;
    });
  }

  Future<void> _load() async {
    final username = await SessionStore.getUsername();
    var avatar = await SessionStore.getAvatar(username: username);
    final missingLocal = avatar.startsWith('assets/') ||
        (!avatar.startsWith('assets/') && !(await File(avatar).exists()));
    if (username != null && username.isNotEmpty && missingLocal) {
      final restored = await AvatarPersist.restore(username);
      if (restored != null) avatar = restored;
    }

    final email = await SessionStore.getEmail() ?? '';
    final notifC = await AppPrefs.getNotifChapter();
    final notifM = await AppPrefs.getNotifComment();
    final orient = await AppPrefs.getOrientation();

    // Info akun dari server
    String created = '', lastLogin = '', serverEmail = email;
    try {
      final token = await SessionStore.getToken();
      if (token != null && token.isNotEmpty) {
        final res = await http
            .get(
              Uri.parse('$apiBaseUrl/api/me'),
              headers: {
                'Authorization': 'Bearer $token',
                'Accept': 'application/json',
              },
            )
            .timeout(const Duration(seconds: 15));
        if (res.statusCode >= 200 && res.statusCode < 300) {
          final body = jsonDecode(res.body);
          if (body is Map && body['ok'] == true && body['user'] is Map) {
            final u = body['user'] as Map;
            created = u['createdAt']?.toString() ?? '';
            lastLogin = u['lastLoginAt']?.toString() ?? '';
            final em = u['email']?.toString();
            if (em != null && em.isNotEmpty) serverEmail = em;
          }
        }
      }
    } catch (_) {}

    if (!mounted) return;
    setState(() {
      _username.text = username ?? 'Pengguna';
      _avatar = avatar;
      _initialUsername = _username.text;
      _initialAvatar = avatar;
      _email = serverEmail;
      _createdAt = created;
      _lastLoginAt = lastLogin;
      _notifChapter = notifC;
      _notifComment = notifM;
      _orientation = orient;
      _loading = false;
    });
  }

  bool get _hasChanges {
    return _username.text.trim() != _initialUsername.trim() ||
        _avatar != _initialAvatar;
  }

  @override
  void dispose() {
    _username.dispose();
    _oldPass.dispose();
    _newPass.dispose();
    _confirmPass.dispose();
    super.dispose();
  }

  // ─── Format tanggal ───────────────────────────────────────────
  String _fmtDate(String iso) {
    if (iso.isEmpty) return '—';
    try {
      final d = DateTime.parse(iso).toLocal();
      final dd = d.day.toString().padLeft(2, '0');
      final mm = d.month.toString().padLeft(2, '0');
      final yy = d.year.toString();
      final hh = d.hour.toString().padLeft(2, '0');
      final mi = d.minute.toString().padLeft(2, '0');
      return '$dd/$mm/$yy $hh:$mi';
    } catch (_) {
      return iso.length > 16 ? iso.substring(0, 16).replaceFirst('T', ' ') : iso;
    }
  }

  // ─── Kekuatan password ────────────────────────────────────────
  int _passStrength(String s) {
    if (s.isEmpty) return 0;
    var score = 0;
    if (s.length >= 4) score++;
    if (s.length >= 8) score++;
    if (RegExp(r'[A-Z]').hasMatch(s) && RegExp(r'[a-z]').hasMatch(s)) score++;
    if (RegExp(r'[0-9]').hasMatch(s)) score++;
    if (RegExp(r'[^A-Za-z0-9]').hasMatch(s)) score++;
    return score.clamp(0, 4);
  }

  String _passLabel(int s) {
    switch (s) {
      case 0:
        return '';
      case 1:
        return 'Lemah';
      case 2:
        return 'Cukup';
      case 3:
        return 'Kuat';
      default:
        return 'Sangat kuat';
    }
  }

  Color _passColor(int s) {
    switch (s) {
      case 1:
        return Colors.redAccent;
      case 2:
        return Colors.orangeAccent;
      case 3:
        return Colors.lightGreenAccent;
      case 4:
        return const Color(0xFF4ADE80);
      default:
        return Colors.white24;
    }
  }

  // ─── Dialog konfirmasi umum ───────────────────────────────────
  Future<bool> _confirmDialog({
    required String title,
    required String message,
    String cancelLabel = 'Batal',
    String okLabel = 'Oke',
    Color? okColor,
  }) async {
    final result = await showGeneralDialog<bool>(
      context: context,
      barrierDismissible: true,
      barrierLabel: 'Tutup',
      barrierColor: Colors.black.withOpacity(0.62),
      transitionDuration: const Duration(milliseconds: 280),
      pageBuilder: (ctx, _, __) => const SizedBox.shrink(),
      transitionBuilder: (ctx, anim, _, __) {
        final curved = CurvedAnimation(parent: anim, curve: Curves.easeOutCubic);
        return FadeTransition(
          opacity: curved,
          child: ScaleTransition(
            scale: Tween<double>(begin: 0.88, end: 1).animate(curved),
            child: Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 28),
                child: Material(
                  color: Colors.transparent,
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.fromLTRB(22, 22, 22, 16),
                    decoration: BoxDecoration(
                      color: const Color(0xFF231A2E),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: const Color(0xFFFFD88A).withOpacity(0.35),
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.4),
                          blurRadius: 24,
                          offset: const Offset(0, 10),
                        ),
                      ],
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          title,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w800,
                            fontSize: 18,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          message,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            color: Colors.white70,
                            fontSize: 14,
                            height: 1.35,
                          ),
                        ),
                        const SizedBox(height: 20),
                        Row(
                          children: [
                            Expanded(
                              child: SizedBox(
                                height: 44,
                                child: OutlinedButton(
                                  onPressed: () => Navigator.of(ctx).pop(false),
                                  style: OutlinedButton.styleFrom(
                                    foregroundColor: Colors.white,
                                    side: const BorderSide(color: Colors.white38),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                  ),
                                  child: Text(
                                    cancelLabel,
                                    style: const TextStyle(fontWeight: FontWeight.w800),
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: SizedBox(
                                height: 44,
                                child: ElevatedButton(
                                  onPressed: () => Navigator.of(ctx).pop(true),
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor:
                                        okColor ?? const Color(0xFFFFD88A),
                                    foregroundColor: okColor != null
                                        ? Colors.white
                                        : const Color(0xFF17121F),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                  ),
                                  child: Text(
                                    okLabel,
                                    style: const TextStyle(fontWeight: FontWeight.w800),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
    return result == true;
  }

  // ─── Preview foto profil + tombol hapus ───────────────────────
  Future<void> _openAvatarPreview() async {
    await showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: 'Tutup',
      barrierColor: Colors.black.withOpacity(0.78),
      transitionDuration: const Duration(milliseconds: 260),
      pageBuilder: (ctx, _, __) => const SizedBox.shrink(),
      transitionBuilder: (ctx, anim, _, __) {
        final curved = CurvedAnimation(parent: anim, curve: Curves.easeOutCubic);
        return FadeTransition(
          opacity: curved,
          child: ScaleTransition(
            scale: Tween<double>(begin: 0.9, end: 1).animate(curved),
            child: Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: Material(
                  color: Colors.transparent,
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.fromLTRB(18, 18, 18, 14),
                    decoration: BoxDecoration(
                      color: const Color(0xFF231A2E),
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(
                        color: const Color(0xFFFFD88A).withOpacity(0.3),
                      ),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Text(
                          'Foto profil',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w800,
                            fontSize: 16,
                          ),
                        ),
                        const SizedBox(height: 14),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(16),
                          child: SizedBox(
                            width: 220,
                            height: 220,
                            child: _avatarImage(_avatar, size: 220),
                          ),
                        ),
                        const SizedBox(height: 16),
                        if (!_isDefaultAvatar)
                          SizedBox(
                            width: double.infinity,
                            height: 46,
                            child: ElevatedButton.icon(
                              onPressed: () async {
                                Navigator.of(ctx).pop();
                                await _removeAvatar();
                              },
                              icon: const Icon(Icons.delete_outline_rounded),
                              label: const Text(
                                'Hapus foto profil',
                                style: TextStyle(fontWeight: FontWeight.w800),
                              ),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFFE85D5D),
                                foregroundColor: Colors.white,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                              ),
                            ),
                          ),
                        if (!_isDefaultAvatar) const SizedBox(height: 8),
                        SizedBox(
                          width: double.infinity,
                          height: 44,
                          child: TextButton(
                            onPressed: () => Navigator.of(ctx).pop(),
                            child: const Text(
                              'Tutup',
                              style: TextStyle(
                                color: Colors.white70,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Future<void> _removeAvatar() async {
    final ok = await _confirmDialog(
      title: 'Hapus foto profil?',
      message:
          'Foto profil akan diganti ke default. Tindakan ini tidak bisa dibatalkan.',
      cancelLabel: 'Batal',
      okLabel: 'Oke',
      okColor: const Color(0xFFE85D5D),
    );
    if (!ok || !mounted) return;

    final username = _username.text.trim().isNotEmpty
        ? _username.text.trim()
        : (await SessionStore.getUsername() ?? 'user');

    // Hapus file lokal jika ada
    final old = _avatar;
    if (!old.startsWith('assets/') && old.isNotEmpty) {
      try {
        final f = File(old);
        if (f.existsSync()) f.deleteSync();
      } catch (_) {}
    }

    await SessionStore.setDefaultAvatar(username);
    imageCache.clear();
    imageCache.clearLiveImages();

    // Kosongkan avatar di server
    try {
      final token = await SessionStore.getToken();
      if (token != null && token.isNotEmpty) {
        await http
            .put(
              Uri.parse('$apiBaseUrl/api/me/profile'),
              headers: {
                'Content-Type': 'application/json; charset=utf-8',
                'Authorization': 'Bearer $token',
                'Accept': 'application/json',
              },
              body: jsonEncode({'avatar': ''}),
            )
            .timeout(const Duration(seconds: 20));
      }
    } catch (_) {}

    try {
      await MangaCommentStore.migrateAvatar(username, SessionStore.defaultAvatar);
    } catch (_) {}

    if (!mounted) return;
    setState(() {
      _avatar = SessionStore.defaultAvatar;
      _initialAvatar = SessionStore.defaultAvatar;
    });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Foto profil dihapus')),
    );
  }

  // ─── Simpan username ──────────────────────────────────────────
  Future<void> _save() async {
    final name = _username.text.trim();
    if (name.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Username tidak boleh kosong')),
      );
      return;
    }
    setState(() => _saving = true);
    await SessionStore.updateProfile(
      username: name,
      avatarAsset: _avatar,
    );
    if (!mounted) return;
    setState(() {
      _saving = false;
      _initialUsername = name;
      _initialAvatar = _avatar;
    });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Profil berhasil disimpan')),
    );
  }

  // ─── Ganti password ───────────────────────────────────────────
  Future<void> _changePassword() async {
    final oldP = _oldPass.text;
    final newP = _newPass.text;
    final conf = _confirmPass.text;

    if (oldP.isEmpty || newP.isEmpty || conf.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Isi password lama, baru, dan konfirmasi'),
        ),
      );
      return;
    }
    if (newP.length < 4) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Password baru minimal 4 karakter')),
      );
      return;
    }
    if (newP != conf) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Konfirmasi password tidak cocok')),
      );
      return;
    }

    setState(() => _changingPass = true);
    try {
      final token = await SessionStore.getToken();
      if (token == null || token.isEmpty) {
        throw Exception('Sesi tidak valid, login ulang');
      }
      final res = await http
          .put(
            Uri.parse('$apiBaseUrl/api/me/password'),
            headers: {
              'Content-Type': 'application/json; charset=utf-8',
              'Authorization': 'Bearer $token',
              'Accept': 'application/json',
            },
            body: jsonEncode({
              'oldPassword': oldP,
              'newPassword': newP,
            }),
          )
          .timeout(const Duration(seconds: 20));
      final body = jsonDecode(res.body);
      final msg = body is Map
          ? (body['message']?.toString() ?? '')
          : '';
      if (res.statusCode < 200 || res.statusCode >= 300 || body['ok'] != true) {
        throw Exception(msg.isNotEmpty ? msg : 'Gagal ganti password');
      }
      _oldPass.clear();
      _newPass.clear();
      _confirmPass.clear();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(msg.isNotEmpty ? msg : 'Password berhasil diganti')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(e.toString().replaceFirst('Exception: ', '')),
        ),
      );
    } finally {
      if (mounted) setState(() => _changingPass = false);
    }
  }

  // ─── Hapus akun ───────────────────────────────────────────────
  Future<void> _deleteAccount() async {
    final confirmUser = TextEditingController();
    final confirmPass = TextEditingController();
    var obscure = true;

    final ok = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx, setLocal) {
            return AlertDialog(
              backgroundColor: const Color(0xFF231A2E),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18),
                side: BorderSide(
                  color: const Color(0xFFE85D5D).withOpacity(0.5),
                ),
              ),
              title: const Text(
                'Hapus akun permanen',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w800,
                ),
              ),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Semua data akun (bookmark, history, offline, komentar) akan dihapus dan tidak bisa dikembalikan.',
                      style: TextStyle(color: Colors.white70, fontSize: 13, height: 1.4),
                    ),
                    const SizedBox(height: 14),
                    Text(
                      'Ketik username "${_initialUsername}" untuk konfirmasi:',
                      style: const TextStyle(color: Colors.white60, fontSize: 12),
                    ),
                    const SizedBox(height: 8),
                    TextField(
                      controller: confirmUser,
                      style: const TextStyle(color: Colors.white),
                      decoration: _decoration('Username', Icons.person_outline),
                    ),
                    const SizedBox(height: 10),
                    TextField(
                      controller: confirmPass,
                      obscureText: obscure,
                      style: const TextStyle(color: Colors.white),
                      decoration: _decoration(
                        'Password',
                        Icons.lock_outline,
                        suffix: IconButton(
                          icon: Icon(
                            obscure ? Icons.visibility : Icons.visibility_off,
                            color: Colors.white70,
                          ),
                          onPressed: () => setLocal(() => obscure = !obscure),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(ctx).pop(false),
                  child: const Text('Batal', style: TextStyle(color: Colors.white70)),
                ),
                ElevatedButton(
                  onPressed: () => Navigator.of(ctx).pop(true),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFE85D5D),
                    foregroundColor: Colors.white,
                  ),
                  child: const Text('Hapus akun', style: TextStyle(fontWeight: FontWeight.w800)),
                ),
              ],
            );
          },
        );
      },
    );

    if (ok != true || !mounted) {
      confirmUser.dispose();
      confirmPass.dispose();
      return;
    }

    final typed = confirmUser.text.trim();
    final pass = confirmPass.text;
    confirmUser.dispose();
    confirmPass.dispose();

    if (typed.toLowerCase() != _initialUsername.toLowerCase()) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Username konfirmasi tidak cocok')),
      );
      return;
    }
    if (pass.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Password wajib diisi')),
      );
      return;
    }

    try {
      final token = await SessionStore.getToken();
      if (token == null || token.isEmpty) {
        throw Exception('Sesi tidak valid');
      }
      final res = await http
          .delete(
            Uri.parse('$apiBaseUrl/api/me'),
            headers: {
              'Content-Type': 'application/json; charset=utf-8',
              'Authorization': 'Bearer $token',
              'Accept': 'application/json',
            },
            body: jsonEncode({
              'password': pass,
              'confirmUsername': typed,
            }),
          )
          .timeout(const Duration(seconds: 25));
      final body = jsonDecode(res.body);
      final msg = body is Map ? (body['message']?.toString() ?? '') : '';
      if (res.statusCode < 200 || res.statusCode >= 300 || body['ok'] != true) {
        throw Exception(msg.isNotEmpty ? msg : 'Gagal hapus akun');
      }

      await SessionStore.clear();
      imageCache.clear();
      imageCache.clearLiveImages();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(msg.isNotEmpty ? msg : 'Akun dihapus')),
      );
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const LoginPage()),
        (route) => false,
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(e.toString().replaceFirst('Exception: ', '')),
        ),
      );
    }
  }

  Future<void> _setAvatar(String path) async {
    imageCache.clear();
    imageCache.clearLiveImages();
    final username = _username.text.trim().isNotEmpty
        ? _username.text.trim()
        : (await SessionStore.getUsername() ?? 'user');
    try {
      final saved = await AvatarPersist.writeLocalOnly(
        sourcePath: path,
        username: username,
      );
      if (!mounted) return;
      imageCache.clear();
      imageCache.clearLiveImages();
      setState(() {
        _avatar = saved;
        _initialAvatar = saved;
      });
      unawaited(
        AvatarPersist.persistExisting(localPath: saved, username: username),
      );
      try {
        await MangaCommentStore.migrateAvatar(username, saved);
      } catch (_) {}
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Foto profil diperbarui')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(e.toString().replaceFirst('Exception: ', '')),
        ),
      );
    }
  }

  Future<void> _pickAvatarFromGallery() async {
    final picked = await ImagePicker().pickImage(
      source: ImageSource.gallery,
      maxWidth: 4096,
      imageQuality: 95,
    );
    if (picked == null) return;

    try {
      final directory = await getApplicationDocumentsDirectory();
      final profileDirectory = Directory('${directory.path}/profile');
      if (!profileDirectory.existsSync()) {
        profileDirectory.createSync(recursive: true);
      }

      final name = picked.name;
      final extension = name.contains('.')
          ? name.substring(name.lastIndexOf('.'))
          : (picked.path.contains('.')
              ? picked.path.substring(picked.path.lastIndexOf('.'))
              : '.jpg');

      final tempPath =
          '${profileDirectory.path}/avatar_src_${DateTime.now().millisecondsSinceEpoch}$extension';
      final bytes = await picked.readAsBytes();
      await File(tempPath).writeAsBytes(bytes, flush: true);

      if (!mounted) return;
      final cropped = await Navigator.of(context).push<String>(
        MaterialPageRoute(
          builder: (_) => AvatarCropPage(sourcePath: tempPath),
        ),
      );

      try {
        final t = File(tempPath);
        if (t.existsSync()) t.deleteSync();
      } catch (_) {}

      if (cropped == null || cropped.isEmpty) return;

      final old = _avatar;
      if (!old.startsWith('assets/') && old != cropped) {
        try {
          final f = File(old);
          if (f.existsSync()) f.deleteSync();
        } catch (_) {}
      }

      await _setAvatar(cropped);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Gagal menyimpan foto: $e')),
      );
    }
  }

  Widget _avatarImage(String source, {required double size}) {
    if (source.startsWith('assets/')) {
      return Image.asset(
        source,
        key: ValueKey('asset_$source'),
        width: size,
        height: size,
        fit: BoxFit.cover,
        gaplessPlayback: false,
      );
    }
    final file = File(source);
    if (!file.existsSync()) {
      return Image.asset(
        SessionStore.defaultAvatar,
        width: size,
        height: size,
        fit: BoxFit.cover,
      );
    }
    return Image.file(
      file,
      key: ValueKey('file_${source}_${file.lengthSync()}'),
      width: size,
      height: size,
      fit: BoxFit.cover,
      gaplessPlayback: false,
      errorBuilder: (_, __, ___) => Image.asset(
        SessionStore.defaultAvatar,
        width: size,
        height: size,
        fit: BoxFit.cover,
      ),
    );
  }

  InputDecoration _decoration(String label, IconData icon, {Widget? suffix}) {
    return InputDecoration(
      labelText: label,
      labelStyle: const TextStyle(color: Colors.white70),
      prefixIcon: Icon(icon, color: const Color(0xFFFFD88A)),
      suffixIcon: suffix,
      filled: true,
      fillColor: Colors.white.withOpacity(0.1),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide.none,
      ),
    );
  }


  Widget _sectionTitle(String text, {IconData? icon}) {
    return Padding(
      padding: const EdgeInsets.only(top: 20, bottom: 10),
      child: Row(
        children: [
          if (icon != null) ...[
            Icon(icon, size: 16, color: const Color(0xFFFFD88A)),
            const SizedBox(width: 8),
          ],
          Text(
            text,
            style: const TextStyle(
              color: Color(0xFFFFD88A),
              fontWeight: FontWeight.w800,
              fontSize: 12,
              letterSpacing: 0.8,
            ),
          ),
        ],
      ),
    );
  }

  Widget _infoRow(IconData icon, String label, String value, {bool last = false}) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 10),
          child: Row(
            children: [
              Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(icon, size: 17, color: const Color(0xFFFFD88A)),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  label,
                  style: const TextStyle(color: Colors.white60, fontSize: 13),
                ),
              ),
              const SizedBox(width: 8),
              Flexible(
                child: Text(
                  value,
                  textAlign: TextAlign.right,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        ),
        if (!last)
          Divider(height: 1, thickness: 1, color: Colors.white.withOpacity(0.06)),
      ],
    );
  }

  Widget _card({required List<Widget> children, EdgeInsetsGeometry? padding}) {
    return Container(
      width: double.infinity,
      padding: padding ?? const EdgeInsets.fromLTRB(14, 6, 14, 6),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.055),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.white.withOpacity(0.09)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: children,
      ),
    );
  }

  Widget _primaryBtn({
    required String label,
    required VoidCallback? onPressed,
    required IconData icon,
    bool loading = false,
  }) {
    return SizedBox(
      height: 48,
      child: ElevatedButton.icon(
        onPressed: onPressed,
        icon: loading
            ? const SizedBox(
                width: 18,
                height: 18,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  color: Color(0xFF17121F),
                ),
              )
            : Icon(icon),
        label: Text(label, style: const TextStyle(fontWeight: FontWeight.w800)),
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFFFFD88A),
          foregroundColor: const Color(0xFF17121F),
          disabledBackgroundColor: const Color(0xFFFFD88A).withOpacity(0.5),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          elevation: 0,
        ),
      ),
    );
  }

  Widget _outlineBtn({
    required String label,
    required VoidCallback? onPressed,
    required IconData icon,
    bool loading = false,
  }) {
    return SizedBox(
      height: 48,
      child: OutlinedButton.icon(
        onPressed: onPressed,
        icon: loading
            ? const SizedBox(
                width: 18,
                height: 18,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  color: Color(0xFFFFD88A),
                ),
              )
            : Icon(icon),
        label: Text(label, style: const TextStyle(fontWeight: FontWeight.w800)),
        style: OutlinedButton.styleFrom(
          foregroundColor: const Color(0xFFFFD88A),
          side: const BorderSide(color: Color(0xFFFFD88A)),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        ),
      ),
    );
  }

  Future<void> _confirmLeave() async {
    if (!_hasChanges) {
      if (mounted) Navigator.of(context).pop(false);
      return;
    }
    final ok = await _confirmDialog(
      title: 'Ada perubahan di akunmu',
      message: 'Apakah kamu ingin menyimpan perubahan?',
      cancelLabel: 'Tidak',
      okLabel: 'Ya',
    );
    if (!mounted) return;
    if (ok) {
      await _save();
      if (mounted) Navigator.of(context).pop(true);
    } else {
      Navigator.of(context).pop(false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final strength = _passStrength(_newPass.text);

    return PopScope(
      canPop: !_hasChanges,
      onPopInvokedWithResult: (didPop, _) {
        if (didPop) return;
        _confirmLeave();
      },
      child: Scaffold(
        backgroundColor: const Color(0xFF17121F),
        appBar: AppBar(
          backgroundColor: Colors.black54,
          foregroundColor: Colors.white,
          elevation: 0,
          title: const Text(
            'Account',
            style: TextStyle(fontWeight: FontWeight.w800),
          ),
        ),
        body: !_online
            ? NoConnectionView(onRetry: _checkNet, busy: _checkingNet)
            : _loading
                ? const Center(
                    child: CircularProgressIndicator(color: Color(0xFFFFD88A)),
                  )
                : ListView(
                    padding: const EdgeInsets.fromLTRB(18, 8, 18, 28),
                    children: [
                      // ── Avatar ──
                      _card(
                        padding: const EdgeInsets.fromLTRB(16, 20, 16, 16),
                        children: [
                          Center(
                            child: GestureDetector(
                              onTap: _openAvatarPreview,
                              child: Stack(
                                alignment: Alignment.bottomRight,
                                children: [
                                  ProfileAvatar(
                                    key: ValueKey(_avatar),
                                    path: _avatar,
                                    radius: 52,
                                  ),
                                  Container(
                                    padding: const EdgeInsets.all(6),
                                    decoration: BoxDecoration(
                                      color: const Color(0xFF231A2E),
                                      shape: BoxShape.circle,
                                      border: Border.all(
                                        color: const Color(0xFFFFD88A),
                                        width: 1.5,
                                      ),
                                    ),
                                    child: const Icon(
                                      Icons.zoom_in_rounded,
                                      size: 16,
                                      color: Color(0xFFFFD88A),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(height: 14),
                          Center(
                            child: OutlinedButton.icon(
                              onPressed: _pickAvatarFromGallery,
                              icon: const Icon(Icons.photo_library_outlined, size: 18),
                              label: const Text('Pilih dari galeri'),
                              style: OutlinedButton.styleFrom(
                                foregroundColor: const Color(0xFFFFD88A),
                                side: const BorderSide(color: Color(0xFFFFD88A)),
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 18,
                                  vertical: 10,
                                ),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(22),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),

                      // ── Info akun ──
                      _sectionTitle('INFO AKUN', icon: Icons.info_outline_rounded),
                      _card(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                        children: [
                          _infoRow(Icons.person_outline, 'Username', _initialUsername),
                          _infoRow(
                            Icons.email_outlined,
                            'Email',
                            _email.isEmpty ? '—' : _email,
                          ),
                          _infoRow(
                            Icons.calendar_today_outlined,
                            'Tanggal daftar',
                            _fmtDate(_createdAt),
                          ),
                          _infoRow(
                            Icons.login_rounded,
                            'Login terakhir',
                            _fmtDate(_lastLoginAt),
                            last: true,
                          ),
                        ],
                      ),

                      // ── Profil ──
                      _sectionTitle('PROFIL', icon: Icons.badge_outlined),
                      _card(
                        padding: const EdgeInsets.fromLTRB(14, 14, 14, 14),
                        children: [
                          TextField(
                            controller: _username,
                            style: const TextStyle(color: Colors.white),
                            decoration: _decoration(
                              'Username / nama akun',
                              Icons.person_outline,
                            ),
                          ),
                          const SizedBox(height: 12),
                          _primaryBtn(
                            label: _saving ? 'Menyimpan...' : 'Simpan profil',
                            icon: Icons.save_rounded,
                            loading: _saving,
                            onPressed: _saving ? null : _save,
                          ),
                        ],
                      ),

                      // ── Keamanan ──
                      _sectionTitle('KEAMANAN', icon: Icons.shield_outlined),
                      _card(
                        padding: const EdgeInsets.fromLTRB(14, 14, 14, 14),
                        children: [
                          TextField(
                            controller: _oldPass,
                            style: const TextStyle(color: Colors.white),
                            obscureText: _obscureOld,
                            decoration: _decoration(
                              'Password lama',
                              Icons.lock_outline,
                              suffix: IconButton(
                                icon: Icon(
                                  _obscureOld
                                      ? Icons.visibility
                                      : Icons.visibility_off,
                                  color: Colors.white70,
                                ),
                                onPressed: () =>
                                    setState(() => _obscureOld = !_obscureOld),
                              ),
                            ),
                          ),
                          const SizedBox(height: 10),
                          TextField(
                            controller: _newPass,
                            style: const TextStyle(color: Colors.white),
                            obscureText: _obscureNew,
                            decoration: _decoration(
                              'Password baru',
                              Icons.lock_reset_rounded,
                              suffix: IconButton(
                                icon: Icon(
                                  _obscureNew
                                      ? Icons.visibility
                                      : Icons.visibility_off,
                                  color: Colors.white70,
                                ),
                                onPressed: () =>
                                    setState(() => _obscureNew = !_obscureNew),
                              ),
                            ),
                          ),
                          if (_newPass.text.isNotEmpty) ...[
                            const SizedBox(height: 10),
                            Row(
                              children: List.generate(4, (i) {
                                return Expanded(
                                  child: Container(
                                    height: 4,
                                    margin: EdgeInsets.only(right: i < 3 ? 4 : 0),
                                    decoration: BoxDecoration(
                                      color: i < strength
                                          ? _passColor(strength)
                                          : Colors.white12,
                                      borderRadius: BorderRadius.circular(2),
                                    ),
                                  ),
                                );
                              }),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              _passLabel(strength),
                              style: TextStyle(
                                color: _passColor(strength),
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                          const SizedBox(height: 10),
                          TextField(
                            controller: _confirmPass,
                            style: const TextStyle(color: Colors.white),
                            obscureText: _obscureConfirm,
                            decoration: _decoration(
                              'Konfirmasi password baru',
                              Icons.lock_person_outlined,
                              suffix: IconButton(
                                icon: Icon(
                                  _obscureConfirm
                                      ? Icons.visibility
                                      : Icons.visibility_off,
                                  color: Colors.white70,
                                ),
                                onPressed: () => setState(
                                  () => _obscureConfirm = !_obscureConfirm,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 12),
                          _outlineBtn(
                            label: _changingPass ? 'Memproses...' : 'Ganti password',
                            icon: Icons.key_rounded,
                            loading: _changingPass,
                            onPressed: _changingPass ? null : _changePassword,
                          ),
                        ],
                      ),

                      // ── Pengaturan ──
                      _sectionTitle('PENGATURAN', icon: Icons.tune_rounded),
                      _card(
                        padding: const EdgeInsets.fromLTRB(14, 12, 14, 8),
                        children: [
                          const Text(
                            'Orientasi layar',
                            style: TextStyle(
                              color: Colors.white70,
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          const SizedBox(height: 10),
                          Row(
                            children: [
                              Expanded(
                                child: _orientChip(
                                  'system',
                                  'Otomatis',
                                  Icons.screen_rotation_rounded,
                                ),
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: _orientChip(
                                  'portrait',
                                  'Potrait',
                                  Icons.stay_current_portrait,
                                ),
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: _orientChip(
                                  'landscape',
                                  'Landscape',
                                  Icons.stay_current_landscape,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Divider(color: Colors.white.withOpacity(0.06)),
                          SwitchListTile(
                            contentPadding: EdgeInsets.zero,
                            title: const Text(
                              'Chapter baru di bookmark',
                              style: TextStyle(color: Colors.white, fontSize: 14),
                            ),
                            subtitle: const Text(
                              'Beritahu jika ada chapter baru',
                              style: TextStyle(color: Colors.white54, fontSize: 12),
                            ),
                            activeTrackColor: const Color(0xFFFFD88A),
                            activeThumbColor: Colors.white,
                            value: _notifChapter,
                            onChanged: (v) async {
                              setState(() => _notifChapter = v);
                              await AppPrefs.setNotifChapter(v);
                              await ApiSync.pushSettings({
                                'notifChapter': v,
                                'notifComment': _notifComment,
                              });
                            },
                          ),
                          SwitchListTile(
                            contentPadding: EdgeInsets.zero,
                            title: const Text(
                              'Balasan komentar',
                              style: TextStyle(color: Colors.white, fontSize: 14),
                            ),
                            subtitle: const Text(
                              'Beritahu jika ada balasan',
                              style: TextStyle(color: Colors.white54, fontSize: 12),
                            ),
                            activeTrackColor: const Color(0xFFFFD88A),
                            activeThumbColor: Colors.white,
                            value: _notifComment,
                            onChanged: (v) async {
                              setState(() => _notifComment = v);
                              await AppPrefs.setNotifComment(v);
                              await ApiSync.pushSettings({
                                'notifChapter': _notifChapter,
                                'notifComment': v,
                              });
                            },
                          ),
                        ],
                      ),

                      
                      _sectionTitle('AKUN', icon: Icons.manage_accounts_outlined),
                      _card(
                        padding: const EdgeInsets.fromLTRB(8, 4, 8, 4),
                        children: [
                          ListTile(
                            onTap: () async {
                              await SessionStore.clear();
                              imageCache.clear();
                              imageCache.clearLiveImages();
                              if (!mounted) return;
                              Navigator.of(context).pushAndRemoveUntil(
                                MaterialPageRoute(
                                  builder: (_) => const LoginPage(),
                                ),
                                (route) => false,
                              );
                            },
                            leading: Container(
                              width: 38,
                              height: 38,
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.06),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: const Icon(
                                Icons.logout_rounded,
                                color: Colors.white70,
                                size: 20,
                              ),
                            ),
                            title: const Text(
                              'Keluar',
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w700,
                                fontSize: 14,
                              ),
                            ),
                            subtitle: const Text(
                              'Logout dari akun ini',
                              style: TextStyle(color: Colors.white54, fontSize: 12),
                            ),
                            trailing: const Icon(
                              Icons.chevron_right_rounded,
                              color: Colors.white38,
                            ),
                          ),
                          Divider(height: 1, color: Colors.white.withOpacity(0.06)),
                          ListTile(
                            onTap: _deleteAccount,
                            leading: Container(
                              width: 38,
                              height: 38,
                              decoration: BoxDecoration(
                                color: const Color(0xFFE85D5D).withOpacity(0.12),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: const Icon(
                                Icons.delete_forever_rounded,
                                color: Color(0xFFE85D5D),
                                size: 20,
                              ),
                            ),
                            title: const Text(
                              'Hapus akun',
                              style: TextStyle(
                                color: Color(0xFFE85D5D),
                                fontWeight: FontWeight.w700,
                                fontSize: 14,
                              ),
                            ),
                            subtitle: const Text(
                              'Hapus permanen semua data akun',
                              style: TextStyle(color: Colors.white54, fontSize: 12),
                            ),
                            trailing: const Icon(
                              Icons.chevron_right_rounded,
                              color: Color(0xFFE85D5D),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                    ],
                  ),
      ),
    );
  }

  Widget _orientChip(String value, String label, IconData icon) {
    final selected = _orientation == value;
    return Material(
      color: selected
          ? const Color(0xFFFFD88A)
          : Colors.white.withOpacity(0.07),
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () async {
          setState(() => _orientation = value);
          await AppPrefs.setOrientation(value);
          if (value == 'portrait') {
            await SystemChrome.setPreferredOrientations([
              DeviceOrientation.portraitUp,
              DeviceOrientation.portraitDown,
            ]);
          } else if (value == 'landscape') {
            await SystemChrome.setPreferredOrientations([
              DeviceOrientation.landscapeLeft,
              DeviceOrientation.landscapeRight,
            ]);
          } else {
            await SystemChrome.setPreferredOrientations(
              DeviceOrientation.values,
            );
          }
        },
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 6),
          child: Column(
            children: [
              Icon(
                icon,
                size: 18,
                color: selected ? const Color(0xFF17121F) : Colors.white70,
              ),
              const SizedBox(height: 4),
              Text(
                label,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: selected ? const Color(0xFF17121F) : Colors.white,
                  fontWeight: FontWeight.w700,
                  fontSize: 11,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
