import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

// ============================================================
// GANTI 3 BARIS INI SESUAI PROJECT KAMU
// ============================================================
const String kWelcomeLogoAsset = 'assets/images/logo_kiryo.png'; // path logo di project kamu
const String kWelcomeTiktokUrl = 'https://www.tiktok.com/@kiryomanz';
const String kWelcomeTelegramUrl = 'https://t.me/kiryochannel';
// ============================================================

class WelcomeOverlay {
  static const String _prefKey = 'show_welcome_overlay';

  /// Tampilkan dialog selamat datang jika user belum mencentang
  /// "Jangan tampilkan ini lagi".
  static Future<void> showIfNeeded(BuildContext context) async {
    final prefs = await SharedPreferences.getInstance();
    final show = prefs.getBool(_prefKey) ?? true;
    if (!show) return;
    if (!context.mounted) return;
    await showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black54,
      builder: (_) => const _WelcomeDialog(),
    );
  }
}

class _WelcomeDialog extends StatefulWidget {
  const _WelcomeDialog();

  @override
  State<_WelcomeDialog> createState() => _WelcomeDialogState();
}

class _WelcomeDialogState extends State<_WelcomeDialog> {
  bool _dontShowAgain = false;

  Future<void> _close() async {
    if (_dontShowAgain) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(WelcomeOverlay._prefKey, false);
    }
    if (mounted) Navigator.of(context).pop();
  }

  Future<void> _open(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 10),
      child: Container(
        constraints: const BoxConstraints(maxWidth: 420),
        padding: const EdgeInsets.fromLTRB(20, 24, 20, 20),
        decoration: BoxDecoration(
          color: const Color(0xFF2B2537),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: Colors.white24, width: 1),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Logo - TANPA background hitam (transparan)
            Image.asset(
              kWelcomeLogoAsset,
              width: 175,
              height: 175,
              fit: BoxFit.contain,
            ),
            const SizedBox(height: 16),

            const Text(
              'Halo, selamat datang! 👋',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Color(0xFFF5C15C),
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 14),

            const Text(
              'Ini masih dalam tahap uji coba, dimohon untuk laporkan jika ada bug atau error hehe 😅',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white70, fontSize: 14.5, height: 1.45),
            ),
            const SizedBox(height: 14),

            const Text(
              'Project ini dibuat oleh saya sendiri dan dikerjakan hanya saat malam hari dikarenakan kerja.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white70, fontSize: 14.5, height: 1.45),
            ),
            const SizedBox(height: 18),

            // TikTok
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton.icon(
                onPressed: () => _open(kWelcomeTiktokUrl),
                icon: const Icon(Icons.tiktok, color: Colors.white, size: 22),
                label: const Text(
                  'Akun TikTok saya',
                  style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.black,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                ),
              ),
            ),
            const SizedBox(height: 12),

            // Telegram
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton.icon(
                onPressed: () => _open(kWelcomeTelegramUrl),
                icon: const Icon(Icons.send, color: Colors.white, size: 20),
                label: const Text(
                  'Channel Telegram',
                  style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF229ED9),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                ),
              ),
            ),
            const SizedBox(height: 10),

            // Jangan tampilkan ini lagi
            InkWell(
              onTap: () => setState(() => _dontShowAgain = !_dontShowAgain),
              borderRadius: BorderRadius.circular(8),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Checkbox(
                      value: _dontShowAgain,
                      onChanged: (v) => setState(() => _dontShowAgain = v ?? false),
                      side: const BorderSide(color: Colors.white54),
                      activeColor: const Color(0xFFF5C15C),
                    ),
                    const Text(
                      'Jangan tampilkan ini lagi',
                      style: TextStyle(color: Colors.white70, fontSize: 14.5),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 8),

            // Oke
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton(
                onPressed: _close,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFF5C15C),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                ),
                child: const Text(
                  'Oke saya mengerti',
                  style: TextStyle(color: Color(0xFF2B2537), fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
